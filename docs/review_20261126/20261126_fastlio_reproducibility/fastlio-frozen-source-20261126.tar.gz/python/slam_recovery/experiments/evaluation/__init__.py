"""Evaluation subpackage."""

from .trajectory_eval import (
    TrajectoryMetrics,
    associate_trajectories,
    compute_recovery_ratio_G,
    detect_quat_order,
    evaluate_path_heading_proxy_deg,
    evaluate_rotation_ate_rpe_deg,
    evaluate_trajectory,
    load_tum_trajectory,
    load_tum_trajectory_se3,
    quat_xyzw_to_rot,
    recovery_ratio_G_rounded,
    round_or_none,
    umeyama_se3_align,
)

__all__ = [
    "TrajectoryMetrics",
    "associate_trajectories",
    "compute_recovery_ratio_G",
    "detect_quat_order",
    "evaluate_path_heading_proxy_deg",
    "evaluate_rotation_ate_rpe_deg",
    "evaluate_trajectory",
    "load_tum_trajectory",
    "load_tum_trajectory_se3",
    "quat_xyzw_to_rot",
    "recovery_ratio_G_rounded",
    "round_or_none",
    "umeyama_se3_align",
]
