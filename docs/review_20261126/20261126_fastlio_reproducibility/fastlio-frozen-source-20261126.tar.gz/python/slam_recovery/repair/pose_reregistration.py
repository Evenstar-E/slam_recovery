"""Stage (d): pose-level re-registration of quarantined frames against the pre-quarantine map.

The native closed loop can only offer the host's own poses as a candidate, and the archived
four-arm shows the gate refuses exactly that population -- so B10's benefit side has no candidate
to score. This module produces a different one: each buffered scan is re-registered against the
trusted map as it stood before the quarantine opened, and the resulting pose is the candidate.

Frozen parameters (B10_PREREGISTRATION.md §9; changing any one of them is a new experiment):

    init                      the frame's host pose
    reference                 trusted points within 30 m of that pose, at most 20 000
    scan sampling             uniform stride to 2 000 points
    correspondence gate       0.5 m for the first 10 iterations, 0.25 m afterwards
    iteration limit           20
    convergence               ||delta_xi|| < 1e-6

The solver is pure numpy -- no scipy -- because the ROS interpreter that hosts the recovery node
has numpy but not scipy, and a repairer that cannot run where the node runs is not a repairer.
Nearest neighbours come from a uniform voxel hash rather than a KD-tree.

What this is not: it is a *candidate generator*. Whether a candidate deserves to be committed is
the gate's decision, and this module never calls the gate.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np

# Frozen by B10_PREREGISTRATION.md §9.
REFERENCE_RADIUS_M = 30.0
REFERENCE_MAX_POINTS = 20_000
SCAN_SAMPLES = 2_000
GATE_NEAR_M = 0.50
GATE_FAR_M = 0.25
GATE_SWITCH_ITER = 10
MAX_ITERS = 20
CONVERGENCE_TOL = 1e-6

# Not part of §9: implementation constants of the neighbour search and normal estimate. They are
# recorded with every result so a run is interpretable, and they do not change what is optimised.
# 0.5 m, not 1.0 m: with a 1 m cell a dense surface puts hundreds of points in every
# neighbourhood and the query dominates the run (2000 queries x 27 cells x N per cell). At
# 0.5 m the same 3x3x3 block still reaches 1.5 m, which is three times the correspondence gate,
# and the candidate set shrinks by close to an order of magnitude.
CELL_M = 0.5
# Hard ceiling on points taken from one cell per query. Only reached in very dense cells; when
# it is, the nearest neighbour is taken from this cap rather than from the whole cell, which is
# recorded with the run so an approximation is never silent.
MAX_POINTS_PER_CELL = 64
NORMAL_K = 8
MIN_REFERENCE_POINTS = 100
MIN_CORRESPONDENCES = 30


@dataclass(frozen=True)
class IcpConfig:
    reference_radius_m: float = REFERENCE_RADIUS_M
    reference_max_points: int = REFERENCE_MAX_POINTS
    scan_samples: int = SCAN_SAMPLES
    gate_near_m: float = GATE_NEAR_M
    gate_far_m: float = GATE_FAR_M
    gate_switch_iter: int = GATE_SWITCH_ITER
    max_iters: int = MAX_ITERS
    convergence_tol: float = CONVERGENCE_TOL
    cell_m: float = CELL_M
    max_points_per_cell: int = MAX_POINTS_PER_CELL
    normal_k: int = NORMAL_K
    min_reference_points: int = MIN_REFERENCE_POINTS
    min_correspondences: int = MIN_CORRESPONDENCES


ICP_CONFIG = IcpConfig()


@dataclass
class IcpResult:
    pose: np.ndarray
    iterations: int
    final_residual_m: float
    converged: bool
    inliers: int
    correspondences: int
    reference_points: int
    reference_total_points: int
    scan_points: int
    status: str
    displacement_from_init_m: float
    rotation_from_init_deg: float
    gate_path: List[float] = field(default_factory=list)
    envelope_m: float = 0.0
    envelope_clamps: int = 0

    def as_dict(self) -> Dict[str, object]:
        return {
            "pose_se3": [float(x) for x in np.asarray(self.pose, dtype=np.float64).reshape(16)],
            "icp_iterations": int(self.iterations),
            "icp_residual": float(self.final_residual_m),
            "icp_converged": bool(self.converged),
            "icp_inliers": int(self.inliers),
            "correspondences": int(self.correspondences),
            "reference_points": int(self.reference_points),
            "reference_total_points": int(self.reference_total_points),
            "scan_points": int(self.scan_points),
            "displacement_from_init_m": float(self.displacement_from_init_m),
            "rotation_from_init_deg": float(self.rotation_from_init_deg),
            "status": self.status,
            "envelope_m": float(self.envelope_m),
            "envelope_clamps": int(self.envelope_clamps),
        }


# ---------------------------------------------------------------------------------------------
# neighbour search
# ---------------------------------------------------------------------------------------------
class VoxelGrid:
    """Uniform voxel hash providing k-nearest-neighbour lookup without scipy.

    Cell size 1.0 m with a 3x3x3 neighbourhood reaches at least one cell in every direction, which
    is wider than the 0.5 m correspondence gate; a query that finds nothing there is an outlier,
    not a victim of the grid.
    """

    def __init__(self, points: np.ndarray, cell_m: float = CELL_M,
                 max_per_cell: int = MAX_POINTS_PER_CELL) -> None:
        self.max_per_cell = int(max_per_cell)
        self.capped_cells = 0
        self.points = np.ascontiguousarray(np.asarray(points, dtype=np.float64)[:, :3])
        self.cell_m = float(cell_m)
        if len(self.points) == 0:
            self.keys = np.zeros(0, dtype=np.int64)
            self.order = np.zeros(0, dtype=np.int64)
            self.origin = np.zeros(3, dtype=np.int64)
            self.dims = np.ones(3, dtype=np.int64)
            return
        q = np.floor(self.points / self.cell_m).astype(np.int64)
        self.origin = q.min(axis=0) - 1
        q = q - self.origin
        self.dims = (q.max(axis=0) + 2).astype(np.int64)
        key = self._key(q)
        self.order = np.argsort(key, kind="stable")
        self.keys = key[self.order]

    def _key(self, q: np.ndarray) -> np.ndarray:
        return (q[:, 0] * self.dims[1] + q[:, 1]) * self.dims[2] + q[:, 2]

    def query(self, queries: np.ndarray, k: int = 1) -> Tuple[np.ndarray, np.ndarray]:
        """Return (indices, squared distances), both (n, k); index -1 and inf where nothing is found."""
        queries = np.ascontiguousarray(np.asarray(queries, dtype=np.float64)[:, :3])
        n = len(queries)
        idx_out = np.full((n, k), -1, dtype=np.int64)
        d2_out = np.full((n, k), np.inf, dtype=np.float64)
        if n == 0 or len(self.points) == 0:
            return idx_out, d2_out

        qc = np.floor(queries / self.cell_m).astype(np.int64) - self.origin
        base = self._key(qc)
        offsets = []
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    offsets.append((dx * self.dims[1] + dy) * self.dims[2] + dz)

        lo_all, hi_all = [], []
        for off in offsets:
            target = base + off
            lo = np.searchsorted(self.keys, target, side="left")
            hi = np.searchsorted(self.keys, target, side="right")
            over = hi - lo
            self.capped_cells += int(np.count_nonzero(over > self.max_per_cell))
            hi = np.minimum(hi, lo + self.max_per_cell)
            lo_all.append(lo)
            hi_all.append(hi)
        counts = np.stack([h - l for l, h in zip(lo_all, hi_all)], axis=0)   # (27, n), offset-major
        total = int(counts.sum())
        if total == 0:
            return idx_out, d2_out

        # offset-major throughout, so the flat arrays from `np.concatenate(lo_all)` line up with
        # `counts.reshape(-1)` and with the repeated query indices
        flat_counts = counts.reshape(-1)
        # one query index per (offset, query) pair, then one per candidate
        qi = np.repeat(np.tile(np.arange(n, dtype=np.int64), len(offsets)), flat_counts)
        cell_start = np.repeat(np.concatenate(lo_all), flat_counts)
        within = np.arange(total, dtype=np.int64) - np.repeat(np.cumsum(flat_counts) - flat_counts,
                                                              flat_counts)
        ci = cell_start + within
        cand = self.order[ci]
        d2 = np.sum((queries[qi] - self.points[cand]) ** 2, axis=1)

        order = np.lexsort((d2, qi))
        qi_s, d2_s, cand_s = qi[order], d2[order], cand[order]
        new_group = np.empty(len(qi_s), dtype=bool)
        new_group[0] = True
        new_group[1:] = qi_s[1:] != qi_s[:-1]
        group_start = np.flatnonzero(new_group)
        group_id = np.cumsum(new_group) - 1
        rank = np.arange(len(qi_s)) - group_start[group_id]
        keep = rank < k
        rows = qi_s[keep]
        cols = rank[keep]
        idx_out[rows, cols] = cand_s[keep]
        d2_out[rows, cols] = d2_s[keep]
        return idx_out, d2_out


def estimate_normals(points: np.ndarray, grid: Optional[VoxelGrid] = None,
                     k: int = NORMAL_K) -> Tuple[np.ndarray, np.ndarray]:
    """Point-to-plane normals from a local k-NN plane fit; the point itself is its own neighbour."""
    pts = np.asarray(points, dtype=np.float64)[:, :3]
    n = len(pts)
    normals = np.zeros((n, 3), dtype=np.float64)
    valid = np.zeros(n, dtype=bool)
    if n < 3:
        return normals, valid
    grid = grid if grid is not None else VoxelGrid(pts)
    kk = int(min(k, n))
    for start in range(0, n, 2000):
        blk = pts[start:start + 2000]
        idx, _d2 = grid.query(blk, k=kk)
        counts = (idx >= 0).sum(axis=1)
        ok = counts >= 3
        if not np.any(ok):
            continue
        cnt = counts[ok]
        neigh = pts[np.clip(idx[ok], 0, n - 1)]                  # (m, kk, 3)
        mask = (np.arange(kk)[None, :] < cnt[:, None])[..., None]
        mean = (neigh * mask).sum(axis=1) / np.maximum(cnt, 1)[:, None]
        centred = (neigh - mean[:, None, :]) * mask
        cov = np.einsum("mki,mkj->mij", centred, centred) / np.maximum(cnt, 1)[:, None, None]
        cov = 0.5 * (cov + np.swapaxes(cov, 1, 2))
        _vals, vecs = np.linalg.eigh(cov)
        tgt = np.flatnonzero(ok) + start
        normals[tgt] = vecs[:, :, 0]
        valid[tgt] = True
    # eigh returns unit eigenvectors; the sign is arbitrary and irrelevant to |n . (p - q)|
    return normals, valid


def _exp_se3(xi: np.ndarray) -> np.ndarray:
    """Small-angle SE(3) exponential; adequate at the 1e-6 convergence tolerance used here."""
    w = np.asarray(xi[:3], dtype=np.float64)
    v = np.asarray(xi[3:], dtype=np.float64)
    theta = float(np.linalg.norm(w))
    K = np.array([[0.0, -w[2], w[1]], [w[2], 0.0, -w[0]], [-w[1], w[0], 0.0]])
    if theta < 1e-12:
        R = np.eye(3) + K
        V = np.eye(3)
    else:
        s, c = np.sin(theta), np.cos(theta)
        R = np.eye(3) + (s / theta) * K + ((1 - c) / theta ** 2) * (K @ K)
        V = (np.eye(3) + ((1 - c) / theta ** 2) * K
             + ((theta - s) / theta ** 3) * (K @ K))
    T = np.eye(4)
    T[:3, :3] = R
    T[:3, 3] = V @ v
    return T


def restrict_reference(reference_world: np.ndarray, init_pose: np.ndarray,
                       cfg: IcpConfig = ICP_CONFIG) -> Tuple[np.ndarray, int]:
    """Reference points within the radius, thinned by a uniform stride to the point budget."""
    ref = np.asarray(reference_world, dtype=np.float64)[:, :3]
    total = len(ref)
    if total == 0:
        return ref, 0
    centre = np.asarray(init_pose, dtype=np.float64)[:3, 3]
    near = ref[np.linalg.norm(ref - centre, axis=1) <= cfg.reference_radius_m]
    if len(near) > cfg.reference_max_points:
        step = int(np.ceil(len(near) / cfg.reference_max_points))
        near = near[::step]
    return near, total


def sample_scan(scan_body: np.ndarray, cfg: IcpConfig = ICP_CONFIG) -> np.ndarray:
    pts = np.asarray(scan_body, dtype=np.float64)[:, :3]
    if len(pts) <= cfg.scan_samples:
        return pts
    step = int(np.ceil(len(pts) / cfg.scan_samples))
    return pts[::step]


def _rotation_deg(R: np.ndarray) -> float:
    c = (float(np.trace(R)) - 1.0) / 2.0
    return float(np.degrees(np.arccos(np.clip(c, -1.0, 1.0))))


def reregister_frame(scan_body: np.ndarray, reference_world: np.ndarray,
                     init_pose: np.ndarray, cfg: IcpConfig = ICP_CONFIG) -> IcpResult:
    """Point-to-plane ICP of one scan against the reference, starting from the host pose."""
    init = np.asarray(init_pose, dtype=np.float64).copy()
    scan = sample_scan(scan_body, cfg)
    ref, total_ref = restrict_reference(reference_world, init, cfg)
    return _icp_core(scan, ref, init, total_ref, cfg)


def reregister_segment(scan_bodies: Dict[int, np.ndarray], poses: Dict[int, np.ndarray],
                       reference_world: np.ndarray,
                       cfg: IcpConfig = ICP_CONFIG) -> IcpResult:
    """One rigid correction for a whole quarantine segment, fitted once.

    Twenty-three per-frame registrations cost twenty-three times what the decision can afford; a
    single rigid fit over the segment's world points fits the same description -- "align the
    quarantined scans to the trusted map" -- at one registration's cost. The correction is applied
    to every candidate pose, so the candidate still has one frame per quarantined keyframe and the
    paired-evidence population is unchanged.

    The points are already in the world frame (host pose applied), so the fitted transform is the
    correction ``ΔT`` and each candidate becomes ``ΔT @ pose``. The initial transform is the
    identity: the correction, not the pose, is what is being estimated.
    """
    keys = sorted(k for k in scan_bodies if k in poses)
    if not keys:
        return IcpResult(pose=np.eye(4), iterations=0, final_residual_m=float("nan"),
                         converged=False, inliers=0, correspondences=0, reference_points=0,
                         reference_total_points=0, scan_points=0, status="NO_FRAMES",
                         displacement_from_init_m=0.0, rotation_from_init_deg=0.0)
    clouds = []
    for k in keys:
        T = np.asarray(poses[k], dtype=np.float64)
        pts = np.asarray(scan_bodies[k], dtype=np.float64)[:, :3]
        clouds.append(pts @ T[:3, :3].T + T[:3, 3])
    merged = np.vstack(clouds)
    scan = sample_scan(merged, cfg)
    centroid = np.eye(4)
    centroid[:3, 3] = np.mean(merged, axis=0)
    ref, total_ref = restrict_reference(reference_world, centroid, cfg)
    # the correction is small by construction, so the identity is the right initial value; the
    # reference restriction uses the segment centroid, not the identity's origin
    return _icp_core(scan, ref, np.eye(4), total_ref, cfg)


def _icp_core(scan: np.ndarray, ref: np.ndarray, init: np.ndarray, total_ref: int,
              cfg: IcpConfig) -> IcpResult:

    def _fail(status: str, iterations: int = 0, gate_path: Optional[List[float]] = None) -> IcpResult:
        return IcpResult(pose=init.copy(), iterations=iterations, final_residual_m=float("nan"),
                         converged=False, inliers=0, correspondences=0,
                         reference_points=len(ref), reference_total_points=total_ref,
                         scan_points=len(scan), status=status,
                         displacement_from_init_m=0.0, rotation_from_init_deg=0.0,
                         gate_path=gate_path or [])

    if len(ref) < cfg.min_reference_points:
        return _fail("REFERENCE_TOO_SMALL")
    if len(scan) < 3:
        return _fail("SCAN_TOO_SMALL")

    grid = VoxelGrid(ref, cfg.cell_m)
    normals, normal_valid = estimate_normals(ref, grid, cfg.normal_k)
    if not np.any(normal_valid):
        return _fail("NO_VALID_NORMALS")

    T = init.copy()
    gate_path: List[float] = []
    correspondences = 0
    inliers = 0
    residual = float("nan")
    converged = False
    iterations = 0
    for it in range(cfg.max_iters):
        gate = cfg.gate_near_m if it < cfg.gate_switch_iter else cfg.gate_far_m
        gate_path.append(gate)
        world = scan @ T[:3, :3].T + T[:3, 3]
        idx, d2 = grid.query(world, k=1)
        idx = idx[:, 0]
        d2 = d2[:, 0]
        correspondences = int(np.sum(idx >= 0))
        if correspondences < cfg.min_correspondences:
            return _fail("TOO_FEW_CORRESPONDENCES", iterations,
                         gate_path) if it == 0 else _fail("LOST_CORRESPONDENCES", iterations,
                                                          gate_path)
        take = (idx >= 0) & (d2 <= gate * gate)
        take &= normal_valid[np.clip(idx, 0, len(ref) - 1)]
        inliers = int(take.sum())
        iterations = it + 1
        if inliers < cfg.min_correspondences:
            return _fail("TOO_FEW_INLIERS", iterations, gate_path)
        p = world[take]
        q = ref[idx[take]]
        n = normals[idx[take]]
        r0 = np.einsum("ij,ij->i", n, p - q)
        J = np.hstack([np.cross(p, n), n])
        xi, *_ = np.linalg.lstsq(J, -r0, rcond=None)
        T = _exp_se3(xi) @ T
        residual = float(np.mean(np.abs(r0)))
        if float(np.linalg.norm(xi)) < cfg.convergence_tol:
            converged = True
            break

    return IcpResult(
        pose=T, iterations=iterations, final_residual_m=residual, converged=converged,
        inliers=inliers, correspondences=correspondences,
        reference_points=len(ref), reference_total_points=total_ref, scan_points=len(scan),
        status="CONVERGED" if converged else "ITERATION_LIMIT",
        displacement_from_init_m=float(np.linalg.norm(T[:3, 3] - init[:3, 3])),
        rotation_from_init_deg=_rotation_deg(T[:3, :3] @ init[:3, :3].T),
        gate_path=gate_path,
    )


def build_icp_candidate(
    scan_bodies: Dict[int, np.ndarray],
    reference_world: np.ndarray,
    init_poses: Dict[int, np.ndarray],
    cfg: IcpConfig = ICP_CONFIG,
    time_budget_s: float = 0.0,
) -> Tuple[Dict[int, np.ndarray], List[Tuple[int, IcpResult]]]:
    """Re-register every frame that has both a scan and an init pose.

    A frame whose re-registration fails keeps its init pose out of the returned candidate: a
    candidate is a claim that the pose was improved, and an ICP that never converged makes no such
    claim. The failure is returned alongside so the caller can report why the frame is missing.
    """
    poses: Dict[int, np.ndarray] = {}
    results: List[Tuple[int, IcpResult]] = []
    started = time.perf_counter()
    for kf_id in sorted(scan_bodies):
        if kf_id not in init_poses:
            continue
        if time_budget_s and (time.perf_counter() - started) > time_budget_s:
            # Stop rather than overrun the decision point. The frames that did not get a pose are
            # absent from the candidate, and the caller records the truncation.
            results.append((kf_id, _budget_exhausted(init_poses[kf_id], reference_world, cfg)))
            continue
        res = reregister_frame(scan_bodies[kf_id], reference_world, init_poses[kf_id], cfg)
        results.append((kf_id, res))
        if res.status in ("CONVERGED", "ITERATION_LIMIT"):
            poses[kf_id] = res.pose
    return poses, results


def _budget_exhausted(init_pose: np.ndarray, reference_world: np.ndarray,
                      cfg: IcpConfig) -> IcpResult:
    ref, total = restrict_reference(reference_world, np.asarray(init_pose, dtype=np.float64), cfg)
    return IcpResult(pose=np.asarray(init_pose, dtype=np.float64).copy(), iterations=0,
                     final_residual_m=float("nan"), converged=False, inliers=0,
                     correspondences=0, reference_points=len(ref), reference_total_points=total,
                     scan_points=0, status="BUDGET_EXHAUSTED",
                     displacement_from_init_m=0.0, rotation_from_init_deg=0.0)


# ---------------------------------------------------------------------------------------------
# motion-prior constrained, multi-scale re-registration (declared before the confirmation run)
# ---------------------------------------------------------------------------------------------
# COLLABORATION_STATUS §232 option ①. The prior is the incumbent pose -- the trusted map's
# constant-velocity extrapolation. The solver may move away from it only inside an envelope sized
# by a declared acceleration bound; the envelope models how wrong the prior may be, it is not an
# acceptance parameter and it never touches the gate. The multi-scale schedule exists because the
# single-scale solver starts at a 0.5 m correspondence gate and tightens to 0.25 m after ten
# iterations: a cloud displaced by half a metre loses its correspondences at the tightening and
# finishes at ITERATION_LIMIT with a pseudo-correction (v9d/v9e).
MOTION_PRIOR_BASE_M = 0.25          # prior uncertainty at the anchor
MOTION_PRIOR_ACCEL_MPS2 = 0.5       # declared acceleration envelope
MOTION_PRIOR_MAX_M = 2.0            # cap on the envelope
MOTION_PRIOR_MAX_ROT_DEG = 5.0      # attitude envelope, relative to the prior pose
MULTISCALE_STEPS = (
    {"scan_samples": 500, "gate_start_m": 1.20, "gate_end_m": 0.60, "iters": 8},
    {"scan_samples": 2000, "gate_start_m": 0.50, "gate_end_m": 0.25, "iters": 20},
)
STEP_DAMPING = 0.7


def motion_prior_envelope_m(dt_s: float,
                            base_m: float = MOTION_PRIOR_BASE_M,
                            accel_mps2: float = MOTION_PRIOR_ACCEL_MPS2,
                            cap_m: float = MOTION_PRIOR_MAX_M) -> float:
    """How far the prior may be wrong after ``dt_s``: half an acceleration bound, capped.

    This is a declared model of prior drift, not a tuned limit: it grows only with elapsed time
    since the anchor and does not depend on any observed outcome.
    """
    dt = max(0.0, float(dt_s))
    return float(min(cap_m, base_m + 0.5 * accel_mps2 * dt * dt))


def _log_so3(R: np.ndarray) -> np.ndarray:
    c = (float(np.trace(R)) - 1.0) / 2.0
    angle = float(np.arccos(np.clip(c, -1.0, 1.0)))
    if angle < 1e-9:
        return np.zeros(3, dtype=np.float64)
    axis = np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]],
                    dtype=np.float64) / (2.0 * np.sin(angle))
    return axis * angle


def _exp_so3(w: np.ndarray) -> np.ndarray:
    w = np.asarray(w, dtype=np.float64)
    theta = float(np.linalg.norm(w))
    K = np.array([[0.0, -w[2], w[1]], [w[2], 0.0, -w[0]], [-w[1], w[0], 0.0]])
    if theta < 1e-12:
        return np.eye(3) + K
    return (np.eye(3) + (np.sin(theta) / theta) * K
            + ((1.0 - np.cos(theta)) / theta ** 2) * (K @ K))


def clamp_pose_to_envelope(T: np.ndarray, init: np.ndarray, envelope_m: float,
                           max_rot_deg: float) -> Tuple[np.ndarray, bool]:
    """Project a pose onto the motion-prior envelope around ``init``.

    Translation and attitude are clamped independently: both bounds come from the same prior model,
    and a pose that violates either one is outside what the prior permits.
    """
    out = np.asarray(T, dtype=np.float64).copy()
    init = np.asarray(init, dtype=np.float64)
    clamped = False
    d = out[:3, 3] - init[:3, 3]
    dn = float(np.linalg.norm(d))
    if dn > envelope_m:
        out[:3, 3] = init[:3, 3] + (d * (envelope_m / dn) if dn > 1e-12 else 0.0)
        clamped = True
    w = _log_so3(out[:3, :3] @ init[:3, :3].T)
    ang = float(np.degrees(np.linalg.norm(w)))
    if ang > max_rot_deg:
        out[:3, :3] = _exp_so3(w * (max_rot_deg / ang)) @ init[:3, :3]
        clamped = True
    return out, clamped


def _sample_to(points: np.ndarray, cap: int) -> np.ndarray:
    pts = np.asarray(points, dtype=np.float64)[:, :3]
    if len(pts) <= cap:
        return pts
    step = int(np.ceil(len(pts) / max(1, int(cap))))
    return pts[::step]


def _icp_core_constrained(scan: np.ndarray, ref: np.ndarray, init: np.ndarray, total_ref: int,
                          cfg: IcpConfig, gate_start_m: float, gate_end_m: float,
                          switch_iter: int, max_iters: int, envelope_m: float,
                          max_rot_deg: float,
                          clamp_center: Optional[np.ndarray] = None) -> IcpResult:
    """One scale of point-to-plane ICP, damped and clamped to the motion-prior envelope.

    ``clamp_center`` is the pose the envelope is measured from -- the prior, not this scale's
    starting pose. Passing the previous scale's output there would let each level spend the whole
    envelope again and the multi-scale fit would drift outside what the prior permits.
    """

    def _fail(status: str, iterations: int = 0,
              gate_path: Optional[List[float]] = None) -> IcpResult:
        return IcpResult(pose=init.copy(), iterations=iterations, final_residual_m=float("nan"),
                         converged=False, inliers=0, correspondences=0,
                         reference_points=len(ref), reference_total_points=total_ref,
                         scan_points=len(scan), status=status,
                         displacement_from_init_m=0.0, rotation_from_init_deg=0.0,
                         gate_path=gate_path or [], envelope_m=envelope_m)

    if len(ref) < cfg.min_reference_points:
        return _fail("REFERENCE_TOO_SMALL")
    if len(scan) < 3:
        return _fail("SCAN_TOO_SMALL")

    grid = VoxelGrid(ref, cfg.cell_m)
    normals, normal_valid = estimate_normals(ref, grid, cfg.normal_k)
    if not np.any(normal_valid):
        return _fail("NO_VALID_NORMALS")

    T = np.asarray(init, dtype=np.float64).copy()
    center = (T.copy() if clamp_center is None
              else np.asarray(clamp_center, dtype=np.float64).copy())
    gate_path: List[float] = []
    correspondences = 0
    inliers = 0
    residual = float("nan")
    converged = False
    iterations = 0
    clamps = 0
    for it in range(int(max_iters)):
        gate = gate_start_m if it < int(switch_iter) else gate_end_m
        gate_path.append(float(gate))
        world = scan @ T[:3, :3].T + T[:3, 3]
        idx, d2 = grid.query(world, k=1)
        idx = idx[:, 0]
        d2 = d2[:, 0]
        correspondences = int(np.sum(idx >= 0))
        if correspondences < cfg.min_correspondences:
            if it == 0:
                return _fail("TOO_FEW_CORRESPONDENCES", iterations, gate_path)
            return _fail("LOST_CORRESPONDENCES", iterations, gate_path)
        take = (idx >= 0) & (d2 <= gate * gate)
        take &= normal_valid[np.clip(idx, 0, len(ref) - 1)]
        inliers = int(take.sum())
        iterations = it + 1
        if inliers < cfg.min_correspondences:
            return _fail("TOO_FEW_INLIERS", iterations, gate_path)
        p = world[take]
        q = ref[idx[take]]
        n = normals[idx[take]]
        r0 = np.einsum("ij,ij->i", n, p - q)
        J = np.hstack([np.cross(p, n), n])
        xi, *_ = np.linalg.lstsq(J, -r0, rcond=None)
        T = _exp_se3(xi * STEP_DAMPING) @ T
        T, was_clamped = clamp_pose_to_envelope(T, center, envelope_m, max_rot_deg)
        clamps += int(was_clamped)
        residual = float(np.mean(np.abs(r0)))
        if float(np.linalg.norm(xi)) < cfg.convergence_tol:
            converged = True
            break

    return IcpResult(
        pose=T, iterations=iterations, final_residual_m=residual, converged=converged,
        inliers=inliers, correspondences=correspondences,
        reference_points=len(ref), reference_total_points=total_ref, scan_points=len(scan),
        status="CONVERGED" if converged else "ITERATION_LIMIT",
        displacement_from_init_m=float(np.linalg.norm(T[:3, 3] - init[:3, 3])),
        rotation_from_init_deg=_rotation_deg(T[:3, :3] @ init[:3, :3].T),
        gate_path=gate_path, envelope_m=envelope_m, envelope_clamps=clamps,
    )


def reregister_frame_motion_prior(scan_body: np.ndarray, reference_world: np.ndarray,
                                  prior_pose: np.ndarray, envelope_m: float,
                                  cfg: IcpConfig = ICP_CONFIG,
                                  max_rot_deg: float = MOTION_PRIOR_MAX_ROT_DEG) -> IcpResult:
    """Coarse-to-fine ICP of one scan, started at the prior and clamped to its envelope."""
    init = np.asarray(prior_pose, dtype=np.float64).copy()
    if len(np.asarray(scan_body).shape) < 2 or np.asarray(scan_body).reshape(-1).size == 0:
        return IcpResult(pose=init, iterations=0, final_residual_m=float("nan"), converged=False,
                         inliers=0, correspondences=0, reference_points=0,
                         reference_total_points=0, scan_points=0, status="SCAN_TOO_SMALL",
                         displacement_from_init_m=0.0, rotation_from_init_deg=0.0,
                         envelope_m=envelope_m)
    T = init.copy()
    total_iters = 0
    clamps = 0
    last: Optional[IcpResult] = None
    for level in MULTISCALE_STEPS:
        scan = _sample_to(scan_body, level["scan_samples"])
        ref, total_ref = restrict_reference(reference_world, T, cfg)
        res = _icp_core_constrained(
            scan, ref, T, total_ref, cfg,
            gate_start_m=level["gate_start_m"], gate_end_m=level["gate_end_m"],
            switch_iter=max(1, level["iters"] // 2), max_iters=level["iters"],
            envelope_m=envelope_m, max_rot_deg=max_rot_deg, clamp_center=init)
        total_iters += res.iterations
        clamps += res.envelope_clamps
        last = res
        if res.status not in ("CONVERGED", "ITERATION_LIMIT"):
            return IcpResult(
                pose=res.pose, iterations=total_iters, final_residual_m=res.final_residual_m,
                converged=False, inliers=res.inliers, correspondences=res.correspondences,
                reference_points=res.reference_points,
                reference_total_points=res.reference_total_points,
                scan_points=res.scan_points, status=res.status,
                displacement_from_init_m=float(np.linalg.norm(res.pose[:3, 3] - init[:3, 3])),
                rotation_from_init_deg=_rotation_deg(res.pose[:3, :3] @ init[:3, :3].T),
                gate_path=res.gate_path, envelope_m=envelope_m, envelope_clamps=clamps)
        T = res.pose
    return IcpResult(
        pose=T, iterations=total_iters,
        final_residual_m=(last.final_residual_m if last else float("nan")),
        converged=bool(last.converged if last else False),
        inliers=(last.inliers if last else 0),
        correspondences=(last.correspondences if last else 0),
        reference_points=(last.reference_points if last else 0),
        reference_total_points=(last.reference_total_points if last else 0),
        scan_points=(last.scan_points if last else 0),
        status=("CONVERGED" if last and last.converged else "ITERATION_LIMIT"),
        displacement_from_init_m=float(np.linalg.norm(T[:3, 3] - init[:3, 3])),
        rotation_from_init_deg=_rotation_deg(T[:3, :3] @ init[:3, :3].T),
        gate_path=(last.gate_path if last else []),
        envelope_m=envelope_m, envelope_clamps=clamps,
    )


def build_motion_prior_candidate(
    scan_bodies: Dict[int, np.ndarray],
    reference_world: np.ndarray,
    prior_poses: Dict[int, np.ndarray],
    frame_ts_ns: Dict[int, int],
    anchor_ts_ns: Optional[int],
    cfg: IcpConfig = ICP_CONFIG,
    time_budget_s: float = 0.0,
    max_rot_deg: float = MOTION_PRIOR_MAX_ROT_DEG,
) -> Tuple[Dict[int, np.ndarray], List[Tuple[int, IcpResult]]]:
    """Register every quarantined frame at its own incumbent pose inside its own envelope.

    Same candidate contract as the other generators: a frame whose fit fails keeps no candidate
    pose, because a candidate is a claim that the pose improved.
    """
    poses: Dict[int, np.ndarray] = {}
    results: List[Tuple[int, IcpResult]] = []
    started = time.perf_counter()
    for kf_id in sorted(scan_bodies):
        if kf_id not in prior_poses:
            continue
        if time_budget_s and (time.perf_counter() - started) > time_budget_s:
            results.append((kf_id, _budget_exhausted(prior_poses[kf_id], reference_world, cfg)))
            continue
        ts = frame_ts_ns.get(kf_id)
        dt = 0.0 if (ts is None or anchor_ts_ns is None) else (int(ts) - int(anchor_ts_ns)) * 1e-9
        envelope = motion_prior_envelope_m(dt)
        res = reregister_frame_motion_prior(scan_bodies[kf_id], reference_world,
                                            prior_poses[kf_id], envelope, cfg, max_rot_deg)
        results.append((kf_id, res))
        if res.status in ("CONVERGED", "ITERATION_LIMIT"):
            poses[kf_id] = res.pose
    return poses, results
