"""A refused segment must end, or the run can never see a second event.

Mode 3 (soft bridge / wait) is the normal outcome of a refused candidate on this population.
The manager keeps `active_quarantine` set while waiting so arriving frames still have a home --
but that also means it never returns to HEALTHY, and the detector only opens a new segment from
HEALTHY. A two-event run therefore silently became a one-event run: both hall runs ended in
WAITING_FOR_EVIDENCE after 454/474 further frames, with zero second events.

The declared fix is a bounded wait: when the run sets `wait_limit_ns`, a wait that gets no
evidence inside that window closes as *unresolved* (the frames are recorded as lost, not
committed, and the trusted map stays at its last commit) and the run re-arms. Mode 4 already
left the manager terminal with no segment; the next frame re-arms that too.

Both tests fail on the pre-fix code: the first because `maybe_close_waiting_segment` does not
exist (no answer to "when does the wait end"), the second because frame 2 is registered on a
segment that never closes and never becomes trusted.
"""

import unittest

import numpy as np

from slam_recovery.core import RecoveryMode, RecoveryState, TangentFrame
from slam_recovery.health import DetectorConfig, JointHealthDetector
from slam_recovery.quarantine import TrustedMapTransactionManager
from slam_recovery.ros.recovery_node import NativeClosedLoop
from slam_recovery.sim.transaction_manager_node import OnlineRecoveryTransactionNode

WORLD = TangentFrame("world", "rot_trans", "world")
FRAME = TangentFrame("body", "rot_trans", "fixture")
V = np.array([0.0, 0.0, 0.0, 1.0, 0.0, 0.0])
INFO_BEFORE = np.diag([60.0, 60.0, 60.0, 20.0, 40.0, 40.0])


def _delta(ts_sec: float, kf_id: int, x_pos: float):
    from slam_recovery.core import BackendDelta

    pose = np.eye(4, dtype=np.float64)
    pose[0, 3] = x_pos
    return BackendDelta(
        timestamp_ns=int(ts_sec * 1e9), frame_id="map", pose_se3=pose,
        velocity=np.zeros(3), bias_acc=np.zeros(3), bias_gyr=np.zeros(3),
        cov_6x6=np.eye(6) * 0.01, info_6x6=np.eye(6) * 100.0,
        nis_value=1.0, nis_dof=6, factor_ids=[kf_id * 10], keyframe_id=kf_id)


def _open_waiting_segment(mgr, t_end_ns: int = 0):
    mgr.trigger_quarantine(
        t_end_ns, t_end_ns, V, INFO_BEFORE, 1.0,
        weak_direction_frame=WORLD, info_before_frame=WORLD,
        anchor_pose_world=np.eye(4))
    report = mgr.validate_and_resolve(None)   # no candidate -> Mode 3 while the bridge holds
    assert report.mode == RecoveryMode.MODE3_SOFT_BRIDGE_WAIT, report.mode
    assert mgr.state == RecoveryState.WAITING_FOR_EVIDENCE


class TestWaitLimit(unittest.TestCase):
    def test_a_wait_without_evidence_closes_after_the_declared_limit(self):
        mgr = TrustedMapTransactionManager(wait_limit_ns=5_000_000_000)
        _open_waiting_segment(mgr)
        mgr.register_quarantined_frame(7, 1_000_000_000)

        self.assertIsNone(mgr.maybe_close_waiting_segment(4_000_000_000),
                          "the wait closed before its declared limit")
        segment = mgr.maybe_close_waiting_segment(4_000_000_000 + 1_000)
        self.assertIsNone(segment, "3 s into a 5 s wait is not expired")

        segment = mgr.maybe_close_waiting_segment(5_000_000_000)
        self.assertIsNotNone(segment)
        self.assertIs(mgr.state, RecoveryState.ABORTED)
        self.assertIsNone(mgr.active_quarantine)
        self.assertEqual(mgr.unresolved_segments, [segment])
        event = mgr.lifecycle_events[-1]
        self.assertEqual(event["event"], "wait_limit_closed")
        self.assertIn("7", event["frames_unresolved"])
        # The trusted map is untouched: those frames are lost, not committed.
        self.assertEqual(mgr.trusted_poses, {})

    def test_rearm_returns_to_healthy_only_after_a_close(self):
        mgr = TrustedMapTransactionManager(wait_limit_ns=1_000_000_000)
        _open_waiting_segment(mgr)
        self.assertFalse(mgr.rearm(), "re-armed while a segment is still open")
        mgr.maybe_close_waiting_segment(2_000_000_000)
        self.assertTrue(mgr.rearm())
        self.assertIs(mgr.state, RecoveryState.HEALTHY)


class TestAcceptedCommitReleasesTheHold(unittest.TestCase):
    """An accepted repair must also tell the host it may write again.

    `resume` was sent only for a `rearm` event, and `rearm` is produced only after a wait
    closed unresolved. A full Mode 2 commit cleared the quarantine directly to HEALTHY and
    appended nothing, so on the accepted path the host's map hold was never released -- the
    repair would be committed and map writing would stay stopped for the rest of the run.
    Both controlled-chain segments were refusals, so this path was never exercised.
    """

    def _accepted_commit(self):
        from slam_recovery.core import CandidateMap, GateThresholds

        mgr = TrustedMapTransactionManager(
            confirmation_margin_ns=int(2.0 * 1e9),
            gate_thresholds=GateThresholds(tau_abs_min=25.0, tau_val_nis=2.5,
                                           sigma_tol=0.5, sigma_bridge=4.0),
        )
        mgr.step_healthy(_delta(1.0, 1, 1.0))
        mgr.step_healthy(_delta(4.0, 2, 2.0))
        segment = mgr.trigger_quarantine(
            estimated_onset_ns=int(3.5 * 1e9),
            current_ns=int(6.0 * 1e9),
            weak_direction_6d=np.array([0, 0, 0, 1, 0, 0], dtype=np.float64),
            info_before_6x6=np.diag([60, 60, 60, 3.0, 60, 60]),
            propagated_cov_norm=1.8,
            weak_direction_frame=FRAME, info_before_frame=FRAME,
            anchor_pose_world=np.eye(4),
        )
        candidate = CandidateMap(
            candidate_id="accepted_repair",
            parent_map_version=mgr.trusted_version,
            repaired_poses={2: np.eye(4)},
            info_after_6x6=np.diag([60, 60, 60, 45.0, 60, 60]),
            cov_after_6x6=np.eye(6) * 0.05,
            holdout_nis=1.2,
            paired_benefit_approved=True,
            wilson_lower_bound=0.90,
            reentry_pos_jump_m=0.05,
            info_after_frame=FRAME,
            cov_after_frame=FRAME,
        )
        return mgr, segment, mgr.validate_and_resolve(candidate)

    def test_a_full_commit_records_that_the_quarantine_closed(self):
        mgr, segment, report = self._accepted_commit()
        self.assertTrue(report.accepted)
        self.assertIs(mgr.state, RecoveryState.HEALTHY)
        self.assertIsNone(mgr.active_quarantine)
        events = [e["event"] for e in mgr.lifecycle_events]
        self.assertIn("commit_closed", events,
                      "the accepted path returned to HEALTHY without saying so")
        event = mgr.lifecycle_events[-1]
        self.assertEqual(event["event"], "commit_closed")
        self.assertEqual(event["segment_id"], segment.segment_id)
        self.assertEqual(event["n_committed"], 1)

    def test_a_refused_candidate_records_no_close(self):
        mgr = TrustedMapTransactionManager(wait_limit_ns=5_000_000_000)
        _open_waiting_segment(mgr)
        self.assertNotIn("commit_closed",
                         [e["event"] for e in mgr.lifecycle_events])


class TestNodeRearm(unittest.TestCase):
    def test_a_frame_after_the_wait_is_trusted_and_the_run_is_healthy(self):
        node = OnlineRecoveryTransactionNode(wait_limit_sec=5.0)
        # The detector is not the subject here: switch its alarm legs off so the HEALTHY branch
        # promotes the frame instead of opening another segment. DetectorConfig is frozen, so the
        # detector is replaced rather than mutated.
        node.detector = JointHealthDetector(DetectorConfig(
            lambda_rot_min_th=0.0, lambda_trans_min_th=0.0,
            nis_spike_th=1e9, nis_cusum_h=1e9,
            loso_conflict_th=1e9, loop_spike_th=1e9,
            confirmation_margin_ns=node.tx_mgr.confirmation_margin_ns))

        cloud = np.random.default_rng(0).normal(size=(400, 3)) * 0.16
        body = TangentFrame("body", "rot_trans", "scan:0")
        node.scan_buffer_body[0] = cloud.copy()
        node._kf_timestamps[0] = 0
        node.tx_mgr.trigger_quarantine(
            0, 0, V, INFO_BEFORE, 1.0,
            weak_direction_frame=body, info_before_frame=body,
            anchor_pose_world=np.eye(4))
        node.tx_mgr.validate_and_resolve(None)
        self.assertIs(node.tx_mgr.state, RecoveryState.WAITING_FOR_EVIDENCE)

        # While the wait is open the frame belongs to the segment: registered, not trusted.
        node.step_frame(1, 1_000_000_000, np.eye(4), cloud, 0.5)
        self.assertIs(node.tx_mgr.state, RecoveryState.WAITING_FOR_EVIDENCE)
        self.assertNotIn(1, node.tx_mgr.trusted_poses)

        # Past the limit the same ingest path closes the wait and promotes the frame.
        node.step_frame(2, 8_000_000_000, np.eye(4), cloud, 0.5)
        self.assertIs(node.tx_mgr.state, RecoveryState.HEALTHY)
        self.assertNotIn(1, node.tx_mgr.trusted_poses,
                         "a frame from the closed segment reached the trusted map")
        self.assertEqual(node.tx_mgr.lifecycle_events[0]["event"], "wait_limit_closed")
        self.assertEqual(node.tx_mgr.lifecycle_events[1]["event"], "rearm")
        # A promoted frame needs the confirmation margin to pass; one more frame past it shows
        # the re-armed run is back on the normal trusted path, not just reporting HEALTHY.
        node.step_frame(3, 11_000_000_000, np.eye(4), cloud, 0.5)
        self.assertIn(2, node.tx_mgr.trusted_poses)


class TestWaitClosesOnTheUndetectedPath(unittest.TestCase):
    """The first two-event run ended with the segment open because this path never checked.

    While the reference is frozen almost every frame is UNAVAILABLE and is ingested through
    `_ingest_without_detection`, which used to register the frame and return without ever
    evaluating the wait limit. The segment therefore stayed open for the rest of the run and a
    second event could not fire. Measured: 537 of 542 frames took this path, `lifecycle.events`
    stayed empty, terminal state WAITING_FOR_EVIDENCE.
    """

    def test_a_frame_ingested_without_detection_can_close_the_wait(self):
        node = OnlineRecoveryTransactionNode(wait_limit_sec=5.0)
        node.detector = JointHealthDetector(DetectorConfig(
            lambda_rot_min_th=0.0, lambda_trans_min_th=0.0,
            nis_spike_th=1e9, nis_cusum_h=1e9,
            loso_conflict_th=1e9, loop_spike_th=1e9,
            confirmation_margin_ns=node.tx_mgr.confirmation_margin_ns))
        loop = NativeClosedLoop(node, run_id="t", detection_enabled=False)

        cloud = np.random.default_rng(0).normal(size=(400, 3)) * 0.16
        body = TangentFrame("body", "rot_trans", "scan:0")
        node.scan_buffer_body[0] = cloud.copy()
        node._kf_timestamps[0] = 0
        node.tx_mgr.trigger_quarantine(
            0, 0, V, INFO_BEFORE, 1.0,
            weak_direction_frame=body, info_before_frame=body,
            anchor_pose_world=np.eye(4))
        node.tx_mgr.validate_and_resolve(None)
        self.assertIs(node.tx_mgr.state, RecoveryState.WAITING_FOR_EVIDENCE)

        loop._ingest_without_detection(1, 1_000_000_000, np.eye(4), cloud, None)
        self.assertIs(node.tx_mgr.state, RecoveryState.WAITING_FOR_EVIDENCE,
                      "a frame inside the wait must stay on the segment")

        loop._ingest_without_detection(2, 9_000_000_000, np.eye(4), cloud, None)
        self.assertIs(node.tx_mgr.state, RecoveryState.HEALTHY,
                      "the wait limit was never evaluated on the undetected path")
        self.assertEqual([e["event"] for e in node.tx_mgr.lifecycle_events],
                         ["wait_limit_closed", "rearm"])
        self.assertNotIn(1, node.tx_mgr.trusted_poses,
                         "a frame from the closed segment reached the trusted map")


if __name__ == "__main__":
    unittest.main(verbosity=2)


class TestEpisodeOnAReopenedSegment(unittest.TestCase):
    """A segment opened in the same call that closed the previous one still needs an episode.

    Run 110042Z opened a third quarantine at +15.9 s in the frame where the second segment
    re-armed. `_open_episode` was gated on `before is None`, and the previous segment was still
    set at that moment, so the new segment got no episode: it was never decided, never closed,
    and the trusted map stayed frozen for the remaining 370 frames -- E2 could not fire.
    """

    def test_a_segment_that_replaces_another_gets_an_episode(self):
        from slam_recovery.tests.test_recovery_node import _FakeLoopNode, _scan

        class _RearmingNode(_FakeLoopNode):
            def step_frame(self, kf_id, ts_ns, pose, scan, nis):
                self.calls.append((kf_id, ts_ns))
                self.scan_buffer_body[kf_id] = scan
                self._kf_timestamps[kf_id] = ts_ns
                # The wait expired, the run re-armed, and this same frame triggered again.
                self.tx_mgr.active_quarantine = object()
                self.tx_mgr.state = RecoveryState.QUARANTINED
                return None

        node = _RearmingNode(trigger_at=10_000)
        old_segment = object()
        node.tx_mgr.active_quarantine = old_segment
        node.tx_mgr.state = RecoveryState.WAITING_FOR_EVIDENCE
        loop = NativeClosedLoop(node, run_id="t")

        loop.on_pair(1_000_000_000, np.eye(4), _scan(200))

        self.assertEqual(len(loop.episodes), 1,
                         "the segment that replaced the waiting one has no episode")
        self.assertIs(loop.episodes[0], loop._open)


if __name__ == "__main__":
    unittest.main(verbosity=2)
