#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
base=$(dirname "$PWD")
source /opt/ros/noetic/setup.bash
version="$base/fastlio_stability_20261126/v2"
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1
export PYTHONPATH="$base/fastlio_fault_bridge_matrix_20261125:$base/rigid_ramp_bridge_20261125:$base/short_window_bridge_20261125:$base/ntuviral_fastlio_step5_20261125:/home/tong/src/slam_recovery:$version:$base/fastlio_native_bridge_commit_20261125:$base/fastlio_rtp03_clock_confirmation_20261126:$base/fastlio_rtp03_clock_retiming_20261126:$PYTHONPATH"
sha256sum -c --quiet EXPERIMENT.sha256
(cd "$version" && sha256sum -c --quiet FREEZE.sha256 && sha256sum -c --quiet HOST_SHA256)
(cd "$base/fastlio_rtp03_clock_retiming_20261126" && sha256sum -c --quiet REVIEW_EVIDENCE.sha256)
(cd "$base/fastlio_rtp03_clock_confirmation_20261126" && sha256sum -c --quiet REVIEW_EVIDENCE.sha256)
/usr/bin/python3 -c 'import json,pathlib; b=pathlib.Path("../ntuviral_fastlio_step5_20261125"); print("\n".join(json.loads((b/p/"population.json").read_text())["study_bag_sha256"]+"  "+str(b/p/"study.bag") for p in ("eee_03","sbs_02")))' > SOURCES.sha256
sha256sum -c --quiet SOURCES.sha256
/usr/bin/python3 run_matrix.py prepare
sha256sum FIXED_INPUTS.json > FIXED_INPUTS.sha256
for name in $(/usr/bin/python3 -c 'import json; print(*json.load(open("CASES.json"))["cases"])'); do
    for arm in native plugin; do
        folder="${name}_${arm}"
        rc=0
        bash run_case.sh "$folder" "$name" "$arm" || rc=$?
        printf '%s %s\n' "$folder" "$rc" >> STATUS.txt
        if [[ -d "$folder" && -s "$folder/finished_at.txt" ]]; then
            if [[ ! -s "$folder/exit.txt" ]]; then printf '%s\n' "$rc" > "$folder/exit.txt"; fi
            /usr/bin/python3 compact.py "$folder"
        fi
    done
done
sha256sum -c --quiet FIXED_INPUTS.sha256
sha256sum -c --quiet SOURCES.sha256
(cd "$version" && sha256sum -c --quiet FREEZE.sha256 && sha256sum -c --quiet HOST_SHA256)
