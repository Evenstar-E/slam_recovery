"""Sample identical physical scans and align each arm at the prefault pose."""
import json
from pathlib import Path

import numpy as np
from score_mixed import mat, xyz_samples


ROOT = Path(__file__).resolve().parent
TRANSLATION = np.array([-.05,0.,.055])  # Frozen host LiDAR-to-body calibration.


def main():
    rows = json.loads((ROOT/"RESULTS.json").read_text())["events"]
    scans = {}
    for site in sorted({r["site"] for r in rows}):
        keys = {frame["key"] for row in rows if row["site"]==site for frame in row["plot"]}
        if keys:
            scans[site] = xyz_samples(site,keys)
            assert set(scans[site])==keys
    points = {}
    frames = []
    for row in rows:
        labels = dict(case=row["case"],event=row["event"],kind=row["kind"],site=row["site"],
                      frames=[],outcome=row["lifecycle"]["outcome"])
        frames.append(labels)
        if not row["plot"] or not all(row["pose_before"].values()):
            continue
        align = {arm:np.linalg.inv(mat(pose)) for arm,pose in row["pose_before"].items()}
        for frame in row["plot"]:
            xyz = scans[row["site"]][frame["key"]] + TRANSLATION
            ids = dict(offset_s=frame["offsets_s"],stamp_ns=frame["key"],point_count=len(xyz))
            for arm,pose in frame["poses"].items():
                pose_aligned = align[arm]@mat(pose)
                key = f"{row['case']}_{row['event']}_{len(labels['frames'])}_{arm}"
                points[key] = (xyz@pose_aligned[:3,:3].T+pose_aligned[:3,3]).astype(np.float32)
                ids[arm] = key
            labels["frames"].append(ids)
    np.savez_compressed(ROOT/"SCAN_POINTS.npz",**points)
    (ROOT/"SCAN_FRAMES.json").write_text(json.dumps(frames,indent=2)+"\n")


if __name__=="__main__":
    main()
