"""Evaluate event lifecycle and trajectory on physical scan identities."""
import csv
import hashlib
import json
from pathlib import Path
import re
import sys

import numpy as np


ROOT = Path(__file__).resolve().parent
DATA = ROOT.parent/"ntuviral_fastlio_step5_20261125"
sys.path.insert(0,str(ROOT.parent/"fastlio_rtp03_v2_acceptance_20261126"))
import evaluate as base

NS = base.NS


def event_actions(arm, action, episode=None):
    return [row for row in arm["receipt"]["events"] if row["action"]==action
            and (episode is None or row.get("episode")==episode)]


def integer(message, key):
    number = re.search(rf"\b{key}=(\d+)",message)
    return int(number.group(1)) if number else None


def same_stamps(actual, expected):
    return len(actual)==len(expected) and all(abs(a-b)<=1024 for a,b in zip(actual,expected))


def health(arm, lo, hi):
    return [row for row in arm["health"] if row["last_fed_ns"] is not None
            and lo<=row["last_fed_ns"]<hi]


def event_lifecycle(arm, trigger, physical, fault_keys, fault_fed):
    if trigger is None:
        return dict(outcome="missed_or_already_held",rearmed=False,full_closure=False)
    stamp = trigger["alarm_scan_ns"]
    episode = trigger["episode"]
    taken = next(iter(event_actions(arm,"private_trial",episode)),None)
    released = next(iter(event_actions(arm,"committed_released",episode)
                         or event_actions(arm,"refused_caught_up_released",episode)),None)
    rearm = next(iter(event_actions(arm,"rearmed",episode)),None)
    confirm = next(iter(event_actions(arm,"clock_confirmed",episode)),None)
    checkpoint = integer(trigger["checkpoint"],"stamp_ns")
    hold_match = (integer(trigger["hold"],"stamp_ns")==checkpoint and "map_writes=held" in trigger["hold"])
    groups = [r for r in arm["receipt"]["refusal_receipts"] if r["episode"]==episode]
    faulty = [r for r in groups if r["math"]!="lidar_update"]
    suffix = [r for r in groups if r["math"]=="lidar_update"]
    captured = taken["fault_stamps_ns"] if taken else []
    result = dict(outcome=released["action"] if released else "incomplete",episode=episode,rearmed=bool(rearm),
                  alarm_key=physical[stamp],alarm_delay_ms=(physical[stamp]-fault_keys[0])/1e6,
                  confirm_delay_ms=(physical[confirm["confirmation_scan_ns"]]-fault_keys[0])/1e6
                      if confirm and confirm["confirmation_scan_ns"] in physical else None,
                  channels=trigger["channels"],checkpoint_ns=checkpoint,
                  checkpoint_before_fault=checkpoint is not None and checkpoint<fault_keys[0],
                  hold_matches_checkpoint=hold_match, captured=len(captured),
                  all_faults_captured=captured==fault_fed,
                  retimed=sum(bool(r.get("retimed")) for r in faulty),
                  localization=sum(r["math"]=="localization_only" for r in faulty),
                  imu_only=sum(r["math"]=="imu_only" for r in faulty),healthy_updates=len(suffix),
                  public_map_updates=0, rearm_pose_ns=rearm["first_new_public_pose_ns"] if rearm else None)
    result["native_refusal_input_exact"] = same_stamps([r["scan_ns"] for r in faulty],fault_fed)
    clock_rows = event_actions(arm,"sensor_clock_frame",episode)
    if clock_rows:
        step = event_actions(arm,"clock_confirmed",episode)[0]
        result["clock_header_offset_ms"] = step["header_offset_ns"]/1e6
        result["clock_header_states"] = {s:sum(r["state"]==s for r in clock_rows)
                                         for s in ("shifted","returned","invalid")}
        first_invalid = next((r["scan_ns"] for r in clock_rows if r["state"]=="invalid"),None)
        result["first_clock_header_invalid_ms"] = (
            (first_invalid-fault_fed[0])/1e6 if first_invalid is not None else None)
    if taken and taken.get("map_result"):
        result["map_gate"] = taken["map_result"]
    if released and released["action"]=="committed_released":
        live = released["native_status"]
        count = integer(live,"repaired_map_updates")
        result["public_map_updates"] = count
        result["healthy_updates"] = len(taken["healthy_suffix_ns"])
        maps = arm["receipt"]["maps"]
        candidate = maps[f"E{episode}_candidate.xyz32"]
        raw = maps[f"E{episode}_raw.xyz32"]
        result["native_commit_verified"] = (count==len(fault_fed)
            and released["live_candidate_map_sha256"]==candidate["sha256"]
            and candidate["sha256"]!=raw["sha256"] and candidate["bytes"]==12*integer(live,"map_points")
            and "map_writes=released" in live)
        motion = result["native_commit_verified"]
    else:
        motion = result["native_refusal_input_exact"] and len(suffix)==2
    result["full_closure"] = bool(rearm and released and hold_match
        and result["checkpoint_before_fault"] and result["all_faults_captured"] and motion)
    return result


def gt_for(site):
    path = DATA/"incoming"/f"{site}_gt.csv"
    expected = base.read(DATA/site/"population.json")["ground_truth_sha256"]
    assert hashlib.sha256(path.read_bytes()).hexdigest()==expected
    return base.read_gt(path)


def main():
    fixed = base.read(ROOT/"FIXED_INPUTS.json")
    base.ROOT = ROOT
    check_prefix = base.check_prefix

    def check(rows, expected):
        check_prefix([{k:r[k] for k in expected[0]} for r in rows],expected)

    base.check_prefix = check
    result = dict(cases={},events=[],clean={})
    matrix = []
    for name, spec in fixed.items():
        windows, expected = spec["windows"], spec["inputs"]
        origin, site = spec["origin_ns"], spec["site"]
        native, plugin = [base.load_arm(f"{name}_{role}",expected) for role in ("native","plugin")]
        roles = dict(native=native,plugin=plugin)
        physical = {r["fed_ns"]:r["stamp_ns"] for r in expected}
        truth = gt_for(site)
        common = sorted(native["poses"].keys() & plugin["poses"].keys())
        ref = {t:v for t in common if (v:=base.interp(*truth,native["poses"][t][1])) is not None}
        triggers = event_actions(plugin,"triggered")
        frame_index = {r["fed_ns"]:r["event"] for r in expected}
        off = [t for t in triggers if frame_index.get(t["alarm_scan_ns"]) is None]
        final = {role:dict(exit=arm["receipt"]["code"],rows=len(arm["relay"]),complete=arm["complete_input"],
                          public=len(arm["public"]), unbound=len(arm["unbound"]),
                          private_leaked=arm["receipt"]["private_leaked"],
                          strictly_increasing=arm["receipt"]["public_increasing"],
                          final_mode=(arm["receipt"]["final"] or {}).get("mode"),
                          resets=arm["health"]) for role,arm in roles.items()}
        result["cases"][name] = dict(site=site, arms=final, outside_events=off,
                                     alarms=len(triggers), windows=len(windows))
        if not windows:
            keys = sorted(native["public"].keys() & plugin["public"].keys())
            delta = np.asarray(base.latencies(plugin,keys))-base.latencies(native,keys)
            result["clean"][name] = dict(paired=len(keys),spurious_isolates=len(triggers),
                public={role:len(arm["public"]) for role,arm in roles.items()},
                p50_ms=float(np.median(delta)) if len(delta) else None,
                p95_ms=float(np.quantile(delta,.95)) if len(delta) else None)
        last_rearm_key = None
        for j,w in enumerate(windows):
            lo,hi = w["onset_ns"],w["end_ns"]
            tail = min(hi+3*NS,windows[j+1]["onset_ns"]) if j+1<len(windows) else hi+3*NS
            target = [r["stamp_ns"] for r in expected if lo<=r["stamp_ns"]<tail]
            injected = [r for r in expected if r["event"]==w["id"]]
            fault_keys, fault_fed = [[r[field] for r in injected] for field in ("stamp_ns","fed_ns")]
            associated = [r for r in triggers if r["alarm_scan_ns"] in fault_fed]
            trigger = associated[0] if associated else None
            lc = event_lifecycle(plugin, trigger, physical, fault_keys, fault_fed)
            before = max((t for t in ref if t<lo and all(t in d["public"] for d in roles.values())),default=None)
            paired = [t for t in ref if lo<=t<tail]
            paired_post = [t for t in paired if t>=hi]
            metrics = {}
            for role,arm in roles.items():
                pre_out = max((t for t in arm["public"] if t<lo),default=None)
                after = min((t for t in target if t>=hi and t in arm["public"]),default=None)
                marker = health(arm,lo,tail)
                metrics[role] = dict(
                    public=sum(t in arm["public"] for t in target),
                    faults_public=sum(t in arm["public"] for t in fault_keys),
                    total=len(target), marker=marker,
                    no_output_window_s=base.maximum_gap(sorted(arm["public"]),lo,tail),
                    before_to_post_s=(after-pre_out)/NS if pre_out is not None and after is not None else None,
                    after_end_s=(after-hi)/NS if after is not None else None,
                    first_public_bias_m=base.first_public_displacement(arm,after,before,truth,ref),
                    all_rmse=base.displacement_error(arm,paired,before,ref),
                    post_rmse=base.displacement_error(arm,paired_post,before,ref))
            joint = sorted(t for t in target if t>=hi and all(t in d["public"] for d in roles.values()))
            chosen = list(dict.fromkeys(joint[i] for i in (0,(len(joint)-1)//2,len(joint)-1))) if joint else []
            pose_before = {role:(arm["poses"][before] if before in arm["poses"] else None) for role,arm in roles.items()}
            plot = [dict(key=t, offsets_s=(t-hi)/NS,
                         poses={role:arm["poses"][t] for role,arm in roles.items()})
                    for t in chosen if all(t in d["poses"] for d in roles.values())]
            rearm_keys = [t for t,row in plugin["public"].items() if row["stamp_ns"]==lc.get("rearm_pose_ns")]
            result["events"].append(dict(case=name,site=site,event=w["id"],kind=w["kind"],
                windows_s=[(t-origin)/NS for t in (lo,hi,tail)], fault_count=len(injected),
                associated_isolates=len(associated), lifecycle=lc, arms=metrics,
                previous_rearm_before_this=last_rearm_key<fault_keys[0] if last_rearm_key is not None else None,
                rearm_key=min(rearm_keys) if rearm_keys else None,
                plot=plot, pose_before=pose_before))
            if rearm_keys:
                last_rearm_key=min(rearm_keys)
            matrix.append([name,site,w["id"],w["kind"],len(injected),int(bool(trigger)),
                           lc["outcome"],int(lc["full_closure"]),lc.get("alarm_delay_ms"),
                           lc.get("confirm_delay_ms"),lc.get("public_map_updates"),lc.get("retimed"),
                           lc.get("localization"),lc.get("imu_only"),len(paired),metrics["native"]["all_rmse"]["rmse_m"],
                           metrics["plugin"]["all_rmse"]["rmse_m"],metrics["native"]["post_rmse"]["rmse_m"],
                           metrics["plugin"]["post_rmse"]["rmse_m"],metrics["native"]["public"],
                           metrics["plugin"]["public"],len(target),metrics["plugin"]["first_public_bias_m"],
                           metrics["plugin"]["before_to_post_s"]])
    (ROOT/"RESULTS.json").write_text(json.dumps(result,indent=2,allow_nan=False)+"\n")
    with (ROOT/"EVENT_MATRIX.csv").open("w",newline="",encoding="utf-8") as stream:
        out = csv.writer(stream)
        out.writerow(("case","site","event","fault","injected","triggered","outcome","full_closure",
                      "alarm_delay_ms","confirm_delay_ms","public_map_updates","retimed","localization","imu_only",
                      "common_frames","native_rmse_m","plugin_rmse_m","native_post_rmse_m","plugin_post_rmse_m",
                      "native_public","plugin_public","public_slots","plugin_first_public_bias_m","plugin_before_to_post_s"))
        out.writerows(matrix)


if __name__=="__main__":
    main()
