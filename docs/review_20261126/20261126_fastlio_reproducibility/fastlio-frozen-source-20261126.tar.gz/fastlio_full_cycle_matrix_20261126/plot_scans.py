"""Render comparable 3D views of common public post-event scans."""
import json
from pathlib import Path
from tempfile import TemporaryDirectory

import matplotlib
matplotlib.use("Agg")
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.lines import Line2D
import matplotlib.pyplot as plt
import numpy as np

from audit_panel_alignment import require_matplotlib_panel_alignment


ROOT = Path(__file__).resolve().parent
KINDS = dict(z_shift="Z shift",rigid_ramp="Rigid jump and return",occlusion="Near-field occlusion",
             attenuation="Severe dropout",narrow_fov="Narrow field of view",sync="Clock offset")
COLORS = dict(native="#566477",plugin="#0C8569")


def render(rows, points, page, pdf, temporary):
    figure, panels = plt.subplots(3,3,figsize=(7.2,8.4),squeeze=False,subplot_kw={"projection":"3d"})
    figure.subplots_adjust(left=.085,right=.95,bottom=.06,top=.835,hspace=.27,wspace=.1)
    figure.text(.066,.965,"FAST-LIO2 public poses on the same scans",fontsize=13,weight="bold")
    figure.text(.066,.939,f"Post-event views, page {page}  |  Shared scale within each row",fontsize=9)
    handles = [Line2D([],[],marker="o",markersize=4,linestyle="none",color=color,label=arm.title())
               for arm,color in COLORS.items()]
    figure.legend(handles=handles,loc="upper left",bbox_to_anchor=(.062,.927),ncol=2,frameon=False)
    for index,(axes,row) in enumerate(zip(panels,rows)):
        source = [points[frame[arm]] for frame in row["frames"] for arm in COLORS]
        merged = np.concatenate(source) if source else np.zeros((1,3))
        low, high = merged.min(axis=0),merged.max(axis=0)
        middle = (low+high)/2
        half = max(float((high-low).max())*.53,1.)
        for col,axis in enumerate(axes):
            axis.set_box_aspect((1,1,1))
            axis.view_init(elev=24,azim=-61)
            axis.set(xlim=(middle[0]-half,middle[0]+half),ylim=(middle[1]-half,middle[1]+half),
                     zlim=(middle[2]-half,middle[2]+half),xticks=[],yticks=[],zticks=[])
            if col<len(row["frames"]):
                frame = row["frames"][col]
                for arm,color in COLORS.items():
                    axis.scatter(*points[frame[arm]].T,s=1.55,alpha=.53,color=color,linewidths=0,
                                 depthshade=False,rasterized=True)
                axis.set_title(f"+{frame['offset_s']:.3f} s",pad=2,fontsize=8)
            else:
                axis.text2D(.19,.48,"No paired public frame",transform=axis.transAxes,fontsize=7)
        row_top = axes[0].get_position().y1
        figure.text(.066,row_top+.035,f"{KINDS[row['kind']]}  |  {row['case'].replace('_',' ')} E{row['event']}"
                    f"  |  {half*2:.1f} m cube",fontsize=8,weight="bold")
    figure.text(.066,.025,"The same LiDAR points are placed using each arm's published pose.",fontsize=8)
    require_matplotlib_panel_alignment(figure,json_out=ROOT/f"scans_page_{page}_alignment.json")
    pdf.savefig(figure,dpi=300)
    figure.savefig(ROOT/f"scans_page_{page}.png",dpi=300)
    figure.savefig(temporary/f"scans_page_{page}.svg",dpi=300)
    figure.savefig(temporary/f"scans_page_{page}.tiff",dpi=300,pil_kwargs={"compression":"tiff_lzw"})
    plt.close(figure)


def main():
    plt.rcParams.update({
        "font.family":"sans-serif",
        "font.sans-serif":["Arial","DejaVu Sans"],
        "font.size":8,
        "pdf.fonttype":42,
        "svg.fonttype":"none",
    })
    rows = json.loads((ROOT/"SCAN_FRAMES.json").read_text())
    with (np.load(ROOT/"SCAN_POINTS.npz") as points,
          PdfPages(ROOT/"POINT_CLOUD_COMPARISON.pdf") as pdf, TemporaryDirectory() as output):
        for i in range(0,len(rows),3):
            render(rows[i:i+3],points,i//3+1,pdf,Path(output))


if __name__=="__main__":
    main()
