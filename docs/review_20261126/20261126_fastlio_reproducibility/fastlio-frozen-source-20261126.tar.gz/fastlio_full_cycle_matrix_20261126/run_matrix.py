"""Blind controller and native companion on one fixed case from the matrix."""
import hashlib
import json
import os
from pathlib import Path
import sys
import time

import cv2
import rosbag
import rospy

from run_retiming import RetimedController
from run_confirmation import ObservedController, frozen


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent/"ntuviral_fastlio_step5_20261125"
NS = frozen.NS


def definition(case):
    config = json.loads((ROOT/"CASES.json").read_text())
    site, events = config["cases"][case]
    population = json.loads((SOURCE/site/"population.json").read_text())
    origin = population["start_ns"]
    windows = [dict(id=i, kind=kind, onset_ns=origin+round(start*NS), end_ns=origin+round(end*NS),
                    inject_z_m=.5)
               for i, (kind, start, end) in enumerate(events, 1)]
    return config, site, origin, windows


def inputs(bag, config, origin, windows):
    start, stop = [origin+round(t*NS) for t in config["feed_s"]]
    read_start, read_stop = [frozen.time_to_ros(origin+round(t*NS)) for t in config["read_s"]]
    counts = [0]*len(windows)
    for _, msg, receipt in bag.read_messages(topics=["/velodyne_points"],
                                               start_time=read_start, end_time=read_stop):
        stamp = msg.header.stamp.to_nsec()
        if not start <= stamp < stop:
            continue
        index = next((i for i,e in enumerate(windows) if e["onset_ns"] <= stamp < e["end_ns"]), None)
        if index is not None:
            counts[index] += 1
            msg = frozen.mutate(msg, windows[index]["kind"], windows[index], counts[index])
        yield msg, receipt.to_nsec(), dict(stamp_ns=stamp, fed_ns=msg.header.stamp.to_nsec(),
                                           event=None if index is None else index+1,
                                           sha256=hashlib.sha256(msg.data).hexdigest())


def prepare():
    cases = json.loads((ROOT/"CASES.json").read_text())["cases"]
    inputs_by_case = {}
    for case in cases:
        config, site, origin, windows = definition(case)
        with rosbag.Bag(str(SOURCE/site/"study.bag")) as bag:
            rows = [row for _,_,row in inputs(bag, config, origin, windows)]
        assert 360 <= len(rows) <= 380
        assert all(a["fed_ns"] < b["fed_ns"] for a,b in zip(rows, rows[1:]))
        expected = [sum(row["event"] == window["id"] for row in rows) for window in windows]
        assert all(count > 0 for count in expected)
        inputs_by_case[case] = dict(site=site, origin_ns=origin, windows=windows, counts=expected, inputs=rows)
    (ROOT/"FIXED_INPUTS.json").write_text(json.dumps(inputs_by_case,separators=(",",":"))+"\n")


def run(out, case, arm):
    version = Path(os.environ["FROZEN_VERSION_DIR"])
    assert Path(frozen.__file__).resolve() == version/"mixed_controller.py"
    config, site, origin, windows = definition(case)
    read_start, read_stop = [frozen.time_to_ros(origin+round(t*NS)) for t in config["read_s"]]
    expected = json.loads((ROOT/"FIXED_INPUTS.json").read_text())[case]
    speed = config["speed"]
    with rosbag.Bag(str(SOURCE/site/"study.bag")) as bag:
        imu = [msg for _,msg,_ in bag.read_messages(topics=["/imu_raw"],start_time=read_start,end_time=read_stop)]
        rospy.init_node("blind_matrix",disable_signals=True)
        ctl = (RetimedController if arm=="plugin" else ObservedController)(out,imu)
        ctl.arm = "sparse_localization" if arm=="plugin" else "native"
        ctl.wait(lambda:ctl.native_pub.get_num_connections()>0 and ctl.imu_pub.get_num_connections()>0,
                 12,"missing native subscribers")
        (out/"node_identity.txt").write_text(str(os.getpid())+"\n")
        wall = None
        groups = 0
        for msg, recorded, identity in inputs(bag, config, origin, windows):
            assert identity == expected["inputs"][groups]
            groups += 1
            position = (recorded-origin)/NS
            if wall is None:
                wall = time.monotonic()-position/speed
            remaining = wall+position/speed-time.monotonic()
            if remaining>0:
                time.sleep(remaining)
            now = time.monotonic()
            receive_ns = origin+round((now-wall)*speed*NS)
            if identity["stamp_ns"]<origin+31*NS and arm=="plugin":
                ctl.diagnose(msg,origin,receive_ns)
            row = dict(identity, receiver_ns=receive_ns, received_wall_ns=round(now*NS),
                       wall_feed_ns=time.monotonic_ns())
            ctl.input_file.write(json.dumps(row)+"\n")
            if arm=="plugin":
                ctl.receive(msg,origin,receive_ns,row["received_wall_ns"])
            else:
                ctl.imu_through(identity["fed_ns"])
                ctl.native_pub.publish(msg)
                ctl.latest_scan=identity["fed_ns"]
            if ctl.mode in ("AWAIT_LIVE","REENTRY"):
                wall += max(0.,time.monotonic()-now)
        assert groups==len(expected["inputs"])
        if arm=="plugin":
            ctl.flush_clock(origin)
        if arm=="native" or ctl.mode=="ARMED":
            ctl.wait_pose(ctl.latest_scan,10)
        tail = ctl.send("status")
        (out/"completion.json").write_text(json.dumps(dict(site=site, scenario=case, arm=arm,
            events=ctl.closed, mode=ctl.mode, tail=tail, injected=expected["counts"],
            speed=speed, controller_pid=os.getpid()),indent=2)+"\n")


if __name__=="__main__":
    cv2.setNumThreads(1)
    if sys.argv[1:]==["prepare"]:
        prepare()
    else:
        run(Path(sys.argv[1]),sys.argv[2],sys.argv[3])
