"""Offline diagnostic transaction driver, via the existing native file/topic protocol."""
import argparse
from pathlib import Path
import json
import sys
import time

import rospy
import rosbag

sys.path.insert(0,str(Path(__file__).resolve().parent.parent / "campus12_step3_native_20261124"))
from native_probe import Probe, integer


CHECKPOINT_BOUNDARY = 1711548075776363519
ARMS = ("clean", "injected", "partial40", "repaired60", "clean_repeat")


def run(out, target):
    probe = Probe(out)
    rows = json.loads(target.with_suffix(".json").read_text())
    expected = [r["stamp_ns"] for r in rows]
    partial = {r["stamp_ns"] for r in rows if r["partial40"]}
    branches = {}
    with rosbag.Bag(str(target)) as bag:
        for topic, msg, _ in bag.read_messages():
            branches.setdefault(topic[1:], []).append(msg)
    assert all([msg.header.stamp.to_nsec() for msg in msgs] == expected for msgs in branches.values())

    probe.arm(CHECKPOINT_BOUNDARY)
    cp_stamp = probe.snapshot_applied(CHECKPOINT_BOUNDARY)
    # The publication stream can pause near host hibernation, so wait on the actual
    # capture-complete export rather than treating a pose as receipt for LiDAR/IMU.
    probe.wait(lambda: (probe.ctl/"checkpoint.xyz32").is_file(), 105, "capture did not freeze")
    base = probe.send("status")
    assert integer(base,"lab_frozen") == 1 and integer(base,"valid") == 1
    count = integer(base,"captured_groups")
    if count < 250:
        raise RuntimeError(f"too few common groups through the tail: {count}")
    results = []
    for arm in ARMS:
        ack = probe.send("lab_arm", arm)
        assert integer(ack, "valid") == 1
        if arm == "clean_repeat":
            clouds = branches["clean"]
        elif arm == "partial40":
            clouds = [good if good.header.stamp.to_nsec() in partial else bad
                      for good,bad in zip(branches["repaired60"],branches["injected"])]
        else:
            clouds = branches[arm]
        received = probe.publish_candidate(clouds)
        replay = probe.send("reprocess", str(expected[-1]))
        assert integer(replay,"valid") == 1 and integer(replay,"checkpoint_stamp_ns") == cp_stamp
        assert integer(replay,"repaired_fed") == len(expected)
        assert integer(replay,"replay_suffix") + integer(replay,"replay_within_end") == count

        def completed():
            report = probe.send("status")
            return report if integer(report,"replay_remaining") == 0 else None

        report = probe.wait(completed, 25, f"replay did not finish for {arm}")
        assert integer(report,"captured_groups") == count
        export = probe.send("lab_export", arm)
        assert integer(export,"valid") == 1
        entry = {"arm":arm, "received":received, "reprocess_ack":replay, "last_status":report,
                 "map_points":integer(export,"points"), "capture_groups":count}
        print(json.dumps(entry),flush=True)
        results.append(entry)
    (out / "native_arms.json").write_text(json.dumps(results,indent=2)+"\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("run_root",type=Path)
    parser.add_argument("target",type=Path)
    args = parser.parse_args()
    rospy.init_node("candidate_native_probe")
    run(args.run_root,args.target)


if __name__ == "__main__":
    main()
