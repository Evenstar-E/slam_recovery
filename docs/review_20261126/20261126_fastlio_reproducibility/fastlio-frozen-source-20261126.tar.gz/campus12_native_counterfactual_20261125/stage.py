"""Prepare all 60 target frames with the previously frozen beam model."""
from pathlib import Path
import json
import sys

import numpy as np
import rosbag
from genpy import Time

from slam_recovery.ros.cloud_repair import shift_z_cloud

ASSET = Path("../campus12_e1_ray_candidate_20261124").resolve()
sys.path.insert(0, str(ASSET))
from ray_candidate import estimate, measures


INPUT = "/home/tong/datasets/mmlins/campus_12.bag"
TRACE = Path("../campus12_tail_ab_20261124/with_recovery/relay_frames.jsonl")
TOPIC = "/velodyne_points"


def ns_time(ns):
    return Time(ns // 10**9, ns % 10**9)


def main():
    trace = [json.loads(row) for row in TRACE.read_text().splitlines()]
    targets = {row["stamp_ns"]: row for row in trace if row["event"] == "frame" and row["shifted"]}
    assert len(targets) == 60
    old = json.loads((ASSET / "candidate_estimates.json").read_text())
    partial = set(row["stamp_ns"] for row in old["candidate_frames"])
    assert len(partial) == 40 and partial <= targets.keys()
    model = {int(key): tuple(vals) for key, vals in old["calibration_model"].items()}
    rows = []
    with rosbag.Bag(INPUT) as bag, rosbag.Bag("targets.bag", "w", compression="lz4") as out:
        for _, msg, timestamp in bag.read_messages(topics=[TOPIC],
                start_time=ns_time(min(targets)-10**9), end_time=ns_time(max(targets)+10**9)):
            ns = msg.header.stamp.to_nsec()
            if ns not in targets:
                continue
            record = targets[ns]
            if msg.width * msg.height != record["points"]:
                raise ValueError(f"target scan population mismatch {ns}")
            bad = shift_z_cloud(msg, record["dz"])
            bias, beams, deviation = estimate(bad, model)
            repaired = shift_z_cloud(bad, -bias)
            for branch, cloud in (("clean", msg), ("injected", bad), ("repaired60", repaired)):
                out.write("/" + branch, cloud, timestamp)
            _, z0, _, _ = measures(msg)
            _, z1, _, _ = measures(bad)
            _, z2, _, _ = measures(repaired)
            valid = np.isfinite(z0)
            e_bad = z1[valid] - z0[valid]
            e_new = z2[valid] - z0[valid]
            rows.append({"stamp_ns":ns,"partial40":ns in partial,"estimated_bias_m":bias,
                         "even_beams":beams,"median_beam_dispersion_m":deviation,"finite_points":int(valid.sum()),
                         "sum_abs_bad":float(np.abs(e_bad).sum()),"sum_abs_repaired":float(np.abs(e_new).sum())})
    assert [r["stamp_ns"] for r in rows] == sorted(targets)
    (Path("targets.json")).write_text(json.dumps(rows,indent=2,allow_nan=False)+"\n")


if __name__ == "__main__":
    main()
