"""Check native input identity, compare trajectories without alignment, and inspect maps."""
from pathlib import Path
from collections import defaultdict
import json

import numpy as np


ROOT = Path(__file__).resolve().parent
RUN = ROOT / "native_comparison"
ARMS = ("clean","injected","partial40","repaired60","clean_repeat")
CELL_M = 0.5


def stats(values):
    return {"mean": float(np.mean(values)), "rmse": float(np.sqrt(np.mean(values ** 2))),
            "median":float(np.median(values)), "p95":float(np.quantile(values,0.95)),
            "max":float(np.max(values)), "last":float(values[-1])}


def pose_errors(reference, poses):
    dp = poses[:, :3] - reference[:, :3]
    qa = poses[:, 3:]
    qb = reference[:, 3:]
    qa = qa / np.linalg.norm(qa, axis=1, keepdims=True)
    qb = qb / np.linalg.norm(qb, axis=1, keepdims=True)
    dot = np.clip(np.abs(np.sum(qa * qb, axis=1)), 0.0, 1.0)
    angle = np.rad2deg(2.0 * np.arccos(dot))
    return np.linalg.norm(dp,axis=1), np.abs(dp[:,2]), angle


def positions(path):
    result = np.fromfile(str(path), "<f4").reshape(-1,3)
    if not np.isfinite(result).all():
        raise ValueError(f"nonfinite map coordinates in {path}")
    return result


def voxels(points):
    return set(map(tuple, np.floor(points / CELL_M).astype(np.int64)))


def overlap(reference, other):
    common = len(reference & other)
    return {"reference":len(reference), "candidate":len(other), "shared":common,
            "extra":len(other - reference), "missing":len(reference-other),
            "iou":common/len(reference|other)}


def fields(text):
    return {a.split("=",1)[0]:a.split("=",1)[1] for a in text.split() if "=" in a}


def assert_integer(fields_dict, key, want):
    got = int(fields_dict[key])
    if got != want:
        raise ValueError(f"{key} got {got}, expected {want}")


def main():
    targets = json.loads((ROOT / "targets.json").read_text())
    target_ns=np.array([r["stamp_ns"] for r in targets],dtype=np.int64)
    partial = {r["stamp_ns"] for r in targets if r["partial40"]}
    arm_data = json.loads((RUN/"native_arms.json").read_text())
    trace = defaultdict(list)
    for line in (RUN/"ctl/lab_trace.jsonl").read_text().splitlines():
        row=json.loads(line)
        trace[row["arm"]].append(row)
    assert tuple(trace) == ARMS
    cp_map = voxels(positions(RUN/"ctl/checkpoint.xyz32"))
    ref_point=positions(RUN/"ctl/clean.xyz32")
    ref_map=voxels(ref_point)
    ref_new=ref_map-cp_map
    key = lambda row: (row["scan_stamp_ns"],row["stamp_ns"])
    population = [key(r) for r in trace["clean"]]
    scan_stamps = np.array([key(r)[0] for r in trace["clean"]],dtype=np.int64)
    assert np.all(np.diff(scan_stamps) > 0)
    anchor = fields(arm_data[0]["reprocess_ack"])["checkpoint_stamp_ns"]
    exact_target = np.array([np.any(np.abs(s-target_ns)<=1024) for s in scan_stamps])
    before = scan_stamps < target_ns[0]-1024
    after = scan_stamps > target_ns[-1]+1024
    assert int(exact_target.sum()) == len(target_ns) and np.all(before | exact_target | after)
    assert len(ref_new) > 0 and after.sum() >= 150
    p_ref=np.array([r["pose"] for r in trace["clean"]],dtype=np.float64)
    result={"checkpoint_stamp_ns":int(anchor),
            "population":len(population),
            "phase_counts":{"before":int(before.sum()),"fault":int(exact_target.sum()),"post_fault":int(after.sum())},
            "final_scan_stamp_ns":int(scan_stamps[-1]), "first_scan_stamp_ns":int(scan_stamps[0]),
            "precision_raw_mae_m":{
                "injected":sum(r["sum_abs_bad"] for r in targets)/sum(r["finite_points"] for r in targets),
                "partial40":sum(r["sum_abs_repaired"] if r["stamp_ns"] in partial else r["sum_abs_bad"] for r in targets)/sum(r["finite_points"] for r in targets),
                "repaired60":sum(r["sum_abs_repaired"] for r in targets)/sum(r["finite_points"] for r in targets),
            }, "map_voxel_m":CELL_M, "checkpoint_points":len(positions(RUN/"ctl/checkpoint.xyz32")), "arms":{}}
    per_frame=[]
    for arm,receipt in zip(ARMS,arm_data):
        rr=trace[arm]
        assert receipt["arm"] == arm
        assert population == [key(r) for r in rr], f"unequal historical population in {arm}"
        assert [r["replacement"] for r in rr] == exact_target.tolist()
        ack=fields(receipt["last_status"])
        assert_integer(ack,"repaired_in_update",len(target_ns))
        assert_integer(ack,"repaired_map_updates",len(target_ns))
        assert_integer(ack,"replay_remaining",0)
        assert_integer(fields(receipt["reprocess_ack"]),"checkpoint_stamp_ns",int(anchor))
        got=np.array([r["pose"] for r in rr],dtype=np.float64)
        assert np.isfinite(got).all()
        points = positions(RUN/f"ctl/{arm}.xyz32")
        nmap=voxels(points)
        assert len(points)==receipt["map_points"]
        pos,z,angle=pose_errors(p_ref,got)
        mcounts=np.array([r["matched_features"] for r in rr])
        d={"native_replaced_updated_mapped":[receipt["received"],len(target_ns),int(ack["repaired_map_updates"])],
           "all_voxel_overlap":overlap(ref_map,nmap),"new_voxel_overlap":overlap(ref_new,nmap-cp_map),
           "map_points":len(points),
           "median_matched_features_fault":float(np.median(mcounts[exact_target])),
           "phase":{}}
        for name,mask in (("before",before),("fault",exact_target),("post_fault",after),("entire",np.ones(len(got),bool))):
            d["phase"][name]={"position_m":stats(pos[mask]),"abs_z_m":stats(z[mask]),"rotation_deg":stats(angle[mask])}
        result["arms"][arm]=d
        per_frame += [{"arm":arm, "scan_stamp_ns":key(r)[0], "position_error_m":float(pos[i]),
                       "z_abs_error_m":float(z[i]),"rotation_error_deg":float(angle[i])} for i,r in enumerate(rr)]
    result["same_source_and_native_group_population"] = True
    (ROOT/"native_comparison_metrics.json").write_text(json.dumps(result,indent=2,allow_nan=False)+"\n")
    (ROOT/"errors_per_frame.jsonl").write_text("".join(json.dumps(row)+"\n" for row in per_frame))
    print("population",result["phase_counts"], "raw_z_mae_m",result["precision_raw_mae_m"])
    for k,d in result["arms"].items():
        print(k, "position_rmse_m",[d["phase"][name]["position_m"]["rmse"] for name in ("before","fault","post_fault")],
              "rot_rmse_deg",[d["phase"][name]["rotation_deg"]["rmse"] for name in ("fault","post_fault")],
              "map_iou_all_new",d["all_voxel_overlap"]["iou"],d["new_voxel_overlap"]["iou"])


if __name__ == "__main__":
    main()
