"""Evaluate the archived gate's scoring components on equal-input native poses.

Uses the same raw-to-world projection, precursor fit, sub-sampler, holdout scorer
and Wilson test. This is an offline component diagnosis on the diagnostic run's
own pre-fault inputs. No admission or map mutation is run in this analysis.
"""
from bisect import bisect_left
from collections import defaultdict
import json
from pathlib import Path

from genpy import Time
import numpy as np
import rosbag

from slam_recovery.core import GateThresholds, transport_information
from slam_recovery.ros.cloud_repair import ReferenceGrid
from slam_recovery.ros.recovery_node import (
    cloud_to_xyz, extrapolate_incumbent, pose_to_matrix, subsample
)
from slam_recovery.sim.transaction_manager_node import OnlineRecoveryTransactionNode
from slam_recovery.validation.fim_and_holdout import (
    compute_6dof_point_to_plane_fim, compute_disjoint_holdout_point_to_plane_nis,
)
from slam_recovery.validation.wilson_validator import evaluate_paired_sequential_benefit

ROOT = Path(__file__).resolve().parent
RUN = ROOT/"native_comparison"
INPUT = "/home/tong/datasets/mmlins/campus_12.bag"


def nearest(stamps, value, tolerance):
    i = bisect_left(stamps,value)
    adjacent=stamps[max(0,i-1):i+1]
    if not adjacent:
        return None
    best=min(adjacent,key=lambda got:abs(got-value))
    return best if abs(best-value)<=tolerance else None


def stamp(ns):
    return Time(secs=ns//10**9,nsecs=ns%10**9)


def msg_pose(msg):
    p,q=msg.pose.pose.position,msg.pose.pose.orientation
    return pose_to_matrix((p.x,p.y,p.z),(q.x,q.y,q.z,q.w))


def trace_poses(targets, arm_label):
    data=defaultdict(dict)
    keys=sorted(targets)
    for line in (RUN/"ctl/lab_trace.jsonl").read_text().splitlines():
        row=json.loads(line)
        if row["arm"] not in arm_label or not row["replacement"]:
            continue
        ns=nearest(keys,row["scan_stamp_ns"],1024)
        if ns is None:
            raise ValueError("replacement outside the frozen population")
        p=row["pose"]
        data[row["arm"]][ns]=pose_to_matrix(p[:3],p[3:])
    assert all(sorted(d)==keys for d in data.values())
    return data


def historical_reference(cp_ns):
    odo={}
    with rosbag.Bag(str(RUN/"frontend.bag")) as recorded:
        for _,msg,_ in recorded.read_messages(topics=["/Odometry"]):
            ns=msg.header.stamp.to_nsec()
            if ns<=cp_ns+1024:
                odo.setdefault(ns,msg_pose(msg))
    stamps=sorted(odo)
    fit=OnlineRecoveryTransactionNode(confirmation_margin_sec=4, sigma_meas_m=.12)
    poses,times={},{}
    raw_sample_count=0
    used=set()
    with rosbag.Bag(INPUT) as source:
        for _,msg,_ in source.read_messages(topics=["/velodyne_points"],end_time=stamp(cp_ns+100_000_000)):
            ns=msg.header.stamp.to_nsec()
            pose_ns=nearest(stamps,ns,40_000_000)
            if pose_ns is None or pose_ns in used or ns>cp_ns+1024:
                continue
            used.add(pose_ns)
            X=odo[pose_ns]
            cloud=subsample(cloud_to_xyz(msg),6000)
            pts=cloud@X[:3,:3].T+X[:3,3]
            fit.committed_map_points.append(pts[::4])
            k=len(poses)
            poses[k],times[k]=X,pose_ns
            raw_sample_count+=len(pts[::4])
    assert len(poses)>1500 and abs(times[max(times)]-cp_ns)<=1024
    return fit.get_trusted_map_points(max_pts=1500), poses, times, raw_sample_count


def score(reference, poses, clouds, timestamps):
    rows=[]
    for ns in timestamps:
        T=poses[ns]
        pts=clouds[ns]@T[:3,:3].T+T[:3,3]
        details={}
        val=compute_disjoint_holdout_point_to_plane_nis(
            reference,pts,delta_pose_se3=np.eye(4),sigma_meas_m=.12, details=details)
        rows.append({"stamp_ns":ns,"nis":val,"coverage_under_2m_signed_plane":details["inlier_coverage"],
                     "branch":details["branch"],"sampled_train":details["train_sampled"],
                     "sampled_query":details["query_sampled"]})
    return rows


def distance_quality(reference, sparse, clean_poses, clean_clouds, target_stamps):
    # Compare support of identical query points in the actual scorer's sparse set and
    # the native map captured before E1. 1 m is a diagnostic distance, no admission effect.
    a,b=ReferenceGrid(sparse),ReferenceGrid(reference)
    vals=[[],[]]
    for ns in target_stamps[::5]:
        X=clean_poses[ns]
        cloud=clean_clouds[ns]
        q=cloud[::max(1,len(cloud)//300)][:300]@X[:3,:3].T+X[:3,3]
        vals[0].append(a.nearest_distances(q,reach=2))
        vals[1].append(b.nearest_distances(q,reach=2))
    out={}
    for k,parts in zip(("sparse_scoring_reference","native_checkpoint_map"),vals):
        d=np.concatenate(parts)
        out[k]={"queries":int(len(d)),"within_1m_fraction":float((d<=1).mean()),
                "queries_with_local_cell_candidates":int(np.isfinite(d).sum()),
                "median_distance_on_queries_with_cell_candidates_m":float(np.median(d[np.isfinite(d)]))
                if np.isfinite(d).any() else None}
    return out


def main():
    result=json.loads((ROOT/"native_comparison_metrics.json").read_text())
    targets=json.loads((ROOT/"targets.json").read_text())
    ns=[r["stamp_ns"] for r in targets]
    fixed40=[r["stamp_ns"] for r in targets if r["partial40"]]
    checkpoint=result["checkpoint_stamp_ns"]
    ref,poses0,times0,count=historical_reference(checkpoint)
    series={k:{} for k in ("clean","injected","repaired60")}
    with rosbag.Bag(str(ROOT/"targets.bag")) as bag:
        for topic,msg,_ in bag.read_messages(topics=["/clean","/injected","/repaired60"]):
            series[topic[1:]][msg.header.stamp.to_nsec()]=subsample(cloud_to_xyz(msg),6000)

    native=trace_poses(ns,{"clean","injected","partial40","repaired60","clean_repeat"})
    baseline,_,basis=extrapolate_incumbent(poses0,times0,{t:t for t in ns})
    gate=GateThresholds()
    trigger=1711548079873248339
    pre_info, _, _, _, weak=compute_6dof_point_to_plane_fim(
        series["injected"][trigger],sigma_meas_m=.075)
    weak=np.asarray(weak,dtype=np.float64).reshape(6)
    weak=weak/np.linalg.norm(weak)
    info_before=float(weak@pre_info@weak)
    anchor_inverse=np.linalg.inv(native["injected"][trigger])
    diagnostics={"scope":"Offline scorer components only. Same implementation, diagnostic run's pre-event prefix.",
                 "trusted_keyframes":len(poses0), "historical_points_before_cap":count,
                 "scorer_reference_points":len(ref),"anchor":basis, "windows":{},
                 "weak_direction_info_at_trigger":info_before,
                 "weak_direction_info_threshold":max(gate.tau_abs_min,gate.tau_info_kappa*info_before)}
    for name, population in (("previous_40_frames",fixed40),("all_60_frames",ns)):
        scores={}
        prev=score(ref,baseline,series["repaired60"],population)
        diagnostics["windows"][name]={"count":len(population),
                                       "incumbent_mean_nis":float(np.mean([r["nis"] for r in prev])),
                                       "results":scores}
        for arm in ("clean","injected","partial40","repaired60","clean_repeat"):
            curves=score(ref,native[arm],series["repaired60"],population)
            pre=np.array([r["nis"] for r in prev])
            nxt=np.array([r["nis"] for r in curves])
            wilson=evaluate_paired_sequential_benefit(pre,nxt,reentry_position_jump_m=0.0,
                                                       min_observations=8)
            fims=[]
            for t in population[::5]:
                X=native[arm][t]
                pts=series["repaired60"][t]@X[:3,:3].T+X[:3,3]
                info,_,_,_,_=compute_6dof_point_to_plane_fim(pts,sigma_meas_m=.075)
                fims.append(info)
            current_info=transport_information(np.mean(fims,axis=0),anchor_inverse)
            scores[arm]={"weak_direction_info_after":float(weak@current_info@weak),"mean_nis":float(nxt.mean()), "holdout_stride_5_mean_nis":float(nxt[::5].mean()),
                         "paired_benefit_approved":bool(wilson.approved),"relative_threshold":gate.min_wilson_lower_bound,
                         "wilson_lower_bound":float(wilson.wilson_lower_bound),
                         "improved_frames":int(wilson.num_improved_frames),
                         "absolute_nis_threshold":gate.tau_val_nis,
                         "mean_plane_coverage":float(np.mean([r["coverage_under_2m_signed_plane"] for r in curves])),
                         "per_frame":curves}
    checkpoint_points=np.fromfile(str(RUN/"ctl/checkpoint.xyz32"),"<f4").reshape(-1,3)
    score_sparse=ref[::max(1,len(ref)//600)][:600]
    diagnostics["geometric_support_on_clean_replay"]=distance_quality(
        checkpoint_points,score_sparse,native["clean"],series["clean"],ns)
    (ROOT/"gate_diagnostic.json").write_text(json.dumps(diagnostics,indent=2,allow_nan=False)+"\n")
    print("support",diagnostics["geometric_support_on_clean_replay"])
    for k,w in diagnostics["windows"].items():
        print(k,"incumbent",w["incumbent_mean_nis"])
        for arm,x in w["results"].items():
            print(arm, x["holdout_stride_5_mean_nis"],x["improved_frames"],x["wilson_lower_bound"],x["weak_direction_info_after"])


if __name__ == "__main__":
    main()
