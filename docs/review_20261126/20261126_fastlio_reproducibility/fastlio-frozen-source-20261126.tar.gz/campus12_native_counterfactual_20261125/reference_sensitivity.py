"""Post hoc reference diagnostic with a common native-supported query set."""
from itertools import product
import json

import numpy as np
import rosbag

from gate_diagnostic import ROOT, RUN, historical_reference, trace_poses
from slam_recovery.ros.cloud_repair import ReferenceGrid
from slam_recovery.ros.recovery_node import cloud_to_xyz, subsample
from slam_recovery.validation.fim_and_holdout import compute_disjoint_holdout_point_to_plane_nis


def native_residual(points, grid, offsets):
    base = tuple(np.floor(points/grid.cell).astype(int))
    buckets = [grid.cells.get(tuple(a+b for a,b in zip(base,d))) for d in offsets]
    present = [p for p in buckets if p is not None]
    if not present:
        return None
    candidates=np.concatenate(present)
    distances=np.sum((candidates-points)**2,axis=1)
    nearby=np.flatnonzero(distances<=1)
    if nearby.size<8:
        return None
    idx=nearby[np.argpartition(distances[nearby],7)[:8]]
    neighbors=candidates[idx]
    centroid=neighbors.mean(axis=0)
    centered=neighbors-centroid
    _,vectors=np.linalg.eigh(centered.T@centered/8)
    return float(abs(vectors[:,0]@(points-centroid)))


def main():
    cp=json.loads((ROOT/"native_comparison_metrics.json").read_text())["checkpoint_stamp_ns"]
    target=json.loads((ROOT/"targets.json").read_text())
    keys=[r["stamp_ns"] for r in target]
    stride_keys=set(keys[::5])
    poses=trace_poses(keys,{"clean"})["clean"]
    historical,_,_,_=historical_reference(cp)
    grid=ReferenceGrid(np.fromfile(str(RUN/"ctl/checkpoint.xyz32"),"<f4").reshape(-1,3))
    offsets=list(product(range(-2,3),repeat=3))
    ordinary,native=[],[]
    total=0
    with rosbag.Bag(str(ROOT/"targets.bag")) as bag:
        for _,msg,_ in bag.read_messages(topics=["/clean"]):
            stamp=msg.header.stamp.to_nsec()
            if stamp not in stride_keys:
                continue
            X=poses[stamp]
            xyz=subsample(cloud_to_xyz(msg),6000)
            pts=xyz@X[:3,:3].T+X[:3,3]
            details={}
            compute_disjoint_holdout_point_to_plane_nis(historical,pts,sigma_meas_m=.12,details=details)
            qs=pts[::max(1,len(pts)//300)][:300]
            assert len(qs)==len(details["points"])
            total+=len(qs)
            for point,evidence in zip(qs,details["points"]):
                near=native_residual(point,grid,offsets)
                if near is None:
                    continue
                ordinary.append(evidence["residual_m"])
                native.append(near)
    result={"scope":"post hoc localization only. Same clean queries with eight native pre-fault neighbours within 1m",
            "total_queries":total,"common_queries":len(native),
            "ordinary_sparse": {"rms_m":float(np.sqrt(np.mean(np.square(ordinary)))),
                                "median_m":float(np.median(ordinary))},
            "native_local": {"rms_m":float(np.sqrt(np.mean(np.square(native)))),
                             "median_m":float(np.median(native))}}
    (ROOT/"reference_sensitivity.json").write_text(json.dumps(result,indent=2,allow_nan=False)+"\n")
    print(json.dumps(result,indent=2))


if __name__=="__main__":
    main()
