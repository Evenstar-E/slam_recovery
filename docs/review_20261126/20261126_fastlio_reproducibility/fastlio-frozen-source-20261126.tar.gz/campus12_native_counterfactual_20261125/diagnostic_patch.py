"""Add offline comparison-only controls to a private native build source."""
from pathlib import Path

path = Path("ws/src/FAST-LIO/src/laserMapping.cpp")
cpp = path.read_text()


def replace(old, new):
    global cpp
    if cpp.count(old) != 1:
        raise ValueError(f"expected one anchor: {old[:100]}")
    cpp = cpp.replace(old, new)


replace('static std::ofstream g_nr_updates;', r'''static std::ofstream g_nr_updates;
static long long lab_end_ns = 0;
static bool lab_frozen = false;
static std::string lab_arm;
static std::ofstream lab_trace;

static bool lab_dump_points(const std::string& path, const PointVector& map)
{
    std::ofstream out(path + ".tmp", std::ios::binary);
    for (const auto& point : map)
    {
        const float xyz[] = {point.x, point.y, point.z};
        out.write(reinterpret_cast<const char*>(xyz), sizeof(xyz));
    }
    out.close();
    return bool(out) && std::rename((path + ".tmp").c_str(), path.c_str()) == 0;
}
''')
replace('        if (cmd == "status")',r'''        if (cmd == "lab_arm" && lab_end_ns > 0)
        {
            if (!lab_frozen || g_nr_replay_remaining != 0 || !g_nr_cp.valid ||
                (payload != "clean" && payload != "injected" && payload != "partial40" &&
                 payload != "repaired60" && payload != "clean_repeat"))
            {
                nr_write_ack("OK lab_arm valid=0");
                return;
            }
            lab_arm = payload;
            g_nr_repair_received.store(0);
            g_nr_repair_applied.store(0);
            g_nr_repaired_in_update = g_nr_repaired_map_updates = 0;
            g_nr_last_repaired_update_ns = 0;
            g_nr_repaired.clear();
            nr_write_ack("OK lab_arm valid=1 name=" + lab_arm);
        }
        else if (cmd == "lab_export" && lab_end_ns > 0)
        {
            if (!lab_frozen || g_nr_replay_remaining || payload != lab_arm)
            {
                nr_write_ack("OK lab_export valid=0");
                return;
            }
            PointVector map;
            if (ikdtree.Root_Node != nullptr) ikdtree.flatten(ikdtree.Root_Node, map, NOT_RECORD);
            const bool ok = lab_dump_points(g_nr_dir + "/" + lab_arm + ".xyz32", map);
            nr_write_ack(std::string("OK lab_export valid=") + (ok ? "1" : "0") +
                         " points=" + std::to_string(map.size()));
        }
        else if (cmd == "status")''')
replace('              << " map_points=" << ikdtree.validnum()\n              << " deferred_resets="',r'''              << " map_points=" << ikdtree.validnum()
              << " lab_frozen=" << (lab_frozen ? 1 : 0)
              << " captured_groups=" << g_nr_groups.size()
              << " deferred_resets="''')
replace('            nr_write_ack(s.str());\n            g_nr_groups.clear();',
        '            nr_write_ack(s.str());\n            if (!lab_frozen) g_nr_groups.clear();')
replace('        g_nr_updates.open(g_nr_dir + "/repair_updates.jsonl", std::ios::out);',r'''        g_nr_updates.open(g_nr_dir + "/repair_updates.jsonl", std::ios::out);
        if (const char* cutoff = std::getenv("LIO_DIAGNOSTIC_CAPTURE_END_NS"))
        {
            lab_end_ns = std::stoll(cutoff);
            lab_trace.open(g_nr_dir + "/lab_trace.jsonl", std::ios::out);
        }''')
replace('if (g_nr_cur_is_replay || sync_packages(Measures))',
        'if (g_nr_cur_is_replay || (!lab_frozen && sync_packages(Measures)))')
replace('            nr_capture_group();',r'''            nr_capture_group();
            if (!g_nr_cur_is_replay && lab_end_ns > 0 &&
                (long long)std::llround(lidar_end_time * 1e9) >= lab_end_ns)
            {
                lab_frozen = true;
                if (!lab_dump_points(g_nr_dir + "/checkpoint.xyz32", g_nr_cp.map_pts))
                    ROS_ERROR("[diagnostic] checkpoint output failed");
            }''')
replace('            g_nr_lidar_end = lidar_end_time;\n            ++g_nr_frame;',r'''            if (g_nr_cur_is_replay && lab_trace.is_open())
            {
                const auto p = state_point.pos;
                const auto q = state_point.rot.coeffs();
                lab_trace << std::setprecision(17)
                    << "{\"arm\":\"" << lab_arm << "\",\"stamp_ns\":"
                    << (long long)std::llround(lidar_end_time * 1e9)
                    << ",\"scan_stamp_ns\":" << (long long)std::llround(Measures.lidar_beg_time * 1e9)
                    << ",\"replacement\":" << (g_nr_cur_repaired ? "true" : "false")
                    << ",\"pose\":[" << p(0) << "," << p(1) << "," << p(2)
                    << "," << q(0) << "," << q(1) << "," << q(2) << "," << q(3) << "]"
                    << ",\"map_points\":" << ikdtree.validnum()
                    << ",\"matched_features\":" << effct_feat_num << "}" << std::endl;
            }
            g_nr_lidar_end = lidar_end_time;
            ++g_nr_frame;''')
# Guard the familiar rebuild fallback before discovery of the diagnostic arm.
replace('#include <atomic>', '#include <atomic>\n#include <cstdlib>')
path.write_text(cpp)
