#!/bin/bash
set -eo pipefail
cd "$(dirname "$0")"
source /opt/ros/noetic/setup.bash
export PYTHONPATH="$HOME/src/slam_recovery:$PYTHONPATH" OMP_THREAD_LIMIT=2 OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
sha256sum -c --quiet prereg.sha256
(cd ws && sha256sum -c --quiet ../binary.sha256)
test ! -e suite.log
for dataset in eee_03 sbs_02; do
    for i in $(seq 1 740); do
        if [ -f "incoming/$dataset.zip" ]; then break; fi
        sleep 1
    done
    if [ ! -f "incoming/$dataset.zip" ]; then
        printf '%s %s UNAVAILABLE_ARCHIVE\n' "$(date -Is)" "$dataset" | tee -a suite.log
        continue
    fi
    export STEP5_INPUT="$PWD/$dataset"
    if ! /usr/bin/python3 prepare.py "$dataset" > "$dataset-prepare.log" 2>&1; then
        printf '%s %s PREPARE_FAILED\n' "$(date -Is)" "$dataset" | tee -a suite.log
        tail -10 "$dataset-prepare.log"
        continue
    fi
    if ! /usr/bin/python3 stage.py > "$dataset-stage.log" 2>&1; then
        printf '%s %s STAGE_FAILED\n' "$(date -Is)" "$dataset" | tee -a suite.log
        tail -10 "$dataset-stage.log"
        continue
    fi
    (
        cd "$dataset"
        sha256sum frozen_candidates.bag frozen_candidates.json population.json events.json study.bag > frozen.sha256
    )
    for rep in r1 r2; do
        (cd "$dataset" && sha256sum -c --quiet frozen.sha256)
        for arm in clean native isolation forced gated; do
            printf '%s %s %s START %s\n' "$(date -Is)" "$dataset" "$rep" "$arm" | tee -a suite.log
            code=0
            bash run_one.sh "$dataset" "$rep" "$arm" || code=$?
            printf '%s %s %s END %s %s\n' "$(date -Is)" "$dataset" "$rep" "$arm" "$code" | tee -a suite.log
            if [ "$code" != 0 ]; then tail -8 "$dataset/$rep/$arm/probe.log" 2>/dev/null || true; fi
        done
    done
done
