#!/bin/bash
set -eo pipefail
cd "$(dirname "$0")"
source /opt/ros/noetic/setup.bash
export PYTHONPATH="$HOME/src/slam_recovery:$PYTHONPATH"
export OMP_THREAD_LIMIT=2 OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
test ! -e exact_suite.log
for seq in eee_03 sbs_02; do
    for rep in r1 r2; do
        for arm in forced gated; do
            src="$seq/$rep/$arm"
            if grep -q 'assert integer(start,"repaired_fed")==got' "$src/probe.log" 2>/dev/null; then
                printf '%s %s %s\n' "$seq" "$rep" "$arm"
            fi
        done
    done
done > exact_attempt_plan.txt
test -s exact_attempt_plan.txt
(cd ws_exact && catkin_make -j2 > ../exact_build.log 2>&1)
(cd ws_exact && sha256sum devel/lib/fast_lio/fastlio_mapping) > exact_binary.sha256
export TWO_EVENT_ROOT="$PWD" LAB_WORKSPACE="$PWD/ws_exact"
export LIO_TWO_EVENT_DIAGNOSTIC=1 LIO_FOUR_POLICY_DIAGNOSTIC=1 LIO_STEP5_EXACT_SCAN_KEY=1
export PLAY_RATE=1 REMAP=/velodyne_points:=/velodyne_points_raw
while read -r seq rep arm; do
    out="$PWD/exact/$seq/$rep/$arm"
    export STEP5_INPUT="$PWD/$seq" TWO_EVENT_ARM="$arm"
    (cd "$STEP5_INPUT" && sha256sum -c --quiet frozen.sha256)
    mkdir -p "$(dirname "$out")"
    mkdir "$out"
    duration="$(/usr/bin/python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["duration_s"])' "$STEP5_INPUT/population.json")"
    printf '%s %s %s START %s\n' "$(date -Is)" "$seq" "$rep" "$arm" | tee -a exact_suite.log
    date -Is > "$out/started_at.txt"
    code=0
    timeout --signal=INT --kill-after=15 180 bash runner.sh "$out" "$STEP5_INPUT/study.bag" "$duration" > "$out/runner.log" 2>&1 || code=$?
    printf '%s\n' "$code" > "$out/runner_exit.txt"
    date -Is > "$out/finished_at.txt"
    printf '%s %s %s END %s %s\n' "$(date -Is)" "$seq" "$rep" "$arm" "$code" | tee -a exact_suite.log
    if [ "$code" != 0 ]; then tail -8 "$out/probe.log" 2>/dev/null || true; fi
done < exact_attempt_plan.txt
