"""Read the response for a particular request, regardless of realtime clock."""
def response(directory, request, phase, command):
    path = directory / f"response.{request}.{phase}"
    try:
        text = path.read_text().strip()
    except FileNotFoundError:
        return None
    return text if text.startswith(f"OK {command} ") else None
