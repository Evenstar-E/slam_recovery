"""Validate realized interventions before calculating fixed comparisons."""
from collections import Counter
from itertools import product
import json
import math
import os
from pathlib import Path
import sys

import numpy as np
import rosbag

from step3_verify import map_points, map_voxels, metrics, msg_pose, nearest, read_jsonl
from slam_recovery.ros.recovery_node import pose_to_matrix
from controller import TAIL_MARK_NS, integer
from stage import INPUT, WINDOWS
ROOT = Path(os.environ["STEP5_RUN"])
POPULATION = json.loads((INPUT/"population.json").read_text())

ARMS = ("clean", "native", "isolation", "forced", "gated")
FROZEN = json.loads((INPUT / "frozen_candidates.json").read_text())["frames"]
ANCHOR_CEILING = WINDOWS[0]["onset_ns"] - 4_000_000_000
GROUP_TOLERANCE = 1024
SHIFT_OFFSETS = tuple(product((-1, 0, 1), repeat=3))


def describe(values):
    values = np.asarray(values)
    stats = metrics(values)
    if len(values):
        stats["mean"] = float(np.mean(values))
        stats["median"] = float(np.median(values))
        stats["sample_sd"] = float(np.std(values, ddof=1)) if len(values) > 1 else None
    return stats


def xyz_pose(row):
    p = row["pose"]
    return pose_to_matrix(p[:3], p[3:])


def fits(poses, time, trans, target):
    fitted = trans @ poses[time]
    delta = fitted[:3, 3] - target[:3, 3]
    cos = (np.trace(fitted[:3, :3].T @ target[:3, :3]) - 1) / 2
    return float(np.linalg.norm(delta)), float(np.degrees(np.arccos(np.clip(cos, -1, 1))))


def receipts(root, actions):
    sends = [row for row in actions if "sent" in row]
    replies = [row for row in actions if "command" in row and row["command"] != "snapshot_applied"]
    assert [row["request"] for row in sends] == list(range(1, len(sends) + 1))
    assert [(x["request"], x["sent"]) for x in sends] == [(x["request"], x["command"]) for x in replies]
    for row in replies + [row for row in actions if row.get("command") == "snapshot_applied"]:
        state = "deferred" if " deferred stamp=" in row["ack"] else "applied"
        path = root / "ctl" / f"response.{row['request']}.{state}"
        assert path.read_text().strip() == row["ack"], path
    return len(replies)


def arm_data(name, wrapper_receipt=True, run_path=None):
    path = ROOT / name if run_path is None else run_path
    codes = ("runner", "play", "probe") if wrapper_receipt else ("play","probe")
    for code in codes:
        assert (path / (code + "_exit.txt")).read_text().strip() == "0", (name, code)
    if not wrapper_receipt:
        assert not (path/"runner_exit.txt").exists()
        assert (path/"result.txt").read_text().strip() == "done"
    assert not (path / "frontend.bag.active").exists(), name
    tail = json.loads((path / "tail_status.json").read_text())["ack"]
    assert integer(tail, "stamp_ns") >= TAIL_MARK_NS
    relay = read_jsonl(path / "relay_frames.jsonl")
    cohort = [(row["stamp_ns"], row["points"]) for row in relay]
    assert len(cohort) == POPULATION["scan_count"] and [t for t, _ in cohort] == sorted({t for t, _ in cohort})
    events = read_jsonl(path / "events_result.jsonl")
    assert [e["id"] for e in events] == [1, 2, 3]
    traces = read_jsonl(path / "ctl/lab_trace.jsonl")
    fates = read_jsonl(path / "ctl/input_fates.jsonl")
    updates = read_jsonl(path / "ctl/repair_updates.jsonl")
    actions = read_jsonl(path / "native_probe_actions.jsonl")
    relay_keys = [t for t, _ in cohort]
    first_fate = {}
    all_fates = Counter()
    for row in fates:
        all_fates[row["fate"]] += 1
        if row["fate"] != "replayed":
            stamp = nearest(relay_keys, round(row["beg_s"] * 1e9))
            if stamp is not None:
                first_fate[stamp] = row["fate"]
    acquisition = {}
    for segment in ("before", "E1", "between_E1_E2", "E2", "between_E2_E3", "E3", "after_E3"):
        segment_keys = [t for t in relay_keys if phase(t) == segment]
        acquisition[segment] = {
            "relayed": len(segment_keys),
            "fates": dict(Counter(first_fate.get(t, "no_native_update_receipt") for t in segment_keys)),
        }
    verified_replies = receipts(path, actions)
    trace_by = {(e["id"], branch): [r for r in traces if r["episode"] == e["id"] and r["arm"] == branch]
                for e in events for branch in ("raw", "candidate", "quarantined")}

    public = {}
    published_times = {}
    with rosbag.Bag(str(path / "frontend.bag")) as bag:
        for _, msg, record_time in bag.read_messages(topics=["/Odometry"]):
            stamp = msg.header.stamp.to_nsec()
            assert stamp not in public, (name, stamp)
            public[stamp] = msg_pose(msg)
            published_times[stamp] = record_time.to_nsec()

    selected_pose = dict(public)
    marks = {row["slot"]: row for row in read_jsonl(path / "ctl/map_measurements.jsonl")}
    assert sorted(marks) == (list(range(1, 8)) if name in ("clean", "native") else [7])
    for slot, entry in marks.items():
        assert entry["ok"] and entry["points"] == len(map_points(path / "ctl" / f"M{slot}.xyz32"))

    maps = {}
    event_output = []
    last_release = None
    scan_cutoffs = []
    for window, event in zip(WINDOWS, events):
        idx = event["id"]
        wanted = [row for row in FROZEN if row["event"] == idx]
        actual = [row for row in relay if row["event"] == idx]
        assert len(wanted) == len(actual) == window["frames"]
        assert [row["stamp_ns"] for row in wanted] == [row["stamp_ns"] for row in actual]
        assert [row["data_sha256"] for row in actual] == [
            row["reference_sha" if name == "clean" else "input_sha"] for row in wanted]
        shifts = [row["shifted"] for row in actual]
        assert all(shifts) if (window["inject_z_m"] and name != "clean") else not any(shifts)
        expected = [row["stamp_ns"] for row in wanted]
        if name in ("native", "clean"):
            assert not traces and not updates
            assert not any(row.get("sent") in ("hold", "restore", "reprocess") for row in actions)
            maps[idx] = (path / "ctl" / f"M{2*idx-1}.xyz32", path / "ctl" / f"M{2*idx}.xyz32")
            pre, post = (marks[2 * idx - 1]["stamp_ns"], marks[2 * idx]["stamp_ns"])
            scan_cutoffs.append(post)
            event_output.append({"id": idx, "decision": event["decision"], "selected_arm": "live",
                                 "checkpoint_ns": pre, "ending_map_ns": post, "written_candidates": 0,
                                 "relayed_inputs": len(expected),
                                 "native_update_receipts": sum(t in first_fate for t in expected)})
            continue

        cp = event["checkpoint_stamp_ns"]
        assert cp < window["onset_ns"] and (last_release is None or last_release < cp)
        release = integer(event["release"], "stamp_ns")
        assert "map_writes=released" in event["release"]
        selected = event["selected_arm"]
        raw = trace_by[idx, "raw"]
        cand = trace_by[idx, "candidate"]
        learned = trace_by[idx, "quarantined"]
        run_trace = raw or learned
        gids = [r["scan_stamp_ns"] for r in run_trace]
        assert gids == sorted(set(gids))
        assert all(nearest(gids, stamp) is not None for stamp in expected)
        assert not any(r["replacement"] for r in run_trace)
        if name in ("forced", "gated"):
            assert event["offered_candidate_message_sha256"] == [row["candidate_message_sha"] for row in wanted]
        if cand:
            assert [r["scan_stamp_ns"] for r in cand] == gids
            replaced = [r["scan_stamp_ns"] for r in cand if r["replacement"]]
            assert len(replaced) == len(expected) and all(nearest(replaced, stamp) is not None for stamp in expected)
        actual_updates = [r for r in updates if nearest(expected, r["scan_stamp_ns"]) is not None]
        if cand:
            assert [r["scan_stamp_ns"] for r in actual_updates] == replaced
            assert [r["map_update_count"] for r in actual_updates] == list(range(1, 1 + len(replaced)))
        else:
            assert not actual_updates
        selected_rows = trace_by.get((idx, selected), [])
        if selected != "restored":
            assert selected_rows and abs(release - selected_rows[-1]["stamp_ns"]) <= GROUP_TOLERANCE
        else:
            assert abs(release - cp) <= GROUP_TOLERANCE
        first, last = run_trace[0]["stamp_ns"], run_trace[-1]["stamp_ns"]
        assert not any(first - GROUP_TOLERANCE <= stamp <= last + GROUP_TOLERANCE for stamp in public)
        for row in selected_rows:
            selected_pose[row["stamp_ns"]] = xyz_pose(row)
        maps[idx] = (path / "ctl" / f"E{idx}_checkpoint.xyz32",
                     path / "ctl" / f"E{idx}_{event['selected_map']}.xyz32")
        observed_after = [r["stamp_ns"] for r in fates if r["fate"] == "ingested" and r["stamp_ns"] > last]
        next_cp = events[idx]["checkpoint_stamp_ns"] if idx < len(events) else math.inf
        ingested = sum(t <= next_cp for t in observed_after)
        assert ingested > 0, (name, idx)
        assert last >= event["expected_cut_ns"] and last <= event["expected_cut_ns"] + 150_000_000
        before_odom = max(stamp for stamp in public if stamp < first - GROUP_TOLERANCE)
        after = [stamp for stamp in public if stamp > last + GROUP_TOLERANCE]
        assert after
        after_odom = min(after)
        start_cmd = next(r for r in actions if r.get("sent") == "lab_arm" and r["request"] >
                         next(p["request"] for p in actions if p.get("command") == "snapshot_applied"
                              and p.get("boundary_ns") == event["boundary_ns"]))
        release_ack = next(r for r in actions if r.get("ack") == event["release"])
        event_output.append({
            "id": idx, "decision": event["decision"], "selected_arm": selected,
            "checkpoint_ns": cp, "ending_map_ns": release, "observed_cut_ns": last,
            "verified_native_groups": len(gids), "native_candidate_trials": sum(r["replacement"] for r in cand),
            "written_candidates": len(expected) if selected == "candidate" else 0,
            "ingested_before_next_checkpoint_or_tail": ingested,
            "public_stamp_gap_s": (after_odom - before_odom) / 1e9,
            "public_record_gap_s": (published_times[after_odom] - published_times[before_odom]) / 1e9,
            "branch_and_release_monotonic_s": release_ack["monotonic_s"] - start_cmd["monotonic_s"],
            "gate": event.get("measurement"), "local_fit": event.get("candidate_map_score"),
        })
        scan_cutoffs.append(last)
        last_release = release

    return {"cohort": cohort, "public": public, "chosen": selected_pose, "traces": trace_by,
            "maps": maps, "tail_map": path / "ctl/M7.xyz32", "public_records": published_times,
            "cutoffs": scan_cutoffs,
            "stats": {"events": event_output, "same_branch_attested": name in ("forced", "gated"),
                      "tail_native_consumed_ns": integer(tail, "stamp_ns"), "tail_map_ns": marks[7]["stamp_ns"],
                      "recorded_odometry": len(public), "native_commands_verified": verified_replies,
                      "last_actual_public_pose_ns": max(public),
                      "last_actual_native_group_ns": max(row["stamp_ns"] for row in fates),
                      "relayed_frames": len(cohort), "relay_edge_ns": [cohort[0][0], cohort[-1][0]],
                      "acquisition_population_by_phase": acquisition, "all_native_fates": dict(all_fates)}}


def phase(stamp):
    for e in WINDOWS:
        if stamp < e["onset_ns"] - GROUP_TOLERANCE:
            return ("before", "between_E1_E2", "between_E2_E3")[e["id"] - 1]
        if stamp < e["end_ns"] - GROUP_TOLERANCE:
            return f"E{e['id']}"
    return "after_E3"


def metric_panels(names, by, transforms, pose_key, shared):
    reference = by["clean"]["public"]
    indexes = {a: sorted(by[a][pose_key]) for a in names}
    error_maps = {a: {} for a in names}
    for stamp, target in sorted(reference.items()):
        match = {a: nearest(indexes[a], stamp) for a in names}
        if shared and any(t is None for t in match.values()):
            continue
        for a, t in match.items():
            if t is not None:
                error_maps[a][stamp] = fits(by[a][pose_key], t, transforms[a], target)
    panels = {}
    phases = ("before", "E1", "between_E1_E2", "E2", "between_E2_E3", "E3", "after_E3", "post_E1")
    for a, errors in error_maps.items():
        panels[a] = {}
        for p in phases:
            row_stamps = [s for s in errors if phase(s) == p or (p == "post_E1" and phase(s) != "before")]
            pos, rot = ([errors[t][i] for t in row_stamps] for i in (0, 1))
            population = sum(phase(s) == p or (p == "post_E1" and phase(s) != "before") for s in reference)
            panels[a][p] = {
                "position_m": describe(pos), "rotation_deg": describe(rot),
                "reference_pose_population": population, "unmatched_reference_poses": population - len(row_stamps),
            }
    return panels, error_maps


def aligned_voxels(path, transform):
    pts = map_points(path)
    return map_voxels(pts @ transform[:3, :3].T + transform[:3, 3])


def near(voxel, target):
    x, y, z = voxel
    for a, b, c in SHIFT_OFFSETS:
        if (x + a, y + b, z + c) in target:
            return True
    return False


def map_delta(pre, final, ref_pre, ref_final):
    addition, ref_add = final - pre, ref_final - ref_pre
    return {
        "before_voxels": len(pre), "final_voxels": len(final), "added_voxels": len(addition),
        "removed_voxels": len(pre - final), "reference_new_voxels": len(ref_add),
        "previous_reference_supported_voxels_lost_exact": len((pre & ref_final) - final),
        "previous_reference_supported_voxels_lost_26_neighbor": sum(
            not near(v, final) for v in (pre & ref_final) - final),
        "exact_occupied_matches": len(addition & ref_final),
        "reference_new_exact_recovered": len(ref_add & addition),
        "added_unsupported_26_neighbor": sum(not near(v, ref_final) for v in addition),
        "reference_new_covered_by_final_26_neighbor": sum(near(v, final) for v in ref_add),
    }


def paired_branches(by, transforms):
    results = {}
    for name in ("forced", "gated"):
        results[name] = {}
        for idx in (1, 2, 3):
            trace_by = by[name]["traces"]
            root = ROOT / name / "ctl"
            raw, cand = trace_by[idx, "raw"], trace_by[idx, "candidate"]
            if not cand:
                continue
            refs = by["clean"]["public"]
            ref_keys = sorted(refs)
            p = {}
            for label, trace in (("raw", raw), ("candidate", cand)):
                errs = []
                for line in trace:
                    stamp = line["stamp_ns"]
                    match = nearest(ref_keys, stamp)
                    if match is None or phase(stamp) != f"E{idx}":
                        continue
                    errs.append(fits({stamp: xyz_pose(line)}, stamp, transforms[name], refs[match])[0])
                p[label] = {"position_m": describe(errs)}
                pre = aligned_voxels(root / f"E{idx}_checkpoint.xyz32", transforms[name])
                final = aligned_voxels(root / f"E{idx}_{label}.xyz32", transforms[name])
                ref_pre, ref_final = (aligned_voxels(path, np.eye(4)) for path in by["clean"]["maps"][idx])
                p[label]["map_delta"] = map_delta(pre, final, ref_pre, ref_final)
            results[name][idx] = p
    return results


def main():
    if len(sys.argv) > 1:
        for name in sys.argv[1:]:
            one = arm_data(name)
            print(json.dumps(one["stats"]))
        return
    by = {a: arm_data(a) for a in ARMS}
    assert all(x["cohort"] == by["clean"]["cohort"] for x in by.values())
    for idx in range(3):
        times = [by[a]["cutoffs"][idx] for a in ARMS]
        assert max(times) - min(times) <= 150_000_000, times
    public_indexes = {a: sorted(by[a]["public"]) for a in ARMS}
    ref = by["clean"]["public"]
    for anchor in reversed(public_indexes["clean"]):
        if anchor > ANCHOR_CEILING:
            continue
        matches = {a: nearest(index, anchor) for a, index in public_indexes.items()}
        if all(t is not None for t in matches.values()):
            break
    else:
        raise ValueError("no common pre-event alignment stamp")
    transforms = {a: ref[anchor] @ np.linalg.inv(by[a]["public"][t]) for a, t in matches.items()}
    aggregates = {}
    series = {}
    for name, key, shared in (("selected_common", "chosen", True), ("selected_pairwise", "chosen", False),
                              ("public_common", "public", True), ("public_pairwise", "public", False)):
        aggregates[name], series[name] = metric_panels(ARMS, by, transforms, key, shared)
    map_metrics = {}
    for name in ARMS:
        map_metrics[name] = {}
        align = transforms[name]
        for idx, (pre_path, post_path) in by[name]["maps"].items():
            pre, post = (aligned_voxels(p, align) for p in (pre_path, post_path))
            ref_pre, ref_post = (aligned_voxels(p, np.eye(4)) for p in by["clean"]["maps"][idx])
            map_metrics[name][idx] = map_delta(pre, post, ref_pre, ref_post)
        final = aligned_voxels(by[name]["tail_map"], align)
        ref_final = aligned_voxels(by["clean"]["tail_map"], transforms["clean"])
        map_metrics[name]["tail"] = {
            "voxels": len(final), "reference_voxels": len(ref_final),
            "global_iou": len(final & ref_final) / len(final | ref_final),
            "map_stamp_ns": by[name]["stats"]["tail_map_ns"],
        }
    selected = aggregates["selected_common"]
    forced_e3, gated_e3 = (by[name]["stats"]["events"][2] for name in ("forced", "gated"))
    paired = paired_branches(by, transforms)
    e3_pair = paired["forced"][3]
    result = {"anchor_ns": anchor, "transforms": {a: t.tolist() for a, t in transforms.items()},
              "population_identical": True, "identical_offered_messages": len(FROZEN),
              "arms": {name: data["stats"] for name, data in by.items()},
              "trajectory": aggregates, "map": map_metrics, "paired_native_branches": paired,
              "stress": {
                  "forced_committed": forced_e3["written_candidates"],
                  "gated_committed": gated_e3["written_candidates"],
                  "same_checkpoint_stale_worsened_position": e3_pair["candidate"]["position_m"]["rmse"] >
                                                             e3_pair["raw"]["position_m"]["rmse"],
                  "gated_beats_forced_e3_selected_rmse": selected["gated"]["E3"]["position_m"]["rmse"] <
                                                       selected["forced"]["E3"]["position_m"]["rmse"],
              }}
    with (ROOT / "evaluation.json").open("x") as out:
        json.dump(result, out, indent=2, allow_nan=False)
    with (ROOT / "trajectory_matches.jsonl").open("x") as out:
        for kind, arms in series.items():
            for arm, points in arms.items():
                for stamp, (position, rotation) in points.items():
                    out.write(json.dumps({"series": kind, "arm": arm, "stamp_ns": stamp, "phase": phase(stamp),
                                          "position_m": position, "rotation_deg": rotation}) + "\n")


if __name__ == "__main__":
    main()
