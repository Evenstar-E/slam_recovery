"""Verify native closure and compare active trajectories using a pre-E1 anchor."""
from bisect import bisect_left
from pathlib import Path
import json
import re

import numpy as np
import rosbag

from slam_recovery.ros.recovery_node import pose_to_matrix


ROOT=Path(__file__).resolve().parent
ARMS=("clean","injected","repair")
TOLERANCE_NS=1024


def read_jsonl(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def integer(ack, field):
    return int(re.search(r"\b"+field+r"=(-?\d+)",ack).group(1))


def nearest(keys, stamp, tolerance=TOLERANCE_NS):
    i=bisect_left(keys,stamp)
    options=keys[max(0,i-1):i+1]
    if not options:
        return None
    best=min(options,key=lambda key:abs(key-stamp))
    return best if abs(best-stamp)<=tolerance else None


def metrics(values):
    if len(values)==0:
        return {"matched":0}
    return {"matched":len(values),"rmse":float(np.sqrt(np.mean(values**2))),
            "p95":float(np.quantile(values,.95)),"max":float(values.max()),
            "final":float(values[-1])}


def msg_pose(msg):
    p,q=msg.pose.pose.position,msg.pose.pose.orientation
    return pose_to_matrix((p.x,p.y,p.z),(q.x,q.y,q.z,q.w))


def map_voxels(points):
    return {tuple(row) for row in np.floor(points/.5).astype(np.int64)}


def map_points(path):
    pts=np.fromfile(str(path),"<f4").reshape(-1,3)
    if not np.isfinite(pts).all() or not len(pts):
        raise ValueError(f"invalid persisted native map {path}")
    return pts


def verify_arm(name,windows):
    root=ROOT/name
    outputs={}
    for f in ("runner_exit","probe_exit","play_exit"):
        path=root/(f+".txt")
        outputs[f]=int(path.read_text()) if path.is_file() else None
    tail_file=root/"tail_status.json"
    ack=json.loads(tail_file.read_text())["ack"] if tail_file.is_file() else ""
    relay=read_jsonl(root/"relay_frames.jsonl")
    events=read_jsonl(root/"events_result.jsonl")
    traces=read_jsonl(root/"ctl/lab_trace.jsonl")
    fates=read_jsonl(root/"ctl/input_fates.jsonl")
    map_exports={}
    active_pose={}
    last_recorded_odom=None
    with rosbag.Bag(str(root/"frontend.bag")) as bag:
        for _,msg,_ in bag.read_messages(topics=["/Odometry"]):
            stamp=msg.header.stamp.to_nsec()
            last_recorded_odom=stamp
            active_pose[stamp]=msg_pose(msg)
    actions=read_jsonl(root/"native_probe_actions.jsonl")
    sent=[r for r in actions if "sent" in r]
    replies=[r for r in actions if "command" in r and r["command"]!="snapshot_applied"]
    assert [r["request"] for r in sent]==list(range(1,len(sent)+1))
    assert [(r["request"],r["sent"]) for r in sent]==[(r["request"],r["command"]) for r in replies]
    for r in replies:
        suffix="deferred" if " deferred stamp=" in r["ack"] else "applied"
        disk=root/"ctl"/f"response.{r['request']}.{suffix}"
        assert disk.read_text().strip()==r["ack"]
    applied=[r for r in actions if r.get("command")=="snapshot_applied"]
    assert len(applied)==2
    for r in applied:
        disk=root/"ctl"/f"response.{r['request']}.applied"
        assert disk.read_text().strip()==r["ack"]
    event_slots=[]
    for window,event in zip(windows,events):
        idx=window["id"]
        assert idx==event["id"] and event["checkpoint_stamp_ns"]<window["onset_ns"]
        selected=event["selected_arm"]
        raw=[r for r in traces if r["episode"]==idx and r["arm"]=="raw"]
        candidate=[r for r in traces if r["episode"]==idx and r["arm"]=="candidate"]
        stamps=[r["stamp_ns"] for r in relay if r["event"]==idx]
        corrupted=[r["stamp_ns"] for r in relay if r["event"]==idx and r["shifted"]]
        expected=event["stamps_ns"]
        assert len(expected)==60 and stamps==expected
        assert corrupted==([] if name=="clean" else expected)
        raw_scan=[r["scan_stamp_ns"] for r in raw]
        assert len(set(raw_scan))==len(raw_scan)==event["raw"]["groups"]
        updated=0
        if candidate:
            assert [r["scan_stamp_ns"] for r in candidate]==raw_scan
            updated=sum(r["replacement"] for r in candidate)
            assert updated==len(expected)==event["candidate"]["updated"]
            assert all(nearest(expected,r["scan_stamp_ns"]) is not None for r in candidate if r["replacement"])
        cutoff=integer(event["release"],"stamp_ns")
        assert "map_writes=released" in event["release"]
        # Private native traces supply only the selected history. The public stream must
        # remain silent for every staged group, and then resume from the selected state.
        first,end=raw[0]["stamp_ns"],raw[-1]["stamp_ns"]
        leaked=[t for t in active_pose if first-TOLERANCE_NS<=t<=end+TOLERANCE_NS]
        assert not leaked, f"{name} E{idx} published {len(leaked)} uncommitted poses"
        if selected in ("raw","candidate"):
            rows=raw if selected=="raw" else candidate
            assert abs(cutoff-rows[-1]["stamp_ns"])<=TOLERANCE_NS
            for item in rows:
                v=item["pose"]
                active_pose[item["stamp_ns"]]=pose_to_matrix(v[:3],v[3:])
            map_exports[idx]=map_points(root/"ctl"/f"E{idx}_{selected}.xyz32")
        else:
            assert selected=="restored" and abs(cutoff-event["checkpoint_stamp_ns"])<=TOLERANCE_NS
        event_slots.append({"id":idx,"event_scans":len(expected),"injected_scans":len(corrupted),
                            "candidate_native_updates":updated,"committed_repaired_frames":updated if selected=="candidate" else 0,
                            "decision":event["decision"],"selected_arm":selected,
                            "checkpoint_ns":event["checkpoint_stamp_ns"],"release_ns":cutoff,
                            "factual_cache_released":event["released_event_cache_scans"],
                            "raw":event["raw"],"candidate":event.get("candidate"),
                            "raw_map":event.get("raw_map"),"candidate_map":event.get("candidate_map"),
                            "wilson":event.get("odd_wilson_lower_bound"),"beam_band":event.get("all_repair_returns_in_healthy_band"),
                            "map_check":event.get("local_map_check_pass")})
    events_complete=len(events)==len(event_slots)==2
    if events_complete:
        e1,e2=event_slots
        assert e1["checkpoint_ns"]<=e1["release_ns"]<e2["checkpoint_ns"]<windows[1]["onset_ns"]
        group_between=sum(r["fate"]=="ingested" and e1["release_ns"]<r["stamp_ns"]<=e2["checkpoint_ns"] for r in fates)
        tail_count=sum(r["fate"]=="ingested" and r["stamp_ns"]>e2["release_ns"] for r in fates)
    else:
        group_between=tail_count=0
    return ({
        **outputs, "confirmed_events":events_complete,"events":event_slots,
        "ingested_between_e1_release_and_e2_checkpoint":group_between,
        "ingested_after_e2_release":tail_count,
        "tail_ack":ack,
        "last_live_odom_ns":last_recorded_odom,
        "correlated_responses_verified":len(replies),
        "snapshot_applications_verified":len(applied),
        "published_provisional_poses":0,
        "relayed_frames":len(relay)}, active_pose,map_exports)


def main():
    windows=json.loads((ROOT/"events.json").read_text())
    per_arm={}
    poses={}
    maps={}
    for name in ARMS:
        per_arm[name],poses[name],maps[name]=verify_arm(name,windows)
    input_stamps={
        name: [(row["stamp_ns"],row["points"]) for row in read_jsonl(ROOT/name/"relay_frames.jsonl")]
        for name in ARMS
    }
    identical_inputs=all(seq==input_stamps["clean"] for seq in input_stamps.values())
    event_measurement_sets={
        name: [row["stamps_ns"] for row in read_jsonl(ROOT/name/"events_result.jsonl")]
        for name in ARMS
    }
    assert all(x==event_measurement_sets["clean"] for x in event_measurement_sets.values())
    key_index={name:sorted(poses[name]) for name in ARMS}
    common=[]
    for t in key_index["clean"]:
        times={name:nearest(key_index[name],t) for name in ARMS}
        if all(x is not None for x in times.values()):
            common.append((t,times))

    anchor_at=min(a["events"][0]["checkpoint_ns"] for a in per_arm.values())
    anchor,times=next((t,p) for t,p in reversed(common) if t<=anchor_at+TOLERANCE_NS)
    trans={name:poses["clean"][anchor]@np.linalg.inv(poses[name][times[name]]) for name in ARMS}
    e1,e2=windows
    phase_names=("before","E1","between","E2","tail")
    error_sections={}
    serial=[]
    for name in ARMS:
        phase_errors={phase:[] for phase in phase_names}
        angles={phase:[] for phase in phase_names}
        error_sections[name]={}
        for t,pair in common:
            X=trans[name]@poses[name][pair[name]]
            Y=poses["clean"][t]
            err=np.linalg.norm(X[:3,3]-Y[:3,3])
            c=np.clip((np.trace(X[:3,:3].T@Y[:3,:3])-1)/2,-1,1)
            angle=np.rad2deg(np.arccos(c))
            phase=("before" if t<e1["onset_ns"]-TOLERANCE_NS else
                   "E1" if t<e1["end_ns"]-TOLERANCE_NS else
                   "between" if t<e2["onset_ns"]-TOLERANCE_NS else
                   "E2" if t<e2["end_ns"]-TOLERANCE_NS else "tail")
            phase_errors[phase].append(err)
            angles[phase].append(angle)
            serial.append({"arm":name,"stamp_ns":t,"position_error_m":float(err),"phase":phase})
        for phase in phase_names:
            error_sections[name][phase]={"position_m":metrics(np.asarray(phase_errors[phase])),
                                         "rotation_deg":metrics(np.asarray(angles[phase]))}
        m={}
        for eid in sorted(set(maps["clean"]) & set(maps[name])):
            target=map_voxels(maps["clean"][eid])
            x=maps[name][eid]
            aligned=x@trans[name][:3,:3].T+trans[name][:3,3]
            pts=map_voxels(aligned)
            m[eid]={"iou":len(target & pts)/len(target | pts),"reference_voxels":len(target),"actual_voxels":len(pts)}
        error_sections[name]["map_voxels_at_release"]=m

    # Within the repair run, each episode produced two candidates from its
    # identical checkpoint. The clean run is an evaluation-only outcome.
    within_checkpoint={}
    repair_trace=read_jsonl(ROOT/"repair"/"ctl/lab_trace.jsonl")
    for event,stamps in enumerate(event_measurement_sets["repair"],start=1):
        variants={name:{} for name in ("raw","candidate")}
        for row in repair_trace:
            if row["episode"]!=event:
                continue
            ns=nearest(stamps,row["scan_stamp_ns"])
            if ns is not None:
                variants[row["arm"]][ns]=row["pose"]
        support=[ns for ns in stamps if all(ns in v for v in variants.values())
                 and nearest(key_index["clean"],ns) is not None]
        within_checkpoint[event]={}
        for name,p in variants.items():
            errors=[]
            for ns in support:
                q=p[ns]
                candidate=trans["repair"]@pose_to_matrix(q[:3],q[3:])
                ref=poses["clean"][nearest(key_index["clean"],ns)]
                errors.append(np.linalg.norm(candidate[:3,3]-ref[:3,3]))
            within_checkpoint[event][name]=metrics(np.asarray(errors))

    repaired=per_arm["repair"]
    eligible=(all(a["runner_exit"]==a["probe_exit"]==a["play_exit"]==0 for a in per_arm.values())
              and all(r["confirmed_events"] for r in per_arm.values())
              and all(r["committed_repaired_frames"]==60 and r["map_check"] and r["beam_band"]
                      and r["decision"]=="ACCEPT_BIAS_CORRECTION" for r in repaired["events"])
              and repaired["ingested_between_e1_release_and_e2_checkpoint"]>0
              and repaired["ingested_after_e2_release"]>0
              and bool(repaired["tail_ack"]))
    calibration=json.loads((ROOT/"calibration.json").read_text())
    control_rows=read_jsonl(ROOT/"clean"/"events_result.jsonl")
    beam_limit=calibration["maximum_healthy_odd_m"]+1e-5
    maximum_control_bias=max(abs(b) for row in control_rows for b in row["bias_m"])
    assert maximum_control_bias<beam_limit
    report={"frozen_calibration":calibration,"maximum_control_bias_m":maximum_control_bias,
            "beam_limit_m":beam_limit,"phase_metrics":error_sections,
            "within_repair_checkpoint_comparison":within_checkpoint,"runs":per_arm,"common_pose_count":len(common),
            "anchor_stamp_ns":anchor,"alignment_transforms":{k:x.tolist() for k,x in trans.items()},
            "identical_input_scan_stamps_and_point_count":identical_inputs,
            "poses_available_by_arm":{name:len(keys) for name,keys in key_index.items()},
            "matched_pose_fraction_by_arm":{name:len(common)/len(keys) for name,keys in key_index.items()},
            "two_event_native_success":eligible,
            "scope":"controlled scripted sensor-bias recovery, separate admission mode, original weak-direction gate intact"}
    (ROOT/"closure_verification.json").write_text(json.dumps(report,indent=2,allow_nan=False)+"\n")
    (ROOT/"trajectory_errors.jsonl").write_text("".join(json.dumps(r)+"\n" for r in serial))
    print("two_event_native_success",eligible,"common",len(common),"anchor",anchor)
    for name in ARMS:
        print(name,[x["decision"] for x in per_arm[name]["events"]],
              "live",per_arm[name]["ingested_between_e1_release_and_e2_checkpoint"],
              per_arm[name]["ingested_after_e2_release"],
              "rmse",{k:round(v["position_m"].get("rmse",0),6) for k,v in error_sections[name].items() if "position_m" in v},
              "map",error_sections[name]["map_voxels_at_release"])


if __name__=="__main__":
    main()
