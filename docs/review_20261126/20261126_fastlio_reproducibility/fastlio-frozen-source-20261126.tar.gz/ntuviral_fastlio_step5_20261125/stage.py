"""Freeze the candidate stream before observing any four-policy outcome."""
import hashlib
from io import BytesIO
import json
import os
from pathlib import Path

import numpy as np
import rosbag
import rospy

from step3_controller import estimate, odd_error, shift_z_cloud

ROOT = Path(__file__).resolve().parent
INPUT = Path(os.environ["STEP5_INPUT"])
SOURCE = INPUT / "study.bag"
WINDOWS = json.loads((INPUT / "events.json").read_text())
MODEL = {int(key): tuple(value) for key, value in
         json.loads((ROOT / "beam_source.json").read_text())["calibration_model"].items()}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def message_sha(msg):
    buf = BytesIO()
    msg.serialize(buf)
    return sha(buf.getbuffer())


def main():
    path = INPUT / "frozen_candidates.bag"
    manifest = INPUT / "frozen_candidates.json"
    assert not path.exists() and not manifest.exists()
    rows = []
    stale = None
    with rosbag.Bag(str(SOURCE)) as source, rosbag.Bag(str(path), "w", compression="lz4") as target:
        for window in WINDOWS:
            ns_lo, ns_hi = window["onset_ns"], window["end_ns"]
            lo = rospy.Time.from_sec(ns_lo / 1e9 - 3)
            hi = rospy.Time.from_sec(ns_hi / 1e9 + 3)
            biases = []
            count = 0
            for _, clean, time in source.read_messages(
                    topics=["/velodyne_points"], start_time=lo, end_time=hi):
                stamp = clean.header.stamp.to_nsec()
                if not ns_lo <= stamp < ns_hi:
                    continue
                dz = window["inject_z_m"]
                delivered = shift_z_cloud(clean, dz) if dz else clean
                bias = estimate(delivered, MODEL)[0] if dz else stale
                corrected = shift_z_cloud(delivered, -bias)
                target.write("/velodyne_points", corrected, time)
                rows.append({
                    "event": window["id"], "stamp_ns": stamp, "bag_ns": time.to_nsec(),
                    "reference_sha": sha(clean.data), "input_sha": sha(delivered.data),
                    "candidate_data_sha": sha(corrected.data), "candidate_message_sha": message_sha(corrected),
                    "subtract_z_m": bias, "held_out_input_m": odd_error(delivered, MODEL),
                    "held_out_candidate_m": odd_error(corrected, MODEL),
                })
                biases.append(bias)
                count += 1
            assert count == window["frames"], (window["id"], count)
            if window["id"] == 2:
                stale = float(np.median(biases))
    assert len({row["stamp_ns"] for row in rows}) == len(rows)
    with rosbag.Bag(str(path)) as candidates:
        readback = [(msg.header.stamp.to_nsec(), time.to_nsec(), message_sha(msg))
                    for _, msg, time in candidates.read_messages()]
    assert readback == [(row["stamp_ns"], row["bag_ns"], row["candidate_message_sha"]) for row in rows]
    with manifest.open("x") as out:
        json.dump({"source": str(SOURCE), "stale_e2_bias_m": stale, "frames": rows}, out, indent=2, allow_nan=False)
        out.write("\n")


if __name__ == "__main__":
    main()
