"""Stage 5 preregistered independent-prism evaluation and all-slot ledger."""
from bisect import bisect_left
from collections import Counter
import csv
import json
import os
from pathlib import Path
import sys
import traceback

import numpy as np
import rosbag

from step3_verify import msg_pose, nearest, read_jsonl

ROOT = Path(__file__).resolve().parent
ARM_NAMES = ("clean", "native", "isolation", "forced", "gated")
DRIVES = ("eee_03", "sbs_02")
PRISM_IN_BODY = np.array([-0.293656, -0.012288, -0.273095])
NANOSECOND = 10**9


def summary(values):
    values = np.asarray(values)
    if not len(values):
        return {"n": 0}
    return {
        "n": len(values), "rmse_m": float(np.sqrt(np.mean(values**2))),
        "median_m": float(np.median(values)), "p95_m": float(np.quantile(values,.95)),
        "max_m": float(values.max()), "last_m": float(values[-1]),
    }


def read_gt(path):
    records = {}
    with path.open(newline="") as f:
        for row in csv.DictReader(f):
            stamp = int(row["field.header.stamp"])
            vector = np.array([float(row[f"field.pose.position.{axis}"]) for axis in "xyz"])
            assert stamp not in records and np.isfinite(vector).all()
            records[stamp] = vector
    pins = sorted(records)
    return pins, records


def interp(pins, records, stamp):
    idx = bisect_left(pins, stamp)
    if idx == len(pins):
        return None
    hi = pins[idx]
    if hi == stamp:
        return records[hi]
    if idx == 0 or hi - pins[idx-1] > 100_000_000:
        return None
    lo = pins[idx-1]
    a = (stamp-lo)/(hi-lo)
    return (1-a)*records[lo] + a*records[hi]


def fit(source, destination):
    if len(source) < 20:
        return None, {"matched": len(source), "failure": "fewer_than_20_prefix_pairs"}
    source = np.array(source)
    destination = np.array(destination)
    x, y = source - source.mean(0), destination - destination.mean(0)
    spreads = np.linalg.svd(y, compute_uv=False)
    span = float(np.max(np.linalg.norm(destination - destination[0], axis=1)))
    ratio = float(spreads[1] / spreads[0]) if spreads[0] else 0.0
    receipt = {"matched": len(source), "span_m": span, "singular_ratio": ratio}
    if span < .5 or ratio < .01:
        receipt["failure"] = "healthy_prefix_geometry_insufficient"
        return None, receipt
    u, _, vt = np.linalg.svd(x.T @ y)
    d = np.eye(3)
    d[2,2] = np.linalg.det(vt.T @ u.T)
    rotation = vt.T @ d @ u.T
    translation = destination.mean(0) - rotation @ source.mean(0)
    receipt.update(rotation=rotation.tolist(), translation=translation.tolist(),
                   prefix_rmse_m=summary(np.linalg.norm(source @ rotation.T+translation-destination,axis=1))["rmse_m"])
    return (rotation, translation), receipt


def prism(pose):
    return pose[:3,:3] @ PRISM_IN_BODY + pose[:3,3]


def metric_panel(predicted, expected):
    pos = {t: np.linalg.norm(predicted[t]-expected[t]) for t in sorted(predicted)}
    stamps = sorted(predicted)
    rpe = []
    for stamp in stamps:
        nxt = nearest(stamps, stamp+NANOSECOND, 50_000_000)
        if nxt is not None:
            rpe.append(np.linalg.norm(
                (predicted[nxt]-predicted[stamp])-(expected[nxt]-expected[stamp])))
    return {"ate": summary(list(pos.values())), "rpe_1s": summary(rpe)}


def use_transform(pose, transform):
    rotation, translation = transform
    return rotation @ prism(pose) + translation


def debug_arm(path):
    """Preserve evidence from an incomplete arm without claiming its replay passed."""
    data = {"public": {}, "events": [], "exit": {}, "relay_count": None}
    for label in ("runner", "probe", "play"):
        file = path / f"{label}_exit.txt"
        if file.is_file():
            data["exit"][label] = int(file.read_text())
    if (path/"relay_frames.jsonl").is_file():
        data["relay_count"] = len(read_jsonl(path/"relay_frames.jsonl"))
    if (path/"frontend.bag").is_file():
        with rosbag.Bag(str(path/"frontend.bag")) as bag:
            data["public"] = {msg.header.stamp.to_nsec(): msg_pose(msg)
                              for _,msg,_ in bag.read_messages(topics=["/Odometry"])}
    if (path/"events_result.jsonl").is_file():
        for row in read_jsonl(path/"events_result.jsonl"):
            data["events"].append({
                "id": row["id"], "decision": row["decision"],
                "selected_arm": row["selected_arm"],
                "candidate_native_updates": row.get("candidate",{}).get("updated",0),
                "release": row.get("release"),
            })
    fates = path/"ctl/input_fates.jsonl"
    if fates.is_file():
        history=[]
        malformed=[]
        for number,line in enumerate(fates.read_text().splitlines(),1):
            try:
                history.append(json.loads(line))
            except json.JSONDecodeError:
                malformed.append(number)
        data["malformed_native_fate_lines"] = malformed
        data["native_fates"] = dict(Counter(row["fate"] for row in history))
        data["last_native_update_ns"] = max((r["stamp_ns"] for r in history),default=None)
    actions = path/"native_probe_actions.jsonl"
    if actions.is_file():
        rows=read_jsonl(actions)
        replied={r["request"] for r in rows if "ack" in r}
        data["unanswered"]=[r for r in rows if "sent" in r and r["request"] not in replied]
        data["reprocess_acks"]=[r["ack"] for r in rows if r.get("command")=="reprocess"]
    received=path/"ctl/ack_received"
    if received.is_file():
        data["last_ack_received"] = received.read_text().strip()
    log = path / "probe.log"
    data["probe_tail"] = log.read_text(errors="replace").splitlines()[-9:] if log.is_file() else []
    return data


def phase(stamp, events):
    if stamp < events[0]["onset_ns"]:
        return "pre"
    for row in events:
        if stamp < row["onset_ns"]:
            return f"before_E{row['id']}"
        if stamp < row["end_ns"]:
            return f"E{row['id']}"
    return "tail"


def supported(poses, target_stamps, gt_pins, gt, tolerance=110_000_000):
    index = sorted(poses)
    samples = {}
    for target in target_stamps:
        stamp = nearest(index,target,tolerance)
        if stamp is not None:
            value = interp(gt_pins,gt,stamp)
            if value is not None and all(np.isfinite(poses[stamp].ravel())):
                samples[target] = (stamp, poses[stamp], value)
    return samples


def paired_raw_candidate(name, info, transform, events, pins, gt, xyz_pose):
    results = {}
    for row in events:
        idx = row["id"]
        raw = {r["scan_stamp_ns"]: r for r in info["traces"][idx, "raw"]}
        replaced = {r["scan_stamp_ns"]: r for r in info["traces"][idx, "candidate"] if r["replacement"]}
        if not replaced:
            continue
        assert len(replaced)==row["frames"] and replaced.keys() <= raw.keys()
        matching = [r for begin,r in sorted(replaced.items()) if interp(pins,gt,r["stamp_ns"]) is not None]
        reference = {r["stamp_ns"]: interp(pins,gt,r["stamp_ns"]) for r in matching}
        a = metric_panel({r["stamp_ns"]:use_transform(xyz_pose(raw[r["scan_stamp_ns"]]),transform)
                          for r in matching},reference)
        b = metric_panel({r["stamp_ns"]:use_transform(xyz_pose(r),transform) for r in matching},reference)
        tested = reference
        label = "UNCERTAIN_SUPPORT"
        if len(tested)>=20 and len(tested)>=0.5*row["frames"]:
            initial, final = a["ate"]["rmse_m"], b["ate"]["rmse_m"]
            delta = initial-final
            label = ("BENEFICIAL" if delta>=.05 and delta>=.05*initial else
                     "HARMFUL" if delta<=-.05 and -delta>=.05*initial else "BELOW_PRACTICAL_THRESHOLD")
        results[idx] = {"label": label, "raw": a, "candidate": b, "expected_frames": row["frames"]}
    return results


def evaluate_drive(name, csv_rows, corrected=False):
    source = ROOT / name
    if not (source/"frozen_candidates.json").is_file():
        return {"status": "DATA_UNAVAILABLE_OR_UNQUALIFIED",
                "runs": {rep: {key: {"status": "NOT_STARTED", "events": []} for key in ARM_NAMES}
                         for rep in ("r1","r2")}}
    os.environ["STEP5_INPUT"] = str(source)
    events = json.loads((source/"events.json").read_text())
    population = json.loads((source/"population.json").read_text())
    scan_stamps = population["scan_stamps_ns"]
    origin = population["start_ns"]
    pins, gt = read_gt(ROOT/"incoming"/f"{name}_gt.csv")
    report = {"status": "DATA_QUALIFIED", "population": population, "events": events,
              "gt": {"positions":len(pins),"start_ns":pins[0],"end_ns":pins[-1]}, "runs": {}}
    for rep in ("r1","r2"):
        os.environ["STEP5_RUN"] = str(source / rep)
        for key in ("evaluate", "stage", "controller"):
            sys.modules.pop(key, None)
        # The inherited probe adds the three archived roots to sys.path.
        # Its archived stage.py is a different module from the frozen driver.
        sys.path[:] = [str(ROOT)] + [p for p in sys.path if p != str(ROOT)]
        from evaluate import arm_data, xyz_pose, map_delta, aligned_voxels
        run = {}
        report["runs"][rep] = run
        checked = {}
        for key in ARM_NAMES:
            path = source / rep / key
            alternative = ROOT / "exact" / name / rep / key
            if corrected and alternative.is_dir():
                path = alternative
            if not path.exists():
                run[key] = {"status":"NOT_STARTED","events":[]}
                continue
            fallback = debug_arm(path)
            val = {"status":"INCOMPLETE_NATIVE", "source_run":str(path), "exact_lookup":path==alternative,
                   **{k:v for k,v in fallback.items() if k!="public"},
                   "public_messages":len(fallback["public"])}
            run[key] = val
            known_wrapper_failure = (
                (name,rep,key)==("eee_03","r1","isolation")
                and any(line.endswith("eee_03 r1 END isolation 1")
                        for line in (ROOT/"suite.log").read_text().splitlines())
            )
            try:
                info = arm_data(key, wrapper_receipt=not known_wrapper_failure, run_path=path)
                if [s for s,_ in info["cohort"]] != scan_stamps:
                    raise ValueError("relay measurement population differs from frozen source")
            except Exception:
                val["verification_failure"]=traceback.format_exc(limit=3).splitlines()[-6:]
            else:
                val.update(status="VERIFIED_NATIVE_WRAPPER_FAILURE" if known_wrapper_failure else "VERIFIED_NATIVE",
                           arm=info["stats"])
                checked[key]=info
        if not checked:
            continue
        if "clean" in checked:
            ref=checked["clean"]["public"]
        else:
            ref={}
        # Use sensor slots from the frozen source. One LiDAR end estimate commonly
        # lies about one scan duration after its begin stamp. Keys below are the
        # estimator's actual timestamps, matched across arms within 2 ms.
        keys = sorted(ref or next(iter(checked.values()))["public"])
        prefix_targets = [t for t in keys if origin+population.get("alignment_start_s",5)*NANOSECOND <= t < origin+population.get("alignment_end_s",29)*NANOSECOND]
        matches = {a:supported(v["public"],prefix_targets,pins,gt,2_000_000) for a,v in checked.items()}
        shared = sorted(set.intersection(*(set(v) for v in matches.values())))
        transforms={}
        for key in checked:
            est = [prism(matches[key][t][1]) for t in shared]
            truth = [matches[key][t][2] for t in shared]
            trans, receipt = fit(est,truth)
            run[key]["alignment"] = receipt
            if trans is not None:
                transforms[key]=trans
        mode = "v1_independent_prefix" if name=="eee_03" else "amended_qualified_independent_prefix"
        if not transforms and ref:
            clean_alignment = {t:(p,g) for t,p in ref.items()
                               if origin+34*NANOSECOND <= t < origin+53*NANOSECOND
                               and (g:=interp(pins,gt,t)) is not None}
            alternative, quality = fit([prism(p) for p,_ in clean_alignment.values()],
                                       [g for _,g in clean_alignment.values()])
            stationary = [t for t in sorted(ref) if t <= events[0]["onset_ns"]-4*NANOSECOND]
            indexes = {a:sorted(item["public"]) for a,item in checked.items()}
            anchor = None
            for t in reversed(stationary):
                match = {a:nearest(k,t,2_000_000) for a,k in indexes.items()}
                if all(stamp is not None for stamp in match.values()):
                    anchor = (t, match)
                    break
            if alternative is not None and anchor is not None:
                t, match = anchor
                world_r,world_t = alternative
                for a,item in checked.items():
                    local=ref[t] @ np.linalg.inv(item["public"][match[a]])
                    transforms[a]=(world_r@local[:3,:3], world_r@local[:3,3]+world_t)
                    run[a]["secondary_alignment"]={"clean_fit":quality,"pre_E1_anchor_ns":t}
                mode = "secondary_clean_reference_anchor"
        for key in transforms:
            run[key]["metric_alignment_mode"]=mode
        eligible = {k:checked[k] for k in transforms}
        if not eligible:
            continue
        desired = [t for t in scan_stamps if t>=events[0]["onset_ns"]]
        coverage = [t for t in desired if interp(pins,gt,t) is not None]
        targets = sorted({t for item in eligible.values() for t in item["chosen"]
                          if t>=events[0]["onset_ns"]})
        for series in ("chosen","public"):
            grouped={k:supported(v[series],targets,pins,gt,2_000_000) for k,v in eligible.items()}
            common=sorted(set.intersection(*(set(v) for v in grouped.values())))
            if "clean" in grouped and len(grouped)>1:
                common = [t for t in common if t in grouped["clean"]]
            # Prefer the clean or first-arm stamp grid. This avoids counting
            # several tiny cross-arm timestamp offsets as independent samples.
            canon = grouped.get("clean",next(iter(grouped.values())))
            common = [t for t in common if canon[t][0]==t]
            for key, series_map in grouped.items():
                unique = {stamp:(pose,value) for stamp,pose,value in series_map.values()}
                comparable = {t:series_map[t] for t in common}
                row = {
                    "desired_scan_slots_post_E1":len(desired),
                    "with_gt_bracket_at_scan_header":len(coverage),
                    "estimate_samples_with_gt":len(unique), "common_across_available_arms":len(comparable),
                    "common_includes_all_five": len(eligible)==5,
                    "common": {},
                    "pairwise": {},
                }
                for section in ("post_E1","E1","before_E2","E2","before_E3","E3","tail"):
                    def include(t):
                        return section=="post_E1" or phase(t,events)==section
                    row["common"][section] = metric_panel(
                        {t:use_transform(pose,transforms[key]) for t,(_,pose,_) in comparable.items() if include(t)},
                        {t:value for t,(_,_,value) in comparable.items() if include(t)})
                    row["pairwise"][section] = metric_panel(
                        {t:use_transform(pose,transforms[key]) for t,(pose,_) in unique.items() if include(t)},
                        {t:value for t,(_,value) in unique.items() if include(t)})
                if series == "chosen":
                    csv_rows.extend(("exact_comparison" if corrected else "original",name,rep,key,t,phase(t,events),
                                     float(np.linalg.norm(use_transform(pose,transforms[key])-value)))
                                    for t,(_,pose,value) in comparable.items())
                run[key][series]=row
        for key in ("forced","gated"):
            if key in eligible:
                run[key]["paired_candidate_quality"]=paired_raw_candidate(
                    name, eligible[key], transforms[key], events, pins, gt, xyz_pose)
        if ref:
            # Map proxy uses a common pre-event host pose. Ground truth for the
            # trajectory is never repurposed into a surveyed surface.
            for key, item in eligible.items():
                ids=sorted(item["public"])
                pre_map=[t for t in sorted(ref) if t<=events[0]["onset_ns"]-4*NANOSECOND]
                anchor=next(((t,near) for t in reversed(pre_map)
                             if (near:=nearest(ids,t,2_000_000)) is not None),None)
                if anchor is None:
                    continue
                t,near=anchor
                pose_transform=ref[t]@np.linalg.inv(item["public"][near])
                run[key]["map_clean_proxy"]={}
                for idx in item["maps"]:
                    before, after = (aligned_voxels(p,pose_transform) for p in item["maps"][idx])
                    ref_before,ref_after = (aligned_voxels(p,np.eye(4)) for p in checked["clean"]["maps"][idx])
                    run[key]["map_clean_proxy"][idx]=map_delta(before,after,ref_before,ref_after)
    return report


def main():
    rows=[]
    result = {name:evaluate_drive(name,rows) for name in DRIVES}
    if (ROOT/"exact").is_dir():
        result["exact_comparison"] = {name:evaluate_drive(name,rows,True) for name in DRIVES}
    with (ROOT/"stage5_results.json").open("x") as f:
        json.dump(result,f,indent=2,allow_nan=False)
    with (ROOT/"stage5_pose_errors.csv").open("x",newline="") as f:
        writer=csv.writer(f)
        writer.writerow(("design","drive","repeat","arm","measurement_ns","phase","leica_position_error_m"))
        writer.writerows(rows)
    for name in DRIVES:
        for rep, arms in result[name]["runs"].items():
            for key, row in arms.items():
                pos = row.get("chosen",{}).get("common",{}).get("post_E1",{}).get("ate",{})
                print(name,rep,key,row["status"],pos,
                      [e["decision"] for e in row.get("arm",{}).get("events",row["events"])],
                      row.get("verification_failure",[]))


if __name__=="__main__":
    main()
