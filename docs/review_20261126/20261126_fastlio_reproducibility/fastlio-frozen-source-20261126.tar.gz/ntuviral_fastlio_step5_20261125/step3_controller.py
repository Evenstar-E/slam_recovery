"""Controlled two-event bias-admission path on the normal estimator loop.

The fixed timestamps arm the test. Repair proposals use received sensor values,
and only scalar limits from the separate uncorrupted calibration run.
"""
import json
import math
import os
from pathlib import Path
import sys
import time

import numpy as np
import rospy
from sensor_msgs.msg import PointCloud2

ROOT=Path(__file__).resolve().parent
PARENT=ROOT.parent
sys.path[:0]=[str(PARENT/name) for name in (
    "campus12_step3_native_20261124",
    "campus12_e1_ray_candidate_20261124",
    "campus12_native_counterfactual_20261125",
)]
from native_probe import Probe, integer
from native_responses import response
from ray_candidate import estimate, measures
from slam_recovery.ros.cloud_repair import ReferenceGrid, shift_z_cloud
from slam_recovery.ros.recovery_node import cloud_to_xyz, pose_to_matrix
from slam_recovery.validation.wilson_validator import evaluate_paired_sequential_benefit

# Numeric slack covers FLOAT32 add/subtract roundoff. These constants and the
# no-injection-calibration policy are identical for both treated events.
RAY_SLACK_M=1e-5
MAP_RADIUS_M=1.0
PROBE_COUNT=96
POST_EVENT_CAPTURE_NS=400_000_000
ARM_MARGIN_NS=4_000_000_000
END_LIVE_NS=1711548160500000000

def measures(msg):
    fields = {f.name:f for f in msg.fields}
    order = ">" if msg.is_bigendian else "<"
    def column(name, dtype, datatype):
        f = fields[name]
        if f.datatype != datatype or f.count != 1:
            raise ValueError(f"unexpected PointCloud2 field {name}")
        return np.ndarray((msg.height, msg.width), dtype=order+dtype, buffer=msg.data,
                          offset=f.offset, strides=(msg.row_step,msg.point_step)).ravel()
    x,y,z = [column(k, "f4", 7).astype(np.float64) for k in "xyz"]
    ring = column("ring","u1",2) if fields["ring"].datatype == 2 else column("ring","u2",4)
    r = np.hypot(x,y)
    return r,z,ring,np.isfinite(r)&np.isfinite(z)&(np.hypot(r,z)>=4)


def estimate(msg,model):
    r,z,ring,valid=measures(msg)
    per_even_ring=[float(np.median(z[valid&(ring==idx)] - (a*r[valid&(ring==idx)]+b)))
                   for idx,(a,b) in model.items() if idx%2==0 and (valid&(ring==idx)).any()]
    if not per_even_ring:
        raise ValueError("no calibration beams observed in target frame")
    bias=float(np.median(per_even_ring))
    return bias,len(per_even_ring),float(np.median(np.abs(np.asarray(per_even_ring)-bias)))


def odd_error(msg,model):
    r,z,rings,valid=measures(msg)
    residuals=[]
    for ring,(slope,intercept) in model.items():
        if ring%2==0:
            continue
        mask=valid & (rings==ring)
        if np.any(mask):
            residuals.append(np.abs(z[mask]-(slope*r[mask]+intercept)))
    return float(np.median(np.concatenate(residuals))) if residuals else math.inf


def map_score(poses, replacements, points):
    grid=ReferenceGrid(points)
    # Same coordinate convention as the archived gate raw-to-world projection.
    # The map is independent and comes exclusively from the active checkpoint.
    score=[]
    for idx in range(0,len(replacements),5):
        msg=replacements[idx]
        stamp=msg.header.stamp.to_nsec()
        p=poses[stamp]
        xyz=cloud_to_xyz(msg)
        xyz=xyz[np.linalg.norm(xyz,axis=1)>=4]
        selected=xyz[np.linspace(0,len(xyz)-1,PROBE_COUNT,dtype=int)]
        X=pose_to_matrix(p[:3],p[3:])
        q=selected@X[:3,:3].T+X[:3,3]
        distance=grid.nearest_distances(q,reach=2)
        # The 1m unsupported penalty stays in the denominator in all branches.
        bounded=np.minimum(distance,MAP_RADIUS_M)
        score.append({"stamp_ns":stamp,"support":float(np.mean(distance<=MAP_RADIUS_M)),
                      "distance_rms_m":float(np.sqrt(np.mean(bounded**2)))})
    return score


def summary(scores):
    return {"scored_frames":len(scores),
            "support":float(np.mean([x["support"] for x in scores])),
            "distance_rms_m":float(np.sqrt(np.mean([x["distance_rms_m"]**2 for x in scores])))}


class Dual(Probe):
    def __init__(self,out,arm):
        super().__init__(out)
        self.next_request = 1
        self.snapshot_request = None
        self.arm_name=arm
        self.windows=json.loads((Path(os.environ["STEP5_INPUT"])/"events.json").read_text())
        estimates=json.loads((ROOT/"beam_source.json").read_text())
        self.model={int(k):tuple(v) for k,v in estimates["calibration_model"].items()}
        self.by_event={w["id"]:{} for w in self.windows}
        self.scan_sub=rospy.Subscriber("/velodyne_points",PointCloud2,self.scan,queue_size=256,buff_size=2**25)
        self.result_file=(out/"events_result.jsonl").open("x",buffering=1)
        self.calibration=json.loads((ROOT/"calibration.json").read_text()) if arm=="repair" else None

    def send(self, cmd, payload="", predicate=None):
        request = self.next_request
        self.next_request += 1
        scheduled = cmd in ("hold", "snapshot") and bool(payload)
        if cmd == "snapshot":
            self.snapshot_request = request
        tmp = self.ctl / "cmd.probe.tmp"
        tmp.write_text(f"{cmd}\n{payload}\n{request}\n")
        tmp.replace(self.ctl / "cmd")
        self.log({"sent":cmd,"payload":payload,"request":request})

        def wait_for_reply():
            ack = (response(self.ctl,request,"deferred",cmd) if scheduled else None)
            ack = ack or response(self.ctl,request,"applied",cmd)
            return ack if ack and (predicate is None or predicate(ack)) else None

        ack=self.wait(wait_for_reply,8,f"no correlated response for {cmd} {request}")
        self.log({"command":cmd,"payload":payload,"request":request,"ack":ack})
        return ack

    def snapshot_applied(self, boundary):
        request = self.snapshot_request
        ack=self.wait(lambda:response(self.ctl,request,"applied","snapshot"),20,
                      f"no application of snapshot request {request}")
        stamp=integer(ack,"stamp_ns")
        if not ack.startswith("OK snapshot applied valid=1 ") or not boundary-300_000_000 <= stamp <= boundary:
            raise RuntimeError(f"wrong snapshot for {request}: {ack}")
        self.log({"command":"snapshot_applied","request":request,"boundary_ns":boundary,"ack":ack})
        return stamp

    def scan(self,msg):
        stamp=msg.header.stamp.to_nsec()
        for window in self.windows:
            if window["onset_ns"]<=stamp<window["end_ns"]:
                self.by_event[window["id"]][stamp]=msg
                break

    def branch(self,event_id,label,cp_ns,expected,clouds=None):
        assert integer(self.send("lab_arm",label),"valid")==1
        got=0 if clouds is None else self.publish_candidate(clouds)
        start=self.send("reprocess",str(expected[-1]))
        assert integer(start,"valid")==1 and integer(start,"checkpoint_stamp_ns")==cp_ns
        assert integer(start,"repaired_fed")==got
        pending=integer(start,"replay_within_end")+integer(start,"replay_suffix")
        def done():
            status=self.send("status")
            return status if integer(status,"replay_remaining")==0 else None
        status=self.wait(done,28,f"{event_id} {label} native replay unfinished")
        assert integer(status,"captured_groups")==pending
        assert integer(status,"repaired_in_update")==integer(status,"repaired_map_updates")==got
        assert integer(self.send("lab_export",label),"valid")==1
        trace=(self.ctl/"lab_trace.jsonl").read_text()
        rows=[row for line in trace.splitlines()
              if (row:=json.loads(line))["episode"]==event_id and row["arm"]==label]
        all_ns=[row["scan_stamp_ns"] for row in rows]
        assert len(all_ns)==pending and all_ns==sorted(set(all_ns))
        poses={}
        for actual in rows:
            ns=actual["scan_stamp_ns"]
            matches=[t for t in expected if abs(ns-t)<=1024]
            if matches:
                assert len(matches)==1
                poses[matches[0]]=actual["pose"]
                assert actual["replacement"]==bool(got)
        assert sorted(poses)==expected
        return poses, {"start":start,"completion":status,"groups":pending,"updated":got,
                       "first_ns":all_ns[0],"last_ns":all_ns[-1]}

    def run_event(self,window):
        idx,onset,end=window["id"],window["onset_ns"],window["end_ns"]
        boundary=onset-ARM_MARGIN_NS
        self.wait_pose(boundary-4*10**9,500 if idx==1 else 80)
        assert integer(self.send("lab_capture",str(end+POST_EVENT_CAPTURE_NS)),"valid")==1
        self.arm(boundary)
        cp=self.snapshot_applied(boundary)
        assert cp<onset
        path=self.ctl/f"E{idx}_checkpoint.xyz32"
        self.wait(path.is_file,45,f"event {idx} did not complete native capture")
        stamps=sorted(self.by_event[idx])
        assert len(stamps)==60, f"event {idx} capture has {len(stamps)} scans"
        originals=[self.by_event[idx][t] for t in stamps]
        assert stamps[0]>=onset and stamps[-1]<end
        biases=[estimate(m,self.model)[0] for m in originals]
        originals_odd=[odd_error(m,self.model) for m in originals]
        checkpoint=np.fromfile(str(path),"<f4").reshape(-1,3)
        assert len(checkpoint)>1000 and np.isfinite(checkpoint).all()
        raw_poses,raw_receipt=self.branch(idx,"raw",cp,stamps)
        row={"id":idx,"checkpoint_stamp_ns":cp,"checkpoint_points":len(checkpoint),
             "boundary_ns":boundary,"onset_ns":onset,"end_ns":end,"stamps_ns":stamps,
             "bias_m":biases,"odd_before_m":originals_odd,"raw":raw_receipt,
             "raw_map":None,"selected_arm":"raw"}
        if self.arm_name=="clean":
            row["raw_local_frames"]=map_score(raw_poses,originals,checkpoint)
            row["raw_map"]=summary(row["raw_local_frames"])
            row["decision"]="CLEAN_NO_CHANGE_CALIBRATION"
        elif self.arm_name=="injected":
            row["decision"]="INJECTED_RAW_CONTROL"
        else:
            numeric_floor=self.calibration["maximum_healthy_odd_m"]+RAY_SLACK_M
            row["beam_limit_m"]=numeric_floor
            if not all(np.isfinite(biases)) or not all(np.isfinite(originals_odd)):
                raise ValueError("non-finite measurement evidence")
            if not any(abs(b)>numeric_floor for b in biases):
                row["decision"]="HEALTHY_NO_CHANGE"
            else:
                corrected=[shift_z_cloud(m,-b) for m,b in zip(originals,biases)]
                odd=[odd_error(m,self.model) for m in corrected]
                paired=evaluate_paired_sequential_benefit(np.array(originals_odd),np.array(odd),
                                                          min_observations=8)
                row["odd_after_m"]=odd
                row["odd_wilson_lower_bound"]=float(paired.wilson_lower_bound)
                row["all_repair_returns_in_healthy_band"]=bool(max(odd)<=numeric_floor)
                row["measurement_check_pass"]=bool(paired.approved and row["all_repair_returns_in_healthy_band"])
                if row["measurement_check_pass"]:
                    row["raw_local_frames"]=map_score(raw_poses,corrected,checkpoint)
                    row["raw_map"]=summary(row["raw_local_frames"])
                    candidate,cand_receipt=self.branch(idx,"candidate",cp,stamps,corrected)
                    if raw_receipt["groups"]!=cand_receipt["groups"] or raw_receipt["last_ns"]!=cand_receipt["last_ns"]:
                        raise RuntimeError("native branches did not use the same cohort")
                    row["candidate"]=cand_receipt
                    row["candidate_local_frames"]=map_score(candidate,corrected,checkpoint)
                    row["candidate_map"]=summary(row["candidate_local_frames"])
                    local_limits=self.calibration["local_map"]
                    valid=(row["candidate_map"]["support"]>=local_limits["support_lower_bound"]
                        and row["candidate_map"]["distance_rms_m"]<=local_limits["distance_rms_upper_bound_m"])
                    row["local_map_limits"]=local_limits
                    row["local_map_check_pass"]=bool(valid)
                    if valid:
                        row["decision"]="ACCEPT_BIAS_CORRECTION"
                        row["selected_arm"]="candidate"
                    else:
                        row["decision"]="REFUSE_UNVERIFIED_LOCAL_GEOMETRY"
                else:
                    row["decision"]="REFUSE_MEASUREMENT_EVIDENCE"
        refused=row["decision"].startswith("REFUSE_")
        if refused:
            # The still-private branch is discarded. Resume from the pre-event native state.
            assert integer(self.send("restore"),"stamp_ns")==cp
            row["selected_arm"]="restored"
        row["release"]=self.send("lab_release","restored" if refused else "applied")
        assert integer(row["release"],"valid")==1 and "map_writes=released" in row["release"]
        self.by_event[idx].clear()
        row["released_event_cache_scans"]=len(originals)
        self.result_file.write(json.dumps(row,allow_nan=False)+"\n")

    def run(self):
        self.wait(lambda:(self.ctl/"capabilities.json").is_file(),20,"native channel not ready")
        self.send("status")
        self.send("status")
        for event in self.windows:
            self.run_event(event)
        # Native status proves input re-entry even in a genuine host odometry hibernation.
        deadline=time.monotonic()+125
        while time.monotonic()<deadline and not rospy.is_shutdown():
            ack=self.send("status")
            if integer(ack,"stamp_ns")>=END_LIVE_NS:
                (self.root/"tail_status.json").write_text(json.dumps({"ack":ack},indent=2)+"\n")
                return
            time.sleep(0.5)
        raise TimeoutError("native estimator did not consume tail through the target timestamp")


if __name__=="__main__":
    out,arm=sys.argv[1:]
    rospy.init_node("candidate_native_probe")
    Dual(Path(out),arm).run()
