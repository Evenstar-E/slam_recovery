"""Run four separately instantiated policies on the same candidate population."""
import json
import os
from pathlib import Path
import sys
import time

import numpy as np
import rosbag
import rospy

from stage import MODEL, message_sha, sha
from step3_controller import (
    ARM_MARGIN_NS, POST_EVENT_CAPTURE_NS, ROOT, RAY_SLACK_M,
    Dual, integer, map_score, odd_error, summary,
    evaluate_paired_sequential_benefit,
)

INPUT = Path(os.environ["STEP5_INPUT"])
TAIL_MARK_NS = json.loads((INPUT/"population.json").read_text())["tail_mark_ns"]


class Policy(Dual):
    def __init__(self, out, arm):
        super().__init__(out, arm)
        self.model = MODEL
        self.calibration = json.loads((ROOT / "calibration.json").read_text())
        self.frame_rows = json.loads((INPUT / "frozen_candidates.json").read_text())["frames"]
        self.candidates = {}
        if arm in ("forced", "gated"):
            with rosbag.Bag(str(INPUT / "frozen_candidates.bag")) as bag:
                for _, msg, _ in bag.read_messages(topics=["/velodyne_points"]):
                    self.candidates[msg.header.stamp.to_nsec()] = msg
            assert sorted(self.candidates) == [row["stamp_ns"] for row in self.frame_rows]

    def log(self, row):
        row["monotonic_s"] = time.monotonic()
        super().log(row)

    def arm_event(self, window):
        idx = window["id"]
        boundary = window["onset_ns"] - ARM_MARGIN_NS
        cutoff = window["end_ns"] + POST_EVENT_CAPTURE_NS
        self.wait_pose(boundary - 4 * 10**9, 500 if idx == 1 else 100)
        assert integer(self.send("lab_capture", str(cutoff)), "valid") == 1
        self.arm(boundary)
        checkpoint_stamp = self.snapshot_applied(boundary)
        path = self.ctl / f"E{idx}_checkpoint.xyz32"
        self.wait(path.is_file, 50, f"E{idx} did not complete native capture")
        rows = [row for row in self.frame_rows if row["event"] == idx]
        stamps = [row["stamp_ns"] for row in rows]
        self.wait(lambda: len(self.by_event[idx]) == len(stamps), 4, f"E{idx} relay delivery incomplete")
        assert sorted(self.by_event[idx]) == stamps
        originals = [self.by_event[idx][stamp] for stamp in stamps]
        assert [sha(msg.data) for msg in originals] == [row["input_sha"] for row in rows]
        return path, rows, originals, {
            "id": idx, "checkpoint_stamp_ns": checkpoint_stamp, "boundary_ns": boundary,
            "onset_ns": window["onset_ns"], "end_ns": window["end_ns"],
            "stamps_ns": stamps, "expected_cut_ns": cutoff,
        }

    def validate(self, originals, corrected):
        before = np.array([odd_error(msg, self.model) for msg in originals])
        after = np.array([odd_error(msg, self.model) for msg in corrected])
        assert np.isfinite(before).all() and np.isfinite(after).all()
        paired = evaluate_paired_sequential_benefit(before, after, min_observations=8)
        floor = self.calibration["maximum_healthy_odd_m"] + RAY_SLACK_M
        return {
            "healthy_odd_limit_m": floor,
            "odd_before_m": before.tolist(), "odd_after_m": after.tolist(),
            "wilson_lower": float(paired.wilson_lower_bound),
            "pass": bool(paired.approved and np.max(after) <= floor),
            "input_in_healthy_band": bool(np.max(before) <= floor),
        }

    def run_event(self, window):
        idx = window["id"]
        started = time.monotonic()
        path, manifest, originals, row = self.arm_event(window)
        checkpoint_ns, stamps = row["checkpoint_stamp_ns"], row["stamps_ns"]
        release_mode = "applied"

        if self.arm_name == "isolation":
            assert integer(self.send("lab_arm", "raw"), "valid") == 1
            assert integer(self.send("lab_export", "raw"), "valid") == 1
            row.update(decision="KEEP_QUARANTINED_ESTIMATE", selected_arm="quarantined", selected_map="raw")
        else:
            _, row["raw"] = self.branch(idx, "raw", checkpoint_ns, stamps)
            corrected = [self.candidates[stamp] for stamp in stamps]
            receipt = [message_sha(msg) for msg in corrected]
            assert receipt == [item["candidate_message_sha"] for item in manifest]
            row["offered_candidate_message_sha256"] = receipt
            measured = self.validate(originals, corrected)
            row["measurement"] = measured
            if self.arm_name == "forced" or measured["pass"]:
                trial, row["candidate"] = self.branch(idx, "candidate", checkpoint_ns, stamps, corrected)
                assert all(row["raw"][key] == row["candidate"][key]
                           for key in ("groups", "first_ns", "last_ns"))
                pts = np.fromfile(str(path), "<f4").reshape(-1, 3)
                assert len(pts) > 1000 and np.isfinite(pts).all()
                row["candidate_map_score"] = summary(map_score(trial, corrected, pts))
                limits = self.calibration["local_map"]
                score = row["candidate_map_score"]
                local_pass = (score["support"] >= limits["support_lower_bound"]
                              and score["distance_rms_m"] <= limits["distance_rms_upper_bound_m"])
                row["local_pass"] = local_pass
                if self.arm_name == "forced" or local_pass:
                    row.update(decision="FORCE_COMMIT" if self.arm_name == "forced" else "ACCEPT",
                               selected_arm="candidate", selected_map="candidate")
                else:
                    row.update(decision="REFUSE_MAP_RESTORE", selected_arm="restored", selected_map="checkpoint")
                    assert integer(self.send("restore"), "stamp_ns") == checkpoint_ns
                    release_mode = "restored"
            elif measured["input_in_healthy_band"]:
                # Original active history is the healthy private raw replay.
                row.update(decision="REFUSE_STALE_KEEP_HEALTHY_RAW", selected_arm="raw", selected_map="raw")
            else:
                row.update(decision="REFUSE_MEASUREMENT_RESTORE", selected_arm="restored", selected_map="checkpoint")
                assert integer(self.send("restore"), "stamp_ns") == checkpoint_ns
                release_mode = "restored"

        row["release"] = self.send("lab_release", release_mode)
        assert integer(row["release"], "valid") == 1 and "map_writes=released" in row["release"]
        row["elapsed_monotonic_s"] = time.monotonic() - started
        row["released_event_cache_scans"] = len(originals)
        self.by_event[idx].clear()
        for stamp in stamps:
            self.candidates.pop(stamp, None)
        self.result_file.write(json.dumps(row, allow_nan=False) + "\n")

    def run(self):
        self.wait(lambda: (self.ctl / "capabilities.json").is_file(), 20, "native channel not ready")
        ordinary = self.arm_name in ("clean", "native")
        mark_slots = [7]
        assert integer(self.send("lab_mark", f"7 {TAIL_MARK_NS}"), "valid") == 1
        if ordinary:
            for window in self.windows:
                idx = window["id"]
                for slot, at in ((2 * idx - 1, window["onset_ns"] - ARM_MARGIN_NS),
                                 (2 * idx, window["end_ns"] + POST_EVENT_CAPTURE_NS)):
                    assert integer(self.send("lab_mark", f"{slot} {at}"), "valid") == 1
                    mark_slots.append(slot)
                self.result_file.write(json.dumps({
                    "id": idx, "decision": "NATIVE_UNINTERRUPTED", "selected_arm": "live",
                }) + "\n")
        else:
            for event in self.windows:
                self.run_event(event)

        self.wait(lambda: all((self.ctl / f"M{slot}.xyz32").is_file() for slot in mark_slots),
                  380 if ordinary else 50, "native estimator did not export scheduled live map")
        ack = self.send("status")
        assert integer(ack, "stamp_ns") >= TAIL_MARK_NS
        (self.root / "tail_status.json").write_text(json.dumps({"ack": ack}, indent=2) + "\n")


if __name__ == "__main__":
    directory, policy = sys.argv[1:]
    rospy.init_node("candidate_native_probe")
    Policy(Path(directory), policy).run()
