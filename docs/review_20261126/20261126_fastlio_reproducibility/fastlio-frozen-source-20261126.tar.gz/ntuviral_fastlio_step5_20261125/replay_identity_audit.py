"""Replay the old association decision using captured immutable ROS timestamps."""
from pathlib import Path
import json
import math

ROOT = Path(__file__).resolve().parent


def lines(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def key(stamp):
    return round((stamp // 10**9 + (stamp % 10**9)*1e-9)*1e9)


def actual_fixture():
    path = ROOT/"eee_03/r1/forced/ctl"
    candidates = {key(r["stamp_ns"]):r["stamp_ns"] for r in
                  json.loads((ROOT/"eee_03/frozen_candidates.json").read_text())["frames"] if r["event"]==1}
    raw = [r for r in lines(path/"lab_trace.jsonl") if r["arm"]=="raw" and r["episode"]==1]
    used = {}
    leftovers = dict(candidates)
    for row in raw:
        begin,end = row["scan_stamp_ns"],row["stamp_ns"]
        possibilities=[t for t in leftovers if (begin*1e-9)-1e-3 <= t*1e-9 <= (end*1e-9)+1e-3]
        if possibilities:
            best=min(possibilities,key=lambda t: (abs(t-end),t))
            used[begin]=leftovers.pop(best)
    applied = [r["scan_stamp_ns"] for r in lines(path/"repair_updates.jsonl")]
    assert list(used)==applied
    exact = {r["scan_stamp_ns"]:candidates[r["scan_stamp_ns"]]
             for r in raw if r["scan_stamp_ns"] in candidates}
    assert len(exact)==len(candidates)==60
    assert all(abs(t-s)<=1024 for t,s in exact.items())
    return {
        "offered":len(candidates),"old_fed":len(used),
        "old_incorrect_destination_count":sum(abs(begin-cap)>1024 for begin,cap in used.items()),
        "old_unmatched_candidate_ns":list(leftovers.values()),
        "old_misbound":[{"group_ns":a,"candidate_ns":b} for a,b in used.items() if abs(a-b)>1024],
        "exact_fed":len(exact),"old_runtime_scan_stamps_match": True,
    }


if __name__ == "__main__":
    with (ROOT/"association_audit.json").open("x") as f:
        json.dump(actual_fixture(), f, indent=2)
