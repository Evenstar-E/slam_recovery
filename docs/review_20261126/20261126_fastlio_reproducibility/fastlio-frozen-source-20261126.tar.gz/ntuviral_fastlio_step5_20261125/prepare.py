"""Prepare a fixed 85 s prefix of the selected publisher archive."""
from collections import Counter, defaultdict
import hashlib
from pathlib import Path
import json
import shutil
import sys
import zipfile

import numpy as np
import rosbag

from ground_truth_eval import read_gt, interp, fit

ROOT = Path(__file__).resolve().parent
LIDAR = "/os1_cloud_node1/points"
IMU = "/imu/imu"
TOPICS = {LIDAR: "/velodyne_points", IMU: "/imu_raw"}
WINDOWS = [(34, 40, 0.5), (53, 59, 0.5), (68, 72, 0.0)]
SPAN = 85
NS = 10**9


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(4*1024*1024), b""):
            h.update(block)
    return h.hexdigest()


def main(name):
    incoming = ROOT / "incoming"
    out = ROOT / name
    out.mkdir(exist_ok=False)
    archive = incoming / f"{name}.zip"
    gt = incoming / f"{name}_gt.csv"
    published = {r.split()[1]: r.split()[0] for r in (incoming / "SHA256SUMS.txt").read_text().splitlines() if r.strip()}
    archive_sha, gt_sha = digest(archive), digest(gt)
    assert archive_sha == published[f"sequences/{name}.zip"]
    assert gt_sha == published[f"ground_truth/{name}/ground_truth.csv"]
    raw = out / "extracted.bag.tmp"
    with zipfile.ZipFile(archive) as z:
        files = [p for p in z.infolist() if p.filename.endswith(".bag")]
        assert len(files) == 1 and 0 < files[0].file_size < 12_000_000_000
        with z.open(files[0]) as content, raw.open("xb") as dest:
            shutil.copyfileobj(content, dest, 4*1024*1024)
    counts = Counter()
    stamps = defaultdict(list)
    sensor = []
    start = None
    shift = 0
    preflight = {"rule":"v1_fixed_timing"}
    with rosbag.Bag(str(raw)) as bag, rosbag.Bag(str(out/"study.bag"), "w", compression="lz4") as prefix:
        info = bag.get_type_and_topic_info()[1]
        assert info[LIDAR].msg_type == "sensor_msgs/PointCloud2"
        assert info[IMU].msg_type == "sensor_msgs/Imu"
        first = [next(bag.read_messages(topics=[topic])).message.header.stamp.to_nsec() for topic in TOPICS]
        start = min(first)
        if name == "sbs_02":
            pins, positions = read_gt(gt)
            preflight = {"rule":"earliest_GT_qualified_offset", "status":"NO_QUALIFIED_SHIFT"}
            for offset in range(36):
                pre = [g for t in range((5+offset)*10,(29+offset)*10)
                       if (g:=interp(pins,positions,start+t*100_000_000)) is not None]
                after_count = sum(interp(pins,positions,start+t*100_000_000) is not None
                                  for t in range((34+offset)*10,(85+offset)*10))
                transform, checks = fit(pre,pre)
                if transform is not None and after_count/510>=.8:
                    shift = offset
                    preflight.update(status="QUALIFIED", offset_s=offset, prefix=checks,
                                     post_gt_support=after_count/510)
                    break
        span = SPAN+shift
        for topic, msg, receipt in bag.read_messages(topics=TOPICS):
            stamp = msg.header.stamp.to_nsec()
            if receipt.to_nsec() > start + (span + 3)*NS and all(stamps[t] for t in TOPICS):
                break
            if not start <= stamp < start + span*NS:
                continue
            if stamps[topic] and stamp <= stamps[topic][-1]:
                raise RuntimeError(f"Nonincreasing source measurement stamp on {topic}")
            if topic == LIDAR and not sensor:
                sensor = [(field.name, field.datatype) for field in msg.fields]
                kinds = dict(sensor)
                assert kinds["ring"] in (2, 4) and kinds["t"] == 6
            prefix.write(TOPICS[topic], msg, msg.header.stamp)
            counts[topic] += 1
            stamps[topic].append(stamp)
    assert counts[LIDAR] > 790 and counts[IMU] > 14000, counts
    assert stamps[LIDAR][-1] > start + (span-1)*NS
    assert stamps[IMU][-1] > start + (span-1)*NS
    events = []
    for idx, (a,b,offset) in enumerate(WINDOWS,1):
        onset,end = start+(a+shift)*NS,start+(b+shift)*NS
        actual = [s for s in stamps[LIDAR] if onset <= s < end]
        assert len(actual) >= 30
        events.append(dict(id=idx,onset_ns=onset,end_ns=end,frames=len(actual),inject_z_m=offset))
    with rosbag.Bag(str(out/"study.bag")) as check:
        for source, target in TOPICS.items():
            new_stamps = [msg.header.stamp.to_nsec() for _,msg,stamp in check.read_messages(topics=[target])
                          if stamp == msg.header.stamp]
            assert new_stamps == stamps[source]
    topology = {
        "sequence": name, "archive_sha256": archive_sha, "raw_bag_sha256": digest(raw),
        "ground_truth_sha256": gt_sha, "study_bag_sha256": digest(out/"study.bag"),
        "start_ns": start, "tail_mark_ns": start+(83+shift)*NS, "duration_s": span,
        "alignment_start_s":5+shift, "alignment_end_s":29+shift, "reference_preflight":preflight,
        "scan_count": counts[LIDAR], "imu_count": counts[IMU],
        "scan_stamps_ns": stamps[LIDAR], "point_fields": sensor,
        "imu_hz_median": float(NS / np.median(np.diff(stamps[IMU]))),
        "lidar_hz_median": float(NS / np.median(np.diff(stamps[LIDAR]))),
        "input_topics": TOPICS,
    }
    (out/"events.json").write_text(json.dumps(events, indent=2)+"\n")
    (out/"population.json").write_text(json.dumps(topology, indent=2)+"\n")
    raw.unlink()
    print(name, counts, sensor, [(e["id"], e["frames"]) for e in events], flush=True)


if __name__ == "__main__":
    main(sys.argv[1])
