from pathlib import Path
import hashlib
import json
import os
import sys

import rospy
from sensor_msgs.msg import PointCloud2

from slam_recovery.ros.cloud_repair import shift_z_cloud


def main():
    out, arm=sys.argv[1:]
    windows=json.loads((Path(os.environ["STEP5_INPUT"]) / "events.json").read_text())
    rospy.init_node("dual_event_input_relay")
    pub=rospy.Publisher("/velodyne_points",PointCloud2,queue_size=256)
    receipt=(Path(out)/"relay_frames.jsonl").open("x",buffering=1)

    def callback(msg):
        stamp=msg.header.stamp.to_nsec()
        hit=next((e for e in windows if e["onset_ns"]<=stamp<e["end_ns"]),None)
        shift=hit["inject_z_m"] if hit is not None and arm!="clean" else 0.0
        forward=shift_z_cloud(msg,shift) if shift else msg
        pub.publish(forward)
        receipt.write(json.dumps({"stamp_ns":stamp,"event":hit["id"] if hit else None,"shifted":bool(shift),"points":msg.width*msg.height,
                                    "data_sha256":hashlib.sha256(forward.data).hexdigest() if hit else None})+"\n")

    sub=rospy.Subscriber("/velodyne_points_raw",PointCloud2,callback,queue_size=256,buff_size=2**25)
    rospy.spin()


if __name__=="__main__":
    main()
