#!/bin/bash
# Scripted two-event interface run: host (FAST-LIO native recovery) + slam_recovery driver.
set -o pipefail
OUT="${1:?out}"; BAG="${2:?bag}"; DUR="${3:-260}"
E1="${4:-1711547999352267771}"; E2="${5:-1711548113452267771}"
# The driver processes ~6 Hz while the host publishes at 10 Hz, so at rate 1.0 the driver is
# ~40 s of bag time behind by the end and every command arrives after the host has moved on.
# PLAY_RATE=0.5 lets the driver keep up; it is recorded in pre_run.txt because a slowed bag is
# not real-time evidence.
PLAY_RATE="${PLAY_RATE:-1.0}"
ARM_LEAD="${ARM_LEAD:-3}"
CANDIDATE_SOURCE="${CANDIDATE_SOURCE:-host_poses}"
# INJECTION (controlled): a body-z shift on the scan stream for a bounded window, delivered by
# the project's own corrupt_relay. The bag's scans are remapped to the relay's input so the host
# sees only the relay's output. Empty CORRUPT_START disables the relay entirely.
CORRUPT_START="${CORRUPT_START:-}"
CORRUPT_END="${CORRUPT_END:-}"
CORRUPT_SHIFT="${CORRUPT_SHIFT:-0.5}"
REMAP="${REMAP:-}"
MARGIN="${MARGIN:-2.0}"
WAIT_LIMIT="${WAIT_LIMIT:-20}"
CTL="$OUT/ctl"; mkdir -p "$CTL" "$OUT"
source /opt/ros/noetic/setup.bash
source "$LAB_WORKSPACE/devel/setup.bash"
export PYTHONPATH="/home/tong/src/slam_recovery:${PYTHONPATH:-}"
export ROS_HOSTNAME=127.0.0.1
PORT="$(/usr/bin/python3 -c 'import socket; s=socket.socket(); s.bind(("127.0.0.1",0)); print(s.getsockname()[1]); s.close()')"
export ROS_MASTER_URI="http://127.0.0.1:${PORT}"
PY="/usr/bin/python3"
RC=""; LAUNCH=""; PLAY=""; NODE=""; RELAY=""; REC=""; PROBE=""
cleanup(){ [ -n "$PROBE" ] && kill -TERM "$PROBE" 2>/dev/null; [ -n "$NODE" ] && kill -INT "$NODE" 2>/dev/null; sleep 1
  for p in "$PLAY" "$REC" "$LAUNCH" "$RC" "$RELAY"; do [ -n "$p" ] && kill -INT -- "-$p" 2>/dev/null; done; sleep 2
  [ -n "$NODE" ] && kill -TERM "$NODE" 2>/dev/null
  for p in "$PLAY" "$REC" "$LAUNCH" "$RC" "$RELAY"; do [ -n "$p" ] && kill -TERM -- "-$p" 2>/dev/null; done
  for p in "$PLAY" "$NODE" "$REC" "$LAUNCH" "$RC" "$RELAY"; do [ -n "$p" ] && wait "$p" 2>/dev/null; done; }
trap cleanup EXIT
setsid roscore -p "$PORT" > "$OUT/roscore.log" 2>&1 & RC=$!
for _ in $(seq 1 30); do rosnode list >/dev/null 2>&1 && break; sleep 1; done
rosparam set /native_recovery_dir "$CTL"
setsid roslaunch "$TWO_EVENT_ROOT/ntulab.launch" > "$OUT/host.log" 2>&1 & LAUNCH=$!
for _ in $(seq 1 60); do rosnode list 2>/dev/null | grep -q '^/laserMapping$' && break; sleep 1; done
rosnode list | grep -q '^/laserMapping$' || { echo "BLOCKED: host did not start" > "$OUT/result.txt"; exit 1; }
setsid "$PY" -u "$TWO_EVENT_ROOT/relay.py" "$OUT" "$TWO_EVENT_ARM" > "$OUT/relay.log" 2>&1 & RELAY=$!
for _ in $(seq 1 20); do
  rosnode list 2>/dev/null | grep -q '^/dual_event_input_relay$' && break
  sleep 0.5
done
rosnode list | grep -q '^/dual_event_input_relay$' || exit 3
RECORD="${RECORD:-1}"
if [ "$RECORD" = "1" ]; then
  setsid rosbag record --lz4 -O "$OUT/frontend.bag" /Odometry /Issleeping /Isbuilding > "$OUT/record.log" 2>&1 & REC=$!
  sleep 2
fi
"$PY" -u "$TWO_EVENT_ROOT/controller.py" "$OUT" "$TWO_EVENT_ARM" > "$OUT/probe.log" 2>&1 & PROBE=$!
for _ in $(seq 1 20); do
  rosnode list 2>/dev/null | grep -q '^/candidate_native_probe$' && break
  sleep 0.5
done
rosnode list | grep -q '^/candidate_native_probe$' || { echo "BLOCKED: native probe registration failed" > "$OUT/result.txt"; exit 4; }
# shellcheck disable=SC2086  # REMAP is a plain list of remap tokens, documented as such
setsid rosbag play --clock -r "$PLAY_RATE" --duration "$DUR" $REMAP "$BAG" > "$OUT/play.log" 2>&1 & PLAY=$!
wait "$PLAY"
play_exit=$?
printf "%s\n" "$play_exit" > "$OUT/play_exit.txt"
# Drain: the driver processes the bag at ~7 Hz while the host publishes at ~8-10 Hz, so a queue of
# bag-end frames remains when playback stops. Keep the driver alive long enough to work through it
# before signalling; POST_PLAY_DRAIN controls how long (default keeps the old 20 s).
for i in $(seq 1 115); do
  if ! kill -0 "$PROBE" 2>/dev/null; then break; fi
  sleep 1
done
if [ -n "$NODE" ]; then kill -INT "$NODE" 2>/dev/null; fi
if [ -n "$REC" ]; then kill -INT "$REC" 2>/dev/null; wait "$REC" 2>/dev/null; fi
if [ -n "$NODE" ]; then
for _ in $(seq 1 120); do [ -d "/proc/$NODE" ] && sleep 1 || break; done
kill -0 "$NODE" 2>/dev/null && kill -TERM "$NODE" 2>/dev/null
wait "$NODE" 2>/dev/null
fi
if kill -0 "$PROBE" 2>/dev/null; then kill -TERM "$PROBE" 2>/dev/null; fi
wait "$PROBE"
probe_exit=$?
printf '%s\n' "$probe_exit" > "$OUT/probe_exit.txt"
rosbag info "$OUT/frontend.bag" > "$OUT/bag_info.txt" 2>&1 || true
echo done > "$OUT/result.txt"
if [ "$play_exit" -ne 0 ]; then exit "$play_exit"; fi
exit "$probe_exit"
