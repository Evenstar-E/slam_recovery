#!/bin/bash
set -eu
cd "$(dirname "$0")"
seq="$1"
rep="$2"
arm="$3"
case "$seq" in eee_03|sbs_02) ;; *) exit 2 ;; esac
case "$rep" in r1|r2) ;; *) exit 2 ;; esac
case "$arm" in clean|native|isolation|forced|gated) ;; *) exit 2 ;; esac
export TWO_EVENT_ROOT="$PWD" TWO_EVENT_ARM="$arm" LAB_WORKSPACE="$PWD/ws"
export STEP5_INPUT="$PWD/$seq"
export LIO_TWO_EVENT_DIAGNOSTIC=1 LIO_FOUR_POLICY_DIAGNOSTIC=1 PLAY_RATE=1 REMAP=/velodyne_points:=/velodyne_points_raw
export OMP_THREAD_LIMIT=2 OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
out="$PWD/$seq/$rep/$arm"
mkdir -p "$(dirname "$out")"
mkdir "$out"
date -Is > "$out/started_at.txt"
duration="$(/usr/bin/python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["duration_s"])' "$STEP5_INPUT/population.json")"
code=0
timeout --signal=INT --kill-after=15 180 bash runner.sh "$out" "$STEP5_INPUT/study.bag" "$duration" > "$out/runner.log" 2>&1 || code=$?
printf '%s\n' "$code" > "$out/runner_exit.txt"
date -Is > "$out/finished_at.txt"
exit "$code"
