"""Bind the original scan population and reconstruct the relay input."""
import json
from pathlib import Path

from genpy import Time
import rosbag

from slam_recovery.ros.cloud_repair import corrupt_if_in_window


TOPIC = "/velodyne_points"
BAG = Path("/home/tong/datasets/mmlins/campus_12.bag")
RUN = Path("../campus12_tail_ab_20261124/with_recovery")
CHECKPOINT_NS = 1711548075773556736


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def stamp(ns):
    return Time(ns // 10**9, ns % 10**9)


def main():
    e1 = rows(RUN / "candidates_detail.jsonl")[0]
    stamps = set(e1["candidate_frame_ts_ns"])
    if len(stamps) != 40:
        raise ValueError("expected the 40 fixed E1 frames")
    relay = rows(RUN / "relay_frames.jsonl")
    injected = {r["stamp_ns"]: r for r in relay if r["event"] == "frame"}
    window = next(r for r in relay if r["event"] == "window")
    prefix = []
    found = set()
    with rosbag.Bag(str(BAG)) as source, rosbag.Bag("candidate_input.bag", "w", compression="lz4") as input_bag, rosbag.Bag(
        "evaluation_original.bag", "w", compression="lz4"
    ) as evaluation:
        for _, msg, t in source.read_messages(
            topics=[TOPIC],
            start_time=stamp(CHECKPOINT_NS - 5 * 10**9),
            end_time=stamp(max(stamps) + 10**9),
        ):
            key = msg.header.stamp.to_nsec()
            if key <= CHECKPOINT_NS:
                prefix.append((msg, t))
            if key in stamps:
                changed, was_shifted = corrupt_if_in_window(
                    msg, key, window["start_ns"], window["end_ns"], window["shift_z"]
                )
                row = injected[key]
                if key in found or not was_shifted or not row["shifted"] or row["points"] != msg.width * msg.height:
                    raise ValueError(f"scan does not match the recorded relay identity {key}")
                found.add(key)
                input_bag.write(TOPIC, changed, t)
                evaluation.write(TOPIC, msg, t)
    if found != stamps or len(prefix) < 40:
        raise ValueError("target or clean prefix population incomplete")
    prefix = prefix[-40:]
    with rosbag.Bag("calibration.bag", "w", compression="lz4") as train, rosbag.Bag(
        "clean_control.bag", "w", compression="lz4"
    ) as control:
        for msg, t in prefix[:30]:
            train.write(TOPIC, msg, t)
        for msg, t in prefix[30:]:
            control.write(TOPIC, msg, t)
    print(json.dumps({
        "e1_candidate": e1["candidate_id"],
        "checkpoint_stamp_ns": CHECKPOINT_NS,
        "calibration_stamps_ns": [msg.header.stamp.to_nsec() for msg, _ in prefix[:30]],
        "negative_control_stamps_ns": [msg.header.stamp.to_nsec() for msg, _ in prefix[30:]],
        "e1_stamps_ns": sorted(found),
        "input_path": str(BAG),
        "relay_trace_path": str(RUN / "relay_frames.jsonl"),
        "input_kind": "reconstructed real scan messages with original controlled relay",
        "injection": {key: window[key] for key in ("start_ns", "end_ns", "shift_z")},
    }, indent=2))


if __name__ == "__main__":
    main()
