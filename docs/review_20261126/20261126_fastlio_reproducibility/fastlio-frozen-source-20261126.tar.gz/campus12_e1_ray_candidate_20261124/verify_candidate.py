"""Compare independent returns against the frozen candidate on equal scan populations."""
from contextlib import ExitStack
from itertools import zip_longest
import json
from pathlib import Path

import numpy as np
import rosbag

from ray_candidate import measures


def metrics(errors):
    return {
        "points": int(errors.size),
        "mae_m": float(np.abs(errors).mean()),
        "rmse_m": float(np.sqrt(np.mean(errors ** 2))),
        "p95_abs_m": float(np.quantile(np.abs(errors), 0.95)),
    }


def check_identity(before, after):
    for attr in ("header", "height", "width", "point_step", "row_step",
                 "fields", "is_bigendian", "is_dense"):
        if getattr(before, attr) != getattr(after, attr):
            raise ValueError(f"changed message metadata: {attr}")
    z = next(field.offset for field in before.fields if field.name == "z")

    def payload(msg):
        return np.frombuffer(msg.data, dtype=np.uint8).reshape(msg.height, msg.row_step)

    lhs, rhs = payload(before), payload(after)
    changed_bytes = [col for col in range(before.row_step)
                     if col < before.width * before.point_step and z <= col % before.point_step < z + 4]
    altered = np.any(lhs != rhs, axis=0)
    altered[changed_bytes] = False
    if altered.any():
        raise ValueError("data bytes outside the z field changed")


def evaluate(names, model, expected_stamps):
    baselines, corrections, held_before, held_after = [], [], [], []
    details = []
    with ExitStack() as stack:
        bags = [stack.enter_context(rosbag.Bag(name)) for name in names]
        for rows in zip_longest(*(bag.read_messages() for bag in bags)):
            if None in rows:
                raise ValueError("message missing in one arm")
            (topic, original, t), (in_topic, before, in_time), (out_topic, after, out_time) = rows
            if topic != in_topic or topic != out_topic or t != in_time or t != out_time:
                raise ValueError("topic or bag timestamp changed")
            check_identity(original, before)
            check_identity(before, after)
            radial, z0, ring, reference_valid = measures(original)
            _, z1, _, _ = measures(before)
            _, z2, _, _ = measures(after)
            valid = np.isfinite(z0)
            if not np.array_equal(valid, np.isfinite(z1)) or not np.array_equal(valid, np.isfinite(z2)):
                raise ValueError("finite measurements changed identity")
            e1, e2 = z1[valid] - z0[valid], z2[valid] - z0[valid]
            expected = np.full(len(z0), np.nan)
            for beam, (slope, intercept) in model.items():
                if beam % 2:
                    mask = ring == beam
                    expected[mask] = slope * radial[mask] + intercept
            odd = reference_valid & np.isfinite(expected)
            if not odd.any():
                raise ValueError("empty odd-ring holdout")
            o1, o2 = z1[odd] - expected[odd], z2[odd] - expected[odd]
            baselines.append(e1)
            corrections.append(e2)
            held_before.append(o1)
            held_after.append(o2)
            details.append({
                "stamp_ns": original.header.stamp.to_nsec(),
                "original": {"before": metrics(e1), "after": metrics(e2)},
                "held_out_odd_rings": {"before": metrics(o1), "after": metrics(o2)},
            })
    if [row["stamp_ns"] for row in details] != expected_stamps:
        raise ValueError("population changed relative to the frozen event or clean control")
    return {
        "frames": len(details),
        "restored_frame_fraction_vs_original": sum(
            row["original"]["after"]["mae_m"] < row["original"]["before"]["mae_m"]
            for row in details
        ) / len(details),
        "improved_frame_count_odd_holdout": sum(
            row["held_out_odd_rings"]["after"]["mae_m"] < row["held_out_odd_rings"]["before"]["mae_m"]
            for row in details
        ),
        "original_return": {"before": metrics(np.concatenate(baselines)),
                            "after": metrics(np.concatenate(corrections))},
        "odd_ring_prediction": {"before": metrics(np.concatenate(held_before)),
                                "after": metrics(np.concatenate(held_after))},
        "per_frame": details,
        "full_non_z_message_payload_preserved": True,
    }


def main():
    split = json.loads(Path("stage_receipt.json").read_text())
    estimates = json.loads(Path("candidate_estimates.json").read_text())
    if split["calibration_stamps_ns"] != estimates["calibration_stamps_ns"]:
        raise ValueError("calibration stamp set changed")
    if set(split["calibration_stamps_ns"]) & set(split["negative_control_stamps_ns"] + split["e1_stamps_ns"]):
        raise ValueError("overlap between calibration and evaluation")
    model = {int(k): v for k, v in estimates["calibration_model"].items()}
    e1 = evaluate(("evaluation_original.bag", "candidate_input.bag", "repair_candidate.bag"),
                  model, split["e1_stamps_ns"])
    clean = evaluate(("clean_control.bag", "clean_control.bag", "clean_control_repaired.bag"),
                     model, split["negative_control_stamps_ns"])
    biases = np.array([row["subtract_z_m"] for row in estimates["candidate_frames"]])
    result = {
        "calibration_frames": len(split["calibration_stamps_ns"]),
        "calibration_rings": len(model),
        "candidate_bias_median_m": float(np.median(biases)),
        "candidate_bias_range_m": [float(biases.min()), float(biases.max())],
        "e1": e1,
        "clean_control": clean,
        "scope": "offline controlled measurement candidate; pose, map, and native gate not evaluated",
    }
    with Path("verification.json").open("x") as output:
        json.dump(result, output, indent=2, allow_nan=False)
        output.write("\n")
    print(json.dumps({k: {n:v for n,v in value.items() if n != "per_frame"} if isinstance(value,dict) else value
                      for k,value in result.items()}, indent=2))


if __name__ == "__main__":
    main()
