"""Estimate a single sensor-coordinate z correction from actual beam geometry."""
import argparse
from itertools import zip_longest
from pathlib import Path
import json

import numpy as np
import rosbag

from slam_recovery.ros.cloud_repair import shift_z_cloud


def measures(msg):
    fields = {field.name: field for field in msg.fields}
    order = ">" if msg.is_bigendian else "<"

    def column(name, dtype, datatype):
        field = fields[name]
        if field.datatype != datatype or field.count != 1:
            raise ValueError(f"unexpected format of {name}")
        return np.ndarray((msg.height, msg.width), dtype=order + dtype, buffer=msg.data,
                          offset=field.offset, strides=(msg.row_step, msg.point_step)).ravel()

    x, y, z = (column(axis, "f4", 7).astype(np.float64) for axis in "xyz")
    ring = column("ring", "u2", 4)
    radial = np.hypot(x, y)
    valid = np.isfinite(radial) & np.isfinite(z) & (np.hypot(radial, z) >= 4)
    return radial, z, ring, valid


def calibrate(path):
    values = []
    stamps = []
    with rosbag.Bag(str(path)) as bag:
        for _, msg, _ in bag.read_messages():
            r, z, beam, ok = measures(msg)
            values.append(np.stack((r[ok], z[ok], beam[ok]), axis=1))
            stamps.append(msg.header.stamp.to_nsec())
    radial, height, ring = np.concatenate(values).T
    models = {}
    for beam in np.unique(ring).astype(int):
        selected = ring == beam
        r = radial[selected]
        if len(r) < 2 or r.min() == r.max():
            continue
        slope, intercept = np.linalg.lstsq(
            np.column_stack((r, np.ones_like(r))), height[selected], rcond=None
        )[0]
        models[int(beam)] = (float(slope), float(intercept))
    return models, stamps


def estimate(msg, model):
    r, z, rings, valid = measures(msg)
    by_beam = []
    for beam, (slope, intercept) in model.items():
        if beam % 2:
            continue
        idx = valid & (rings == beam)
        if idx.any():
            by_beam.append(float(np.median(z[idx] - (slope * r[idx] + intercept))))
    if not by_beam:
        raise ValueError("no calibration beams observed in target frame")
    bias = float(np.median(by_beam))
    return bias, len(by_beam), float(np.median(np.abs(np.asarray(by_beam) - bias)))


def generate(model, input_name, output_name, receipt_existing):
    details = []
    with rosbag.Bag(input_name) as input_bag, rosbag.Bag(
        output_name, "r" if receipt_existing else "w", compression="lz4"
    ) as output:
        targets = output.read_messages() if receipt_existing else ()
        for src, target in zip_longest(input_bag.read_messages(), targets):
            if src is None or (receipt_existing and target is None):
                raise ValueError("existing candidate does not cover the source population")
            topic, msg, t = src
            bias, n_beams, mad = estimate(msg, model)
            corrected = shift_z_cloud(msg, -bias)
            if receipt_existing:
                actual_topic, actual, actual_t = target
                if actual_topic != topic or actual_t != t or actual.header != corrected.header or actual.data != corrected.data:
                    raise ValueError("existing candidate differs from recomputed measurement")
            else:
                output.write(topic, corrected, t)
            details.append({
                "stamp_ns": msg.header.stamp.to_nsec(),
                "subtract_z_m": bias,
                "even_beams": n_beams,
                "beam_median_residual_mad_m": mad,
            })
    return details


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--receipt-existing", action="store_true")
    args = parser.parse_args()
    model, stamps = calibrate("calibration.bag")
    receipt = {
        "calibration_stamps_ns": stamps,
        "calibration_model": model,
        "existing_outputs_byte_verified": args.receipt_existing,
        "candidate_frames": generate(model, "candidate_input.bag", "repair_candidate.bag", args.receipt_existing),
        "control_frames": generate(model, "clean_control.bag", "clean_control_repaired.bag", args.receipt_existing),
    }
    with Path("candidate_estimates.json").open("x") as output:
        json.dump(receipt, output, indent=2, allow_nan=False)
        output.write("\n")


if __name__ == "__main__":
    main()
