"""Check all four offline lifecycle acceptance gates on the frozen controller."""
import csv
import json
from pathlib import Path
import sys

import numpy as np


ROOT = Path(__file__).resolve().parent
MATRIX = ROOT.parent/"fastlio_full_cycle_matrix_20261126"
CLOCK = ROOT.parent/"fastlio_clock_return_edge_20261126"
sys.path.insert(0,str(MATRIX))
from score_matrix import base, event_lifecycle, event_actions, gt_for, integer


RUN_ORDER = ("z_shift","rigid_ramp","occlusion","attenuation","narrow_fov","sync",
             "accept_drop","rigid_occlusion","sync_narrow","eee_clean","sbs_clean")
REUSED = {}


def event_check(arm, window, expected):
    started, ended = window["onset_ns"],window["end_ns"]
    fault = [row for row in expected if row["event"]==window["id"]]
    keys = [row["stamp_ns"] for row in fault]
    fed = [row["fed_ns"] for row in fault]
    physical = {row["fed_ns"]:row["stamp_ns"] for row in expected}
    triggers = [row for row in event_actions(arm,"triggered") if row["alarm_scan_ns"] in fed]
    trigger = triggers[0] if len(triggers)==1 else None
    flow = event_lifecycle(arm,trigger,physical,keys,fed)
    flow["fault_public"] = sum(t in arm["public"] for t in keys)
    flow["source_scan_count"] = len(keys)
    flow["isolates"] = len(triggers)
    flow["detection_pass"] = bool(trigger and flow["checkpoint_before_fault"] and flow["hold_matches_checkpoint"]
                                  and flow["fault_public"]==0)
    eid = flow.get("episode")
    releases = [row for row in arm["receipt"]["events"] if row.get("episode")==eid
                and row["action"] in ("committed_released","refused_caught_up_released")]
    end = releases[0] if len(releases)==1 else None
    status = end["native_status"] if end else ""
    disposition = flow["outcome"]
    if end and disposition=="committed_released":
        flow["native_disposition_pass"] = flow["native_commit_verified"]
    elif end and disposition=="refused_caught_up_released":
        map_key = f"E{eid}_refusal.xyz32"
        refuge = arm["receipt"]["maps"].get(map_key,{})
        flow["refusal_map_hash_matches"] = refuge.get("sha256")==end["live_refusal_map_sha256"]
        healthy = flow["healthy_updates"]
        flow["native_disposition_pass"] = (flow["native_refusal_input_exact"] and healthy==2
            and flow["refusal_map_hash_matches"] and integer(status,"refusal_consumed")==len(keys)+healthy
            and "map_writes=released" in status)
    else:
        flow["native_disposition_pass"] = False
    if window["kind"]=="sync":
        flow["native_disposition_pass"] &= flow.get("retimed")==len(keys)
    pub = arm["public"]
    live = sorted(t for t,val in pub.items() if val["stamp_ns"]==flow.get("rearm_pose_ns"))
    after = sorted(key for key in pub if key>=ended)
    rearms = event_actions(arm,"rearmed",eid) if eid else []
    rearm = rearms[0] if len(rearms)==1 else None
    flow["rearm_key"] = live[0] if live else None
    flow["rearm_pass"] = bool(
        live and live[0]>=ended and rearm and "map_writes=released" in rearm["native_status"]
        and any(key>live[0] for key in after))
    flow["full_pass"] = (
        flow["full_closure"] and flow["detection_pass"] and flow["native_disposition_pass"] and flow["rearm_pass"])
    return flow


def main():
    fixed = base.read(MATRIX/"FIXED_INPUTS.json")
    new_fixtures = base.read(ROOT/"FIXTURES.json")
    archived = base.read(CLOCK/"FIXTURES.json")
    check_prefix = base.check_prefix

    def check(rows, expected):
        check_prefix([{k:r[k] for k in expected[0]} for r in rows],expected)

    base.check_prefix = check
    report = dict(cases={}, events=[], clean={})
    for case in RUN_ORDER:
        spec = fixed[case]
        population = spec["inputs"]
        origin = spec["origin_ns"]
        windows = spec["windows"]
        from_archive = case in REUSED
        folder, name = (CLOCK,REUSED[case]) if from_archive else (ROOT,case)
        fixture = archived[name] if from_archive else new_fixtures[name]
        assert fixture["input"]==spec
        base.ROOT = MATRIX
        native = base.load_arm(case+"_native",population)
        base.ROOT = folder
        arm = base.load_arm(name,population)
        r = arm["receipt"]
        trace = [row[:3] for row in arm["telemetry"]["receiver_trace"]]
        fault_fed = {row["fed_ns"] for row in population if row["event"] is not None}
        extra = [row for row in event_actions(arm,"triggered") if row["alarm_scan_ns"] not in fault_fed]
        actual_resets = [x for x in arm["health"] if x["kind"] in ("native_re_slam","native_imu_reset")]
        row = dict(reused=from_archive,input_count=len(arm["relay"]),native_public=len(native["public"]),
                   plugin_public=len(arm["public"]),source_exit=r["code"],extra_triggers=extra,
                   actual_resets=actual_resets,private_leak=r["private_leaked"],
                   strict_public=r["public_increasing"], exact_trace=trace==fixture["receiver"],
                   final_mode=(r["final"] or {}).get("mode"),full_input=arm["complete_input"],
                   unbound_public=len(arm["unbound"]))
        row["integrity"] = bool(row["source_exit"]==0 and row["full_input"] and row["exact_trace"]
                               and row["strict_public"] and not extra and not actual_resets and not row["private_leak"]
                               and not arm["unbound"] and row["final_mode"]=="ARMED")
        report["cases"][case] = row
        if not windows:
            shared = sorted(set(arm["public"]) & set(native["public"]))
            delta = np.array(base.latencies(arm,shared))-base.latencies(native,shared)
            missing = sorted(set(native["public"])-set(arm["public"]))
            surplus = set(arm["public"])-set(native["public"])
            report["clean"][case] = dict(passed=row["integrity"] and not missing and not surplus,
                missing=len(missing),surplus=len(surplus),paired=len(shared),false_isolates=len(extra),
                native_public=len(native["public"]),plugin_public=len(arm["public"]),
                p50_ms=float(np.median(delta)) if len(delta) else None,
                p95_ms=float(np.quantile(delta,.95)) if len(delta) else None)
            continue
        truth = gt_for(spec["site"])
        common = sorted(arm["poses"].keys() & native["poses"].keys())
        reference = {t:v for t in common if (v:=base.interp(*truth,native["poses"][t][1])) is not None}
        previous_rearm = None
        for j,w in enumerate(windows):
            lo,hi = w["onset_ns"],w["end_ns"]
            tail = min(hi+3*base.NS,windows[j+1]["onset_ns"]) if j+1<len(windows) else hi+3*base.NS
            flow = event_check(arm,w,population)
            before = max((t for t in reference if t<lo and t in arm["public"] and t in native["public"]),default=None)
            keys = [t for t in reference if lo<=t<tail]
            published = sorted(t for t in arm["public"] if lo<=t<tail)
            pre_pub = max((t for t in arm["public"] if t<lo),default=None)
            flow.update(case=case,event=w["id"],kind=w["kind"],reused=from_archive,
                        gap_s=(published[0]-pre_pub)/base.NS if pre_pub is not None and published else None,
                        public=len(published),native_public=sum(lo<=t<tail for t in native["public"]),
                        rearm_data_s=(flow["rearm_key"]-origin)/base.NS if flow["rearm_key"] else None,
                        chained=(previous_rearm is not None and previous_rearm<lo) if j else None,
                        rmse=dict(native=base.displacement_error(native,keys,before,reference),
                                  plugin=base.displacement_error(arm,keys,before,reference)))
            report["events"].append(flow)
            previous_rearm = flow["rearm_key"]
    all_events = report["events"]
    by_case = {case:[e for e in all_events if e["case"]==case] for case in RUN_ORDER}
    solos = [e for e in all_events if len(by_case[e["case"]])==1]
    doubles = {case:len(rows)==2 and all(row["full_pass"] for row in rows) and rows[1]["chained"]
               for case,rows in by_case.items() if len(rows)==2}
    accept = by_case["accept_drop"]
    report["gates"] = dict(
        detection_isolation=len(solos)==6 and all(e["detection_pass"] for e in solos),
        writeback_and_safe_refusal=(accept[0]["outcome"]=="committed_released"
            and accept[1]["outcome"]=="refused_caught_up_released"
            and all(e["native_disposition_pass"] for e in all_events)),
        reentry_and_rearm=len(all_events)==12 and all(e["full_pass"] for e in all_events)
            and len(doubles)==3 and all(doubles.values()),
        clean=len(report["clean"])==2 and all(row["passed"] for row in report["clean"].values()))
    report["double_cases"] = doubles
    report["passed"] = all(report["gates"].values()) and all(c["integrity"] for c in report["cases"].values())
    (ROOT/"RESULTS.json").write_text(json.dumps(report,indent=2,allow_nan=False)+"\n")
    with (ROOT/"EVENTS.csv").open("w",encoding="utf-8",newline="") as stream:
        out = csv.writer(stream)
        out.writerow(("case","event","fault","reused","fault_scans","triggered","decision","map_updates",
                      "retimed","localization_only","imu_only","full_pass","rearm_s","published","native_published",
                      "public_gap_s","common_scans","native_rmse_m","plugin_rmse_m"))
        for e in all_events:
            out.writerow([e["case"],e["event"],e["kind"],e["reused"],e["source_scan_count"],e["isolates"],
                          e["outcome"],e.get("public_map_updates"),e.get("retimed"),e.get("localization"),
                          e.get("imu_only"),e["full_pass"],e["rearm_data_s"],e["public"],e["native_public"],
                          e["gap_s"],e["rmse"]["plugin"]["n"],e["rmse"]["native"]["rmse_m"],e["rmse"]["plugin"]["rmse_m"]])
    print(json.dumps({"passed":report["passed"],"gates":report["gates"],"double_cases":doubles,
                      "events_passed":sum(e["full_pass"] for e in all_events),"clean":report["clean"]},indent=2))


if __name__=="__main__":
    main()
