#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "$0")"
source /opt/ros/noetic/setup.bash
base=$(dirname "$PWD")
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1
export PYTHONPATH="$base/fastlio_mixed_recovery_20261125:$base/fastlio_fault_bridge_matrix_20261125:$base/ntuviral_fastlio_step5_20261125:$base/python:$PYTHONPATH"
exec /usr/bin/python3 "$@"
