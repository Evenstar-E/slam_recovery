#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "$0")"
root=$(dirname "$PWD")
evidence_root="$PWD"
matrix="$root/fastlio_full_cycle_matrix_20261126"
clock="$root/fastlio_clock_return_edge_20261126"
version="$root/fastlio_stability_20261126/v2"
sha256sum -c --quiet EXPERIMENT.sha256
cmp "$clock/run_return.py" run_return.py
(cd "$version" && sha256sum -c --quiet FREEZE.sha256 && sha256sum -c --quiet HOST_SHA256)
for evidence in "$matrix" "$clock" "$root/fastlio_rtp03_clock_retiming_20261126" "$root/fastlio_rtp03_clock_confirmation_20261126"; do
    (cd "$evidence" && sha256sum -c --quiet REVIEW_EVIDENCE.sha256)
done
(cd "$matrix" && sha256sum -c --quiet SOURCES.sha256)
(
    cd "$root"
    sha256sum fastlio_clock_return_edge_20261126/{run_return.py,clock_return_edge.py,REVIEW_EVIDENCE.sha256} \
        fastlio_full_cycle_matrix_20261126/{run_matrix.py,FIXED_INPUTS.json,REVIEW_EVIDENCE.sha256} \
        fastlio_rtp03_clock_retiming_20261126/sensor_clock_retiming.py \
        fastlio_rtp03_clock_confirmation_20261126/{clock_confirmation.py,run_confirmation.py} \
        fastlio_stability_20261126/v2/{BINARY.sha256,FREEZE.sha256,HOST_SHA256}
) > SOURCE_BINDINGS.sha256
while read -r stage profile; do
    rc=0
    started=$(date -Is)
    bash run_case.sh "$profile" "$profile" || rc=$?
    printf '%s %s %s %s %s\n' "$stage" "$profile" "$rc" "$started" "$(date -Is)" >> STATUS.txt
    if [[ -d "$profile" && -s "$profile/finished_at.txt" ]]; then
        if [[ ! -s "$profile/exit.txt" ]]; then printf '%s\n' "$rc" > "$profile/exit.txt"; fi
        bash offline.sh compact.py "$profile"
    fi
done <<'TABLE'
1 z_shift
1 rigid_ramp
1 occlusion
1 attenuation
1 narrow_fov
2 accept_drop
3 rigid_occlusion
4 eee_clean
4 sbs_clean
TABLE
sha256sum -c --quiet EXPERIMENT.sha256
(cd "$root" && sha256sum -c --quiet "$evidence_root/SOURCE_BINDINGS.sha256")
(cd "$matrix" && sha256sum -c --quiet SOURCES.sha256)
(cd "$version" && sha256sum -c --quiet FREEZE.sha256 && sha256sum -c --quiet HOST_SHA256)
printf '%s\n' 'Each new run was compacted and its transient logs, runtime state and private exported maps were removed. No new bag was created.' > CLEANUP.txt
