"""Development registration on LiDAR timestamps with a short-window IMU prior."""
import cv2
import numpy as np

from bridge_shared import AXIS_Z, Fit, GATES, Neighbors, translation_and_step
from slam_recovery.repair.pose_reregistration import (
    MIN_CORRESPONDENCES, MOTION_PRIOR_BASE_M, STEP_DAMPING, estimate_normals,
)

JOINT_GATES = ((2.4, 8), (1.2, 6), (.6, 5), (.5, 4), (.25, 4))
ROTATION_REPORT_RAD = np.deg2rad(2.)


def angle(r):
    return float(np.linalg.norm(cv2.Rodrigues(r)[0]))


def cloud_geometry(cloud):
    index = Neighbors(cloud)
    normals, usable = estimate_normals(cloud, grid=index)
    return index, normals, usable


def fit_edge(previous, current, geometry, rotation, prior, joint=False):
    idx, normals, usable = geometry
    heldout = current[::5]
    sample = current[np.arange(len(current)) % 5 != 0][::2]
    r, p = rotation.copy(), prior.copy()
    rank = 0
    for gate, iterations in JOINT_GATES if joint else GATES:
        for _ in range(iterations):
            shifted = sample @ r.T + p
            keys, distances = idx.query(shifted)
            keys = keys[:, 0]
            use = (distances[:, 0] <= gate * gate) & usable[keys]
            if np.count_nonzero(use) < MIN_CORRESPONDENCES:
                break
            n = normals[keys[use]]
            error = np.einsum("ij,ij->i", n, shifted[use] - previous[keys[use]])
            matrix = np.column_stack((n, np.cross(shifted[use] - p, n))) if joint else n
            delta, _, rank, _ = np.linalg.lstsq(matrix, -error, rcond=None)
            scale = STEP_DAMPING
            if joint:
                scale = min(scale, .6 / max(np.linalg.norm(delta[:3]), 1e-12),
                            .17 / max(np.linalg.norm(delta[3:]), 1e-12))
                r = cv2.Rodrigues(scale * delta[3:])[0] @ r
            p += scale * delta[:3]
            if np.linalg.norm(delta) < 1e-6:
                break
    x = heldout @ r.T + p
    keys, distances = idx.query(x)
    keys = keys[:, 0]
    use = (distances[:, 0] <= 1.) & usable[keys]
    n = normals[keys[use]]
    residual = np.einsum("ij,ij->i", n, x[use] - previous[keys[use]])
    strength = np.column_stack((n, np.cross(x[use] - p, n))) if joint else n
    n_support = len(residual)
    lam = float(np.linalg.eigvalsh(strength.T @ strength / max(n_support, 1))[0])
    available = rank == (6 if joint else 3) and n_support >= max(MIN_CORRESPONDENCES, .6 * len(heldout))
    return r, Fit(p, n_support, len(heldout),
                  float(np.sqrt(np.mean(residual**2))) if n_support else float("nan"), lam, available)


def separate_bias(r_obs, p_obs, r_imu, p_prior, a_prev, b_prev):
    """Observed transform: A_prev R_imu A_next^T, A_prev p + b_prev - R_obs b_next."""
    a_next = r_obs.T @ a_prev @ r_imu
    predicted = a_prev @ p_prior + b_prev - r_obs @ b_prev
    change = p_obs - predicted
    step = float(np.linalg.norm(change)) >= MOTION_PRIOR_BASE_M
    b_next = b_prev - r_obs.T @ change if step else b_prev
    motion = a_prev.T @ (p_obs - b_prev + r_obs @ b_next)
    return motion, a_next, b_next, step, float(np.linalg.norm(change))


MODES = ("imu_only", "lidar_imu", "z_step", "joint_direct", "joint_bias")


def estimate(clouds, rotations, stamps, accel, p0, v0, extr_t):
    """Receives only chronological scans, IMU-derived quantities and the pre-fault state."""
    cv2.setNumThreads(1)
    state = {mode: dict(p=p0.copy(), v=v0.copy(), b_z=0., b=np.zeros(3), a=np.eye(3), rows=[
        dict(stamp_ns=int(stamps[0]), lidar_position=p0.tolist(), physical_rotation=rotations[0].tolist())])
        for mode in MODES}
    for i in range(1, len(stamps)):
        cv2.setRNGSeed(31 + i)
        previous, current = clouds[i-1], clouds[i]
        geometry = cloud_geometry(previous)
        dt = (stamps[i] - stamps[i-1]) * 1e-9
        r_prev = rotations[i-1]
        r_imu = r_prev.T @ rotations[i]
        acc = (accel[i] + accel[i-1]) * .5
        lever = (rotations[i] - r_prev) @ extr_t
        fits = {}
        for mode, s in state.items():
            displacement = s["v"]*dt + .5*acc*dt*dt
            prior = r_prev.T @ (displacement + lever)
            s["v"] += acc*dt
            fit = None
            step = False
            innovation = None
            rot_change = None
            if mode == "lidar_imu":
                fits["translation"] = fit_edge(previous, current, geometry, r_imu, prior)
            if mode == "joint_direct":
                fits["joint"] = fit_edge(previous, current, geometry, r_imu, prior, joint=True)
            if mode != "imu_only":
                r_obs, fit = fits["joint" if mode.startswith("joint_") else "translation"]
                if fit.available:
                    p = fit.pose_translation
                    if mode == "z_step":
                        p, s["b_z"], step, innovation, _ = translation_and_step(p, prior, r_imu, s["b_z"])
                    elif mode == "joint_bias":
                        before = s["a"]
                        p, s["a"], s["b"], step, innovation = separate_bias(
                            r_obs, p, r_imu, prior, before, s["b"])
                        rot_change = angle(before.T @ s["a"])
                    displacement = r_prev @ p - lever
                    s["v"] = .8*s["v"] + .2*(displacement/dt + .5*acc*dt)
            s["p"] += displacement + lever
            s["rows"].append(dict(
                stamp_ns=int(stamps[i]), lidar_position=s["p"].tolist(),
                physical_rotation=rotations[i].tolist(),
                used_lidar=bool(fit is not None and fit.available),
                supported=fit.supported if fit else None,
                support_total=fit.total if fit else None,
                holdout_rmse=fit.holdout_rms if fit and np.isfinite(fit.holdout_rms) else None,
                geometry_min_eig=fit.min_eigenvalue if fit else None,
                translation_step=step, translation_innovation_m=innovation,
                rotation_change_deg=np.rad2deg(rot_change) if rot_change is not None else None,
                rotation_step=bool(rot_change is not None and rot_change >= ROTATION_REPORT_RAD),
                rotation_bias=s["a"].tolist() if mode == "joint_bias" else None,
                shift_bias_m=s["b"].tolist() if mode == "joint_bias" else None,
                z_bias_m=float(s["b_z"]) if mode == "z_step" else None,
            ))
    return {mode: s["rows"] for mode, s in state.items()}
