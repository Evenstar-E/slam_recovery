#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "$0")"
source /opt/ros/noetic/setup.bash
export PYTHONDONTWRITEBYTECODE=1
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export PYTHONPATH="$PWD/../short_window_bridge_20261125:/home/tong/src/slam_recovery:$PYTHONPATH"
sha256sum -c SOURCES.sha256
sha256sum -c INPUT.sha256
sha256sum -c PRISM_EVALUATION_INPUT.sha256
date -Iseconds > STARTED.txt
set +e
timeout --kill-after=10s 900s /usr/bin/python3 -u run_rigid.py > RUN.log 2>&1
code=$?
date -Iseconds > FINISHED.txt
echo "$code" > EXIT.txt
exit "$code"
