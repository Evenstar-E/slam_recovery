#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "$0")"
source /opt/ros/noetic/setup.bash
export PYTHONPATH="/home/tong/src/slam_recovery:$PYTHONPATH"
export OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
test "$(cat EXIT.txt)" = 0
/usr/bin/python3 score.py
echo 0 > SCORE_EXIT.txt
