"""Prepare matched blind inputs and serialize every arm from the existing EEE bag."""
import json
from pathlib import Path
import time

import cv2
import numpy as np
import rosbag
import yaml

from run_bridge_event1 import message_xyz, scalp, interp_matrix, INPUT, PAST, NS
from rigid_bridge import estimate

ROOT = Path(__file__).resolve().parent
AXIS = np.array([1., 1., 2.]) / np.sqrt(6.)
SHIFT = np.array([0., 0., 1.5])
ANGLE_DEG = 20.
HOLD_NS = 2 * NS


def amplitudes(starts, events):
    out = np.zeros(len(starts))
    for event in events:
        on, end = event["onset_ns"], event["end_ns"]
        mask = (starts >= on) & (starts < end)
        u = np.clip((starts[mask] - on - HOLD_NS) / (end - on - HOLD_NS), 0., 1.)
        out[mask] = .5*(1. + np.cos(np.pi*u))
    return out


def main():
    origin = int(json.loads((INPUT/"population.json").read_text())["start_ns"])
    events = [e for e in json.loads((INPUT/"events.json").read_text()) if e["inject_z_m"]]
    cfg = yaml.safe_load((ROOT/"ntulab.yaml").read_text())
    extr_r = np.asarray(cfg["mapping"]["extrinsic_R"], dtype=float).reshape(3,3)
    extr_t = np.asarray(cfg["mapping"]["extrinsic_T"], dtype=float)
    assert np.allclose(extr_r, np.eye(3))
    scans, imu, gyro, accel = [], [], [], []
    with rosbag.Bag(str(INPUT/"study.bag")) as bag:
        for topic, msg, _ in bag.read_messages(topics=["/velodyne_points", "/imu_raw"]):
            at = msg.header.stamp.to_nsec()
            if at < origin+28*NS:
                continue
            if at > origin+63*NS:
                break
            if topic == "/imu_raw":
                imu.append(at)
                gyro.append(message_xyz(msg.angular_velocity))
                accel.append(message_xyz(msg.linear_acceleration))
            elif origin+31*NS <= at < origin+62*NS:
                raw, offset, end_offset = scalp(msg)
                scans.append((at, at+end_offset, raw, at+offset))
    t = np.asarray(imu, dtype=np.int64)
    starts = np.asarray([x[0] for x in scans], dtype=np.int64)
    ends = np.asarray([x[1] for x in scans], dtype=np.int64)
    assert np.all(np.diff(t)>0) and np.all(np.diff(ends)>0)
    past = list(map(json.loads, PAST.open()))
    anchor = np.array(next(r["T_wb"] for r in past if r["scan_stamp_ns"] == starts[0])).reshape(4,4)
    prefix = [r for r in past if starts[0]-500_000_000 <= r["scan_stamp_ns"] <= starts[0]]
    xyz = np.array([np.array(r["T_wb"]).reshape(4,4)[:3,3] for r in prefix])
    times = (np.array([r["scan_stamp_ns"] for r in prefix], dtype=np.int64)-starts[0])*1e-9
    v0 = np.linalg.lstsq(np.column_stack((np.ones(len(times)),times)),xyz,rcond=None)[0][1]
    g, a = np.array(gyro), np.array(accel)
    quiet = (t >= origin+29*NS) & (t < origin+31*NS)
    assert quiet.sum()>100
    g -= g[quiet].mean(axis=0)
    relative = [np.eye(3)]
    for i, dt in enumerate(np.diff(t)*1e-9):
        relative.append(relative[-1] @ cv2.Rodrigues(.5*(g[i]+g[i+1])*dt)[0])
    relative = np.asarray(relative)
    u, _, vt = np.linalg.svd(interp_matrix(np.array([ends[0]]),t,relative)[0])
    world_from_rel = anchor[:3,:3] @ (u @ vt).T
    orientations = world_from_rel @ relative
    u, _, vt = np.linalg.svd(interp_matrix(ends,t,orientations))
    rotations = u @ vt
    a_world = np.einsum("nij,nj->ni", orientations, a)
    a_world -= a_world[quiet].mean(axis=0)
    steps = np.stack([np.interp((ends-t[0])*1e-9,(t-t[0])*1e-9,a_world[:,i])
                      for i in range(3)],axis=-1)
    mag = amplitudes(starts, events)
    assert np.count_nonzero(mag)==sum(e["frames"] for e in events)
    powers = {"clean":np.zeros(len(starts)), "jump_and_ramp":mag,
              "sustained":np.where(starts>=events[0]["onset_ns"],1.,0.)}
    deck = [interp_matrix(s[3], t, orientations) for s in scans]
    run_start = time.monotonic()
    for name, scale in powers.items():
        clouds = []
        for i, (_, _, points, _) in enumerate(scans):
            p = points
            if scale[i] != 0:
                change = cv2.Rodrigues(AXIS*(np.deg2rad(ANGLE_DEG)*scale[i]))[0]
                p = points @ change.T + scale[i]*SHIFT
            clouds.append(np.einsum("nij,nj->ni", deck[i], p) @ rotations[i])
        elapsed = time.monotonic()
        results = estimate(clouds, rotations, ends, steps, anchor[:3,3], v0, extr_t)
        config = dict(arm=name, origin=int(origin), scans=starts.tolist(), stamps=ends.tolist(),
                      imu_samples=len(t), extrinsic_t=extr_t.tolist(), injection_amplitude=scale.tolist(),
                      rotation_axis=AXIS.tolist(), max_rotation_deg=ANGLE_DEG, max_shift_m=SHIFT.tolist(),
                      events=events, hold_ns=HOLD_NS, runtime_s=time.monotonic()-elapsed,
                      outcomes=results)
        (ROOT/f"{name}.json").write_text(json.dumps(config, allow_nan=False, separators=(",",":"))+"\n")
        print(f"{name} {len(starts)} scans {config['runtime_s']:.3f} s", flush=True)
    print(f"Total estimator wall {time.monotonic()-run_start:.3f} s", flush=True)


if __name__ == "__main__":
    main()
