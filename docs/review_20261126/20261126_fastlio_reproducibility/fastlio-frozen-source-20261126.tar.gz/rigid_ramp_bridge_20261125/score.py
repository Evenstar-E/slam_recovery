"""Score matched sensor arms against independent prism positions."""
import json
from pathlib import Path
import sys

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
REF = ROOT.parent / "ntuviral_fastlio_step5_20261125"
sys.path.insert(0, str(REF))
from ground_truth_eval import PRISM_IN_BODY, fit, interp, read_gt

NS = 1_000_000_000
ARMS = ("clean", "jump_and_ramp", "sustained")


def stats(values):
    v = np.asarray(values, dtype=float)
    return dict(n=len(v), rmse=float(np.sqrt(np.mean(v**2))),
                median=float(np.median(v)), maximum=float(np.max(v))) if len(v) else dict(n=0)


def pairs_in(mask, valid, timestamps):
    indexes = np.flatnonzero(mask & valid)
    pairs = []
    for i in indexes:
        target = timestamps[i] + NS
        j = int(np.searchsorted(timestamps, target))
        candidates = [k for k in (j-1, j) if i<k<len(timestamps)]
        if not candidates:
            continue
        j = min(candidates, key=lambda k: abs(timestamps[k]-target))
        if abs(timestamps[j]-target) <= 50_000_000 and mask[j] and valid[j]:
            pairs.append((i,j))
    return np.asarray(pairs, dtype=int).reshape(-1,2)


def prism(rows, extr_t):
    positions = np.asarray([r["lidar_position"] for r in rows])
    rotations = np.asarray([r["physical_rotation"] for r in rows])
    return positions + rotations @ (PRISM_IN_BODY - extr_t)


def run():
    data = {name:json.loads((ROOT/f"{name}.json").read_text()) for name in ARMS}
    common = data["clean"]
    time = np.asarray(common["stamps"], dtype=np.int64)
    starts = np.asarray(common["scans"], dtype=np.int64)
    elapsed = (starts-common["origin"])/NS
    arm_nominal = data["jump_and_ramp"]
    assert all(a["scans"] == common["scans"] and a["stamps"] == common["stamps"] for a in data.values())
    imu = common["outcomes"]["imu_only"]
    assert all(a["outcomes"]["imu_only"] == imu for a in data.values())
    exposure = np.asarray(arm_nominal["injection_amplitude"])
    assert np.all(exposure >= 0) and np.all(exposure <= 1)
    reference_stamps, coords = read_gt(REF/"incoming"/"eee_03_gt.csv")
    gt = np.asarray([g if (g:=interp(reference_stamps,coords,int(t))) is not None else [np.nan]*3 for t in time])
    valid = np.isfinite(gt).all(axis=1)
    extr_t = np.asarray(common["extrinsic_t"])
    clean_est = prism(common["outcomes"]["lidar_imu"], extr_t)
    alignment, receipt = fit(clean_est[valid], gt[valid])
    phases = {"whole":np.ones(len(time),dtype=bool)}
    phases["pre"] = starts < common["events"][0]["onset_ns"]
    phases["both_injected"] = exposure > 0
    for k, event in enumerate(common["events"],1):
        on, off = event["onset_ns"], event["end_ns"]
        limit = common["events"][k]["onset_ns"] if k < len(common["events"]) else starts[-1]+1
        phases[f"E{k}_injected"] = (starts>=on)&(starts<off)
        phases[f"E{k}_hold"] = (starts>=on)&(starts<on+common["hold_ns"])
        phases[f"E{k}_ramp"] = (starts>=on+common["hold_ns"])&(starts<off)
        phases[f"E{k}_post"] = (starts>=off)&(starts<limit)
        assert np.count_nonzero(phases[f"E{k}_injected"])==event["frames"]
        assert np.all(exposure[phases[f"E{k}_hold"]]==1.)
        taper = exposure[phases[f"E{k}_ramp"]]
        assert np.all(np.diff(taper)<0) and np.all((taper>0)&(taper<1))
    assert np.all(exposure[phases["E1_post"] | phases["E2_post"]] == 0.)
    pair_masks = {name:pairs_in(mask,valid,time) for name,mask in phases.items()}
    # Also score at the actual measured prism timestamps, estimating poses between adjacent scans.
    actual = np.asarray(reference_stamps,dtype=np.int64)
    actual = actual[(actual>=time[0])&(actual<=time[-1])]
    actual_coords = np.asarray([coords[int(t)] for t in actual])
    hi = np.searchsorted(time,actual)
    lo = np.where(time[hi]==actual,hi,hi-1)
    span = time[hi]-time[lo]
    weight = np.divide(actual-time[lo],span,out=np.zeros(len(actual)),where=span>0)
    actual_masks = {name:mask[lo]&mask[hi]&(span<=150_000_000) for name,mask in phases.items()}
    actual_pairs = {name:pairs_in(mask,np.ones(len(actual),dtype=bool),actual)
                    for name,mask in actual_masks.items()}
    overview = dict(scan_count=len(time), imu_samples=common["imu_samples"], matched_prism=int(valid.sum()),
                    actual_prism_stamps=len(actual),
                    scan_scope_s=[float(elapsed[0]),float(elapsed[-1])],
                    same_imu_and_scan_population=True, common_secondary_alignment=receipt,
                    runtimes_s={name:a["runtime_s"] for name,a in data.items()}, arms={})
    before_stop = int(np.flatnonzero(phases["E1_hold"])[0])
    split = int(np.flatnonzero(phases["E1_ramp"])[0])
    overview["common_pre_onset_chains_exact"] = all(a["outcomes"][m][:before_stop] == common["outcomes"][m][:before_stop]
        for m in common["outcomes"] for a in data.values())
    overview["common_first_hold_chains_exact"] = all(arm_nominal["outcomes"][m][:split] == data["sustained"]["outcomes"][m][:split]
        for m in common["outcomes"])
    for name, arm in data.items():
        overview["arms"][name] = {}
        for mode, rows in arm["outcomes"].items():
            raw = prism(rows, extr_t)
            corrected = raw @ alignment[0].T + alignment[1] if alignment is not None else None
            pose_at_actual = raw[lo] + weight[:,None]*(raw[hi]-raw[lo])
            panel = dict(phases={}, changes=[], events=[])
            for phase, mask in phases.items():
                eligible = np.flatnonzero(mask & valid)
                ii,jj = pair_masks[phase].T
                errors = np.abs(np.linalg.norm(raw[jj]-raw[ii],axis=1)-np.linalg.norm(gt[jj]-gt[ii],axis=1))
                held = np.array([r.get("used_lidar",False) for r in rows])
                fit_rms = [r["holdout_rmse"] for r, use in zip(rows,mask) if use and r.get("holdout_rmse") is not None]
                ri,rj = actual_pairs[phase].T
                errors_at_actual = np.abs(np.linalg.norm(pose_at_actual[rj]-pose_at_actual[ri],axis=1)
                    - np.linalg.norm(actual_coords[rj]-actual_coords[ri],axis=1))
                panel["phases"][phase] = dict(
                    eligible_prism=len(eligible), heldout_edges=int(np.count_nonzero(mask & held)),
                    edges=int(np.count_nonzero(mask[1:])), holdout_fit_residual_m=stats(fit_rms),
                    one_second_length_error_m=stats(errors),
                    one_second_at_measured_prism_stamps_m=stats(errors_at_actual),
                    secondary_position_error_m=stats(np.linalg.norm(corrected[eligible]-gt[eligible],axis=1)) if corrected is not None else None)
            for i,r in enumerate(rows):
                if r.get("rotation_step") or r.get("translation_step"):
                    panel["changes"].append(dict(time_s=float(elapsed[i]), inject_scale=arm["injection_amplitude"][i],
                        translation_step=r.get("translation_step"), rotation_step=r.get("rotation_step"),
                        rotation_change_deg=r.get("rotation_change_deg"), translation_innovation_m=r.get("translation_innovation_m")))
            for event in common["events"]:
                onset = int(np.searchsorted(starts,event["onset_ns"]))
                after = int(np.searchsorted(starts,event["end_ns"]))
                j = min(after + 20, len(time)-1)
                item = dict(id=event["id"], landmarks=[])
                for i in (onset,onset+10,after-1,after,j):
                    r = rows[i]
                    delta = raw[i]-raw[onset-1]
                    expected = gt[i]-gt[onset-1]
                    point = dict(time_s=float(elapsed[i]),
                        known_shift_m=1.5*arm["injection_amplitude"][i],
                        known_rotation_deg=20*arm["injection_amplitude"][i],
                        relative_length_estimated_m=float(np.linalg.norm(delta)),
                        relative_length_prism_m=float(np.linalg.norm(expected)) if np.isfinite(expected).all() else None,
                        secondary_relative_vector_error_m=float(np.linalg.norm(delta@alignment[0].T-expected))
                            if alignment is not None and np.isfinite(expected).all() else None,
                        used_lidar=r.get("used_lidar",False))
                    b = r.get("shift_bias_m")
                    if b is not None:
                        point["inferred_shift_m"] = b
                        point["inferred_rotation_deg"] = float(np.rad2deg(np.linalg.norm(cv2.Rodrigues(np.asarray(r["rotation_bias"]))[0])))
                    item["landmarks"].append(point)
                panel["events"].append(item)
            overview["arms"][name][mode] = panel
    (ROOT/"RESULTS.json").write_text(json.dumps(overview,indent=2,allow_nan=False)+"\n")


if __name__ == "__main__":
    run()
