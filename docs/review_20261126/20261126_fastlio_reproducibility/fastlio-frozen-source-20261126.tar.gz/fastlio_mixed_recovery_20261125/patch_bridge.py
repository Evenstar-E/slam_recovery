from pathlib import Path
p=Path("ws/src/FAST-LIO/src/laserMapping.cpp")
s=p.read_text()
def one(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b)
one("static int lab_refusal_expected = 0;","""static int lab_refusal_expected = 0;
static bool lab_bridge_pending = false;
static Eigen::Vector3d lab_bridge_target = Eigen::Vector3d::Zero();""")
one('            lab_refusal_expected = (int)g_nr_groups.size();','''            lab_bridge_pending = false;
            Eigen::Vector3d delta;
            if (args >> delta.x() >> delta.y() >> delta.z())
            {
                if (!delta.allFinite()) { nr_write_ack("OK reprocess_refusal valid=0 reason=invalid_bridge"); return; }
                lab_bridge_target = g_nr_cp.x.pos + delta;
                lab_bridge_pending = true;
            }
            lab_refusal_expected = (int)g_nr_groups.size();''')
one('            p_imu->Process(Measures, kf, feats_undistort, Degradationpre_point);','''            if (refusal_suffix && lab_bridge_pending)
            {
                auto x = kf.get_x();
                const Eigen::Vector3d correction = lab_bridge_target - x.pos;
                x.pos = lab_bridge_target;
                kf.change_x(x);
                lab_bridge_pending = false;
                std::ofstream applied(g_nr_dir + "/bridge_applied.jsonl", std::ios::app);
                applied << "{\\\"episode\\\":" << lab_episode
                    << ",\\\"stamp_ns\\\":" << (long long)std::llround(Measures.lidar_beg_time * 1e9)
                    << ",\\\"correction_m\\\":[" << correction.x() << "," << correction.y() << "," << correction.z()
                    << "]}" << std::endl;
            }
            p_imu->Process(Measures, kf, feats_undistort, Degradationpre_point);''')
p.write_text(s)
