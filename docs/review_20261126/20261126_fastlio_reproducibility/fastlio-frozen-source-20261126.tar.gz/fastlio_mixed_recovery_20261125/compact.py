"""Seal numeric source data and receipts, then remove generated per-case logs."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import numpy as np

ROOT=Path(__file__).resolve().parent


def read(path):
    return [json.loads(row) for row in path.read_text().replace("}"+chr(92)+"n","}\n").splitlines()] if path.is_file() else []


def main(name):
    p=(ROOT/name).resolve()
    assert p.parent==ROOT and (p/"finished_at.txt").is_file()
    folder=p/"ctl"
    relay=read(p/"relay_frames.jsonl")
    assert relay
    fed=np.asarray([r["fed_ns"] for r in relay],dtype=np.int64)
    actual_pose={}
    fate=read(folder/"input_fates.jsonl")
    def locate(ts):
        i=int(np.searchsorted(fed,ts))
        return min((j for j in (i-1,i) if 0<=j<len(fed)),key=lambda j:abs(int(fed[j])-ts))
    for item in fate:
        i=locate(round(item["beg_s"]*1e9))
        if abs(fed[i]-round(item["beg_s"]*1e9))<=2500:
            actual_pose[item["stamp_ns"]]=i
    events=read(p/"events_result.jsonl")
    refused={e["episode"] for e in events if e["action"]=="refused_caught_up_released"}
    accepted={e["episode"] for e in events if e["action"]=="committed_released"}
    trace=read(folder/"lab_trace.jsonl")
    refuse_rows=read(folder/"refusal_updates.jsonl")
    good={r["stamp_ns"]:r for r in read(p/"public_poses.jsonl")}
    public_order=list(good)
    pos={}
    candidate={}
    def add(dst,epoch,pose,kind):
        if epoch in actual_pose:
            i=actual_pose[epoch]
        elif actual_pose:
            t=min(actual_pose,key=lambda t:abs(t-epoch))
            if abs(t-epoch)>1500:
                return
            i=actual_pose[t]
        else:
            return
        base=int(relay[i]["stamp_ns"])
        data_ns=base+int(epoch-fed[i])
        dst[base]=[base,data_ns,*pose,kind]
    for stamp,x in good.items():
        add(pos,stamp,x["p"],1)
    for x in trace:
        if x["arm"]=="refusal" and x["episode"] in refused or x["arm"]=="candidate" and x["episode"] in accepted:
            add(pos,x["stamp_ns"],x["pose"],0)
        if x["arm"]=="candidate":
            add(candidate,x["stamp_ns"],x["pose"],0)
    for x in refuse_rows:
        if x["math"]=="imu_only" and "pose" in x and x["episode"] in refused:
            add(pos,x["stamp_ns"],x["pose"],0)
    with (p/"trajectory.json").open("w") as f:
        json.dump(dict(selected=[pos[t] for t in sorted(pos)],candidate=[candidate[t] for t in sorted(candidate)],
            input_identities=relay),f,separators=(",",":"),allow_nan=False)
    start=(p/"started_at.txt").read_text().strip()
    finish=(p/"finished_at.txt").read_text().strip()
    code=int((p/"exit.txt").read_text())
    compact=[]
    for e in events:
        row={k:v for k,v in e.items() if k not in ("beam_before_m","beam_after_m","offered_payload_sha256")}
        compact.append(row)
    output=dict(code=code,run=name,started=start,finished=finish,events=compact,
        final=json.loads((p/"completion.json").read_text().replace("}"+chr(92)+"n","}")) if (p/"completion.json").exists() else None,
        public=len(good),public_increasing=public_order==sorted(public_order),
        private_leaked=sum(r["stamp_ns"] in good for r in trace),
        refusal_receipts=[{k:v for k,v in q.items() if k!="pose"} for q in refuse_rows],
        bridge_applied=read(folder/"bridge_applied.jsonl"),groups=len(relay),
        maps={x.name:{"bytes":x.stat().st_size,"sha256":hashlib.sha256(x.read_bytes()).hexdigest()}
              for x in folder.glob("*.xyz32")},
        run_error_tail=(p/"run.log").read_text(errors="replace").splitlines()[-10:] if code else [])
    (p/"receipt.json").write_text(json.dumps(output,indent=2,allow_nan=False)+"\n")
    for item in p.iterdir():
        if item.name in ("trajectory.json","receipt.json"):
            continue
        if item.is_dir() and not item.is_symlink():
            shutil.rmtree(item)
        else:
            item.unlink()


if __name__=="__main__":
    main(sys.argv[1])
