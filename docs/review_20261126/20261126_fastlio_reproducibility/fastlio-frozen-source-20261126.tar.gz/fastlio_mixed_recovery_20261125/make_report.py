from pathlib import Path
import json

root=Path(__file__).resolve().parent
all_results=json.loads((root/"RESULTS.json").read_text())
groups={n:r for n,r in all_results.items() if "methods" in r}
names={
    "eee_narrow_sync":("EEE 窄视野 → 时间偏移","窄视野","时间偏移"),
    "eee_z_occlusion":("EEE Z 偏移 → 近场遮挡","Z 偏移","近场遮挡"),
    "sbs_sync_narrow":("SBS 时间偏移 → 窄视野","时间偏移","窄视野"),
    "eee_attenuation_rigid":("EEE 严重丢点 → 刚体偏移渐退","严重丢点","刚体偏移渐退"),
}
labels=("native","imu_refusal","lidar_imu_refusal")
rows=[]
joined=success=short_used=committed=0
worse=better=equal=0
private=[]
reentries=[]
comparison=[]
for name,r in groups.items():
    well=names[name]
    assert r["inputs_exact"]
    for arm,v in r["methods"].items():
        assert v["public_increasing"] and v["no_private_leak"]
        if arm=="native":
            continue
        joined+=1
        if len(v["events"])==2 and all(e.get("rearmed") and
           e.get("native_refusal_fault_identities")==e.get("expected_faults") and e.get("native_healthy_groups")==2
           for e in v["events"]):
            success+=1
    for index,events in enumerate(zip(*(r["methods"][l]["events"] for l in labels))):
        slice_=[e["matched_displacement_length_rmse"]["following_3s"] for e in events]
        v=[p["rmse_m"] for p in slice_]
        decision="双拒绝并接回" if all(e["decision"]=="refused_caught_up_released" and e.get("rearmed") for e in events[1:]) else "/".join(e["decision"] for e in events[1:])
        short_used+=bool(events[2].get("bridge_applied"))
        committed+=sum(e["decision"]=="committed_released" for e in events[1:])
        better+=v[2]<v[1]-1e-6
        worse+=v[2]>v[1]+1e-6
        equal+=abs(v[2]-v[1])<=1e-6
        comparison.append((name,index+1,v))
        rows.append(f"| {well[0]} | {well[index+1]} | {slice_[0]['n']} | {v[0]:.3f} | {v[1]:.3f} | {v[2]:.3f} | {v[2]-v[1]:+.3f} | {decision} |")
        rr=[e.get("reentry_length") for e in events[1:]]
        if all(rr):
            reentries.append(f"| {well[0]} | {well[index+1]} | {rr[0]['difference_m']:+.3f} | {rr[1]['difference_m']:+.3f} |")
        for arm,e in zip(labels[1:],events[1:]):
            if "private_candidate_rmse" in e:
                cp=e["private_candidate_rmse"]; se=e["selected_path_on_same_candidate_frames_rmse"]
                private.append(f"- {well[0]} E{index+1}（{arm}），候选私有 RMSE {cp['rmse_m']:.3f} m，同帧实际选择路径 {se['rmse_m']:.3f} m，n={cp['n']}。候选未公开提交。")

intro=f"""# FAST-LIO2 混合双事件自动恢复与三臂对照

2026-11-25 香港时间。EEE 验证三组不同故障组合，独立录包 SBS 验证反向组合。每组在同一个传感器包、相同逐帧载荷摘要和注入时窗下，分别运行原生 FAST-LIO2、原 IMU 拒绝追赶、短窗 LiDAR–IMU 拒绝追赶。EEE 和 SBS 两组无注入复核均无告警。纳入 {len(groups)} 组三臂对照，恢复臂 {success}/{joined} 次完成两事件的真实拒绝追赶、接回和重武装。公开时间戳严格递增，私有试跑位姿无泄漏。两类漏检在本回放安排中触发。公开候选提交 {committed} 次，短窗在拒绝追赶末端实际施加 {short_used} 次平移锚点。

## 同帧 RMSE

单位为米。每个事件使用事件前最后一条共同有效位姿作为本事件起点。对每条共同帧，将宿主相对于该起点的位移长度与独立棱镜测量作差，取 RMSE。以下为故障结束后的固定 3 s，其中 SBS E2 独立棱镜仅覆盖 10 条共同帧。故障段与全段的匹配 RMSE 也在 CSV 中。第一个故障和第二个故障沿用各自过去的状态，不在事件之间重置宿主。

| 混合序列 | 当前事件 | 共同帧 | 原生 | IMU 追赶 | 短窗追赶 | 短窗减 IMU | 两恢复臂决定 |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
"""
tail=f"""

按固定接回后时间窗，短窗相对现有拒绝追赶改善 {better} 个事件，恶化 {worse} 个，持平 {equal} 个。「RMSE」指与棱镜对比的相对位移长度，未测独立地图真值、旋转精度或绝对轨迹误差。原生基线在同输入上保留通常的建图机会。RMSE_DELTAS.csv 中同时记录短窗减原生与短窗减 IMU。

## 接回首帧位移差

正值表示到首条新公开位姿时，估计的位移长度比独立棱镜大。两个恢复臂各用自身的首条新公开里程计，若该时刻有差异仍各自对棱镜评分；上面的 RMSE 按真正相同帧用于公平比较。上一轮 1.19–1.59 m 的固定反例由 EEE 严重丢点及 EEE Z 偏移重新覆盖。

| 混合序列 | 当前事件 | IMU 追赶误差（m） | 短窗误差（m） |
| --- | --- | ---: | ---: |
"""
end="""

## 拒绝候选的私有评分

"""
notes="""

## 实现与证据边界

- 方位检测比较当前点云占据的 36 个方位角格子数与前缀中位数，低于半数触发。时间偏移检测比较 LiDAR 消息头和接收单调时钟的前缀差，本次检测门限 27 ms。回放用录包入库时间调度接收，并扣除控制器主动暂停；该录包的入库时间与原头时间相同。这里验证的是独立接收时钟假设成立的注入链路，不能据此宣称真机上能识别传输抖动、时钟漂移或原录包自身时间错位。
- 未改变冻住的测量和地图准入。短窗估计通过既有匹配条件时，在第一条已确认健康扫描处理前给拒绝追赶补入一个检验用的平移位置锚点，保持原滤波姿态、速度和协方差。未通过匹配或测量资格则沿用原拒绝追赶；因此某个事件即使没有施加新锚点，也可能继承上一个事件对轨迹的影响。这个位置校正尚未验证协方差一致性或真机实时性。
- 三维图对每个组合用各事件后约 0.5、1.4、2.4 s 的同一真实扫描。SBS E2 到回放截点的公共后缀不足 2.4 s，改取该公共后缀内等间隔的三帧。每帧均匀取最多 1800 个 4–26 m 范围内有效点，用各臂公开位姿投影。以首事件前同一帧只做一次刚体对齐，整张图保持共用视角和坐标尺度。图展示配准位置差，同一几何本体输入，未做帧内去畸变，也未据此评分地图准确性。
- 每轮仅归档事件验收、摘要、点云索引、吞吐所需的位姿数值。回放直接读原包，未产生派生录包；临时日志、ROS 日志、私有地图文件和命令临时目录在每轮提取后清理。地图仅保留点文件字节数和 SHA。绘图只保留选帧源数据及图件。首次试跑的原生消费和错误均保存在精简回执。正常回放没有更改原录包。
"""
(root/"REPORT.md").write_text(intro+"\n".join(rows)+tail+"\n".join(reentries)+end+"\n".join(private)+notes)
print("scenarios",len(groups),"closed_two_events",success,"of",joined,"short_applied",short_used,"wins",better,"losses",worse,"ties",equal)
for x in comparison:
    print(x)
