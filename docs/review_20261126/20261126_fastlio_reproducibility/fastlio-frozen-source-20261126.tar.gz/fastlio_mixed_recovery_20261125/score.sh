#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "$0")"
source /opt/ros/noetic/setup.bash
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export PYTHONPATH="../fastlio_fault_bridge_matrix_20261125:/home/tong/src/slam_recovery:$PYTHONPATH"
exec /usr/bin/python3 score_mixed.py
