#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
for n in $(seq 1 110); do test -f BUILD_TELEMETRY_EXIT.txt && break; sleep 2; done
test "$(cat BUILD_TELEMETRY_EXIT.txt)" = 0
run() {
  local name="$1" site="$2" pair="$3" arm="$4" code=0
  bash run_case.sh "$name" "$site" "$pair" "$arm" || code=$?
  /usr/bin/python3 compact.py "$name"
  printf '%s %s\n' "$name" "$code" | tee -a STATUS.txt
}
run eee_narrow_sync_native eee_03 narrow_sync native
run eee_narrow_sync_terminal eee_03 narrow_sync plain
run eee_narrow_sync_bridge eee_03 narrow_sync bridge
run eee_z_occlusion_native eee_03 z_occlusion native
run eee_z_occlusion_plain eee_03 z_occlusion plain
run eee_z_occlusion_bridge eee_03 z_occlusion bridge
run sbs_clean sbs_02 clean plain
run sbs_sync_narrow_native sbs_02 sync_narrow native
run sbs_sync_narrow_plain sbs_02 sync_narrow plain
run sbs_sync_narrow_bridge sbs_02 sync_narrow bridge
date -Is > FINISHED.txt
