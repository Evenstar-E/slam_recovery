from pathlib import Path
p=Path("mixed_controller.py")
s=p.read_text()
s=s.replace("from bisect import", "from copy import copy\nfrom bisect import",1)
s=s.replace("from replay import INPUT, NS, mutate, time_to_ros, capture, vector",
            "from replay import INPUT, NS, mutate, time_to_ros, capture, vector, records\nfrom score import PRISM_IN_BODY")
s=s.replace('        self.next_request=1','''        self.next_request=1
        self.phase_prefix=[]
        self.sector_prefix=[]
        self.observed={}
        self.odom=(out/"public_poses.jsonl").open("x",buffering=1)''',1)
i=s.index('    def log(self')
s=s[:i]+'''    def pose(self,msg):
        super().pose(msg)
        p,q=msg.pose.pose.position,msg.pose.pose.orientation
        self.odom.write(json.dumps(dict(stamp_ns=msg.header.stamp.to_nsec(),p=[p.x,p.y,p.z,q.x,q.y,q.z,q.w]))+"\\\\n")

    def diagnose(self,msg,origin,receiver_ns):
        stamp=msg.header.stamp.to_nsec()
        rows,layout=records(msg)
        r=rows.view(layout).reshape(-1)
        x,y=r["x"],r["y"]
        good=np.isfinite(x)&np.isfinite(y)&(np.hypot(x,y)>1.)
        sector=len(np.unique(np.floor((np.arctan2(y[good],x[good])+np.pi)*36/(2*np.pi)).astype(int).clip(0,35)))
        phase=stamp-receiver_ns
        if stamp<origin+31*NS:
            self.phase_prefix.append(phase)
            self.sector_prefix.append(sector)
        clock_error=phase-int(np.median(self.phase_prefix)) if self.phase_prefix else 0
        reasons=[]
        if self.phase_prefix and abs(clock_error)>27_000_000:
            reasons.append("transport_clock")
        if self.sector_prefix and sector<.5*np.median(self.sector_prefix):
            reasons.append("azimuth_coverage")
        return reasons,clock_error,sector

'''+s[i:]
s=s.replace('    def handle(self, msg, origin):','    def handle(self, msg, origin, receiver_ns):')
s=s.replace('            healthy=max(abs(shift),raw)<=self.limit','''            reasons,clock_error,sector=self.diagnose(msg,origin,receiver_ns)
            if max(abs(shift),raw)>self.limit:
                reasons.append("beam")
            self.observed[stamp]=(reasons,clock_error)
            healthy=not reasons''')
s=s.replace('holdout_raw_m=raw,healthy=bool(healthy)', 'holdout_raw_m=raw,healthy=bool(healthy),channels=reasons,clock_error_ns=clock_error,occupied_azimuth_bins=sector')
s=s.replace('alarm_scan_ns=stamp,checkpoint=snapshot,hold=held','alarm_scan_ns=stamp,checkpoint=snapshot,hold=held,channels=reasons')
s=s.replace('def bridge_displacement(self, messages, origin, native_trial):','def bridge_displacement(self, messages, origin, native_trial=None):')
a=s.index('        native_delta=np.array(')
b=s.index('\\n    def finish_episode',a) if '\\n    def finish_episode' in s[a:] else s.index('\n    def finish_episode',a)
s=s[:a]+'''        k=len(stamps)-3
        motion_body=(positions[k,1]-positions[0,1])-(rot[k]-rot[0])@PRISM_IN_BODY
        native_length=None if native_trial is None else float(np.linalg.norm(np.array(native_trial[start_stamps[-1]][:3])-p[-1]))
        return dict(edges=len(stamps)-1,usable=int(available.sum()),
                    fault_edges=k, fault_usable=int(available[1:k+1].sum()),
                    terminal_fault_supported=bool(available[k]), terminal_body_delta_m=motion_body.tolist(),
                    estimated_lengths_m=np.linalg.norm(delta,axis=1).tolist(),
                    native_displacement_m=native_length,starts_ns=start_stamps)
'''+s[b:]
s=s.replace('        mea=bool(paired.approved and np.max(odd_after)<=self.limit)', '''        mechanisms={k for stamp in stamps for k in self.observed[stamp][0]}
        mea=bool(mechanisms=={"beam"} and paired.approved and np.max(odd_after)<=self.limit)''')
s=s.replace('freeze_status=before,checkpoint_points=len(pts),beam_pass=mea,beam_limit_m=self.limit,',
            'freeze_status=before,checkpoint_points=len(pts),beam_pass=mea,beam_limit_m=self.limit,channels=sorted(mechanisms),')
key='            queued=self.send("reprocess_refusal"," ".join(str(t) for t in self.streak))'
s=s.replace(key,'''            payload=" ".join(str(t) for t in self.streak)
            if self.arm=="bridge":
                decision=dict(used=False,reason="no_qualified_geometry")
                if mea:
                    fit=row["short_window"]
                elif mechanisms.issubset({"transport_clock","azimuth_coverage"}):
                    offsets=[clock for msg,*_ in self.active
                             for channels,clock in [self.observed[msg.header.stamp.to_nsec()]]
                             if "transport_clock" in channels]
                    step=int(np.median(offsets)) if offsets else 0
                    corrected=[]
                    for msg,*_ in self.active:
                        channels,_=self.observed[msg.header.stamp.to_nsec()]
                        c=copy(msg); c.header=copy(msg.header)
                        if "transport_clock" in channels:
                            c.header.stamp=time_to_ros(msg.header.stamp.to_nsec()-step)
                        corrected.append(c)
                    fit=self.bridge_displacement([self.previous_cloud]+corrected,origin)
                else:
                    fit=None
                if fit is not None:
                    decision.update(fit=fit)
                    if (fit["terminal_fault_supported"] and fit["fault_usable"]>=.60*fit["fault_edges"]):
                        payload+=" "+" ".join(str(v) for v in fit["terminal_body_delta_m"])
                        decision.update(used=True,reason="qualified_short_window")
                self.event_file.write(json.dumps(dict(action="bridge_decision",episode=eid,**decision))+"\\\\n")
            queued=self.send("reprocess_refusal",payload)''')
s=s[:s.index("\ndef main(")]
s+='''
def main(out, site, scenario, arm):
    cfg=SOURCE/site
    origin=json.loads((cfg/"population.json").read_text())["start_ns"]
    events=[e for e in json.loads((cfg/"events.json").read_text()) if e["inject_z_m"]]
    kinds={"narrow_sync":("narrow_fov","sync"),"z_occlusion":("z_shift","occlusion"),
           "sync_narrow":("sync","narrow_fov"),"clean":()}[scenario]
    speed=1.65
    lo=time_to_ros(origin+26*NS)
    hi=time_to_ros(origin+65*NS)
    with rosbag.Bag(str(cfg/"study.bag")) as bag:
        imu=[m for _,m,_ in bag.read_messages(topics=["/imu_raw"],start_time=lo,end_time=hi)]
        rospy.init_node("auto_native_bridge_trial",disable_signals=True)
        ctl=AutoZ(out,imu)
        ctl.arm=arm
        ctl.wait(lambda:ctl.native_pub.get_num_connections()>0 and ctl.imu_pub.get_num_connections()>0,
                 12,"missing input connections")
        wall=None
        counts=[0,0]
        for _,msg,receipt in bag.read_messages(topics=["/velodyne_points"],start_time=lo,end_time=hi):
            stamp=msg.header.stamp.to_nsec()
            if not origin+27*NS<=stamp<origin+64*NS:
                continue
            transport=(receipt.to_nsec()-origin)/NS
            if wall is None:
                wall=time.monotonic()-transport/speed
            left=wall+transport/speed-time.monotonic()
            if left>0:
                time.sleep(left)
            now=time.monotonic()
            receive_ns=origin+round((now-wall)*speed*NS)
            if stamp<origin+31*NS and arm!="native":
                ctl.diagnose(msg,origin,receive_ns)
            idx=next((j for j,e in enumerate(events[:len(kinds)]) if e["onset_ns"]<=stamp<e["end_ns"]),None)
            if idx is not None:
                counts[idx]+=1
                msg=mutate(msg,kinds[idx],events[idx],counts[idx])
            ctl.input_file.write(json.dumps(dict(stamp_ns=stamp,fed_ns=msg.header.stamp.to_nsec(),
                event=idx+1 if idx is not None else None,sha256=hashlib.sha256(msg.data).hexdigest()))+"\\\\n")
            if arm=="native":
                ctl.imu_through(msg.header.stamp.to_nsec())
                ctl.native_pub.publish(msg)
                ctl.latest_scan=msg.header.stamp.to_nsec()
            else:
                ctl.handle(msg,origin,receive_ns)
            wall+=max(0.,time.monotonic()-now) if ctl.mode in ("AWAIT_LIVE","REENTRY") else 0.
        if arm=="native" or ctl.mode=="ARMED":
            ctl.wait_pose(ctl.latest_scan,10)
        tail=ctl.send("status")
        (out/"completion.json").write_text(json.dumps(dict(site=site,scenario=scenario,arm=arm,
            events=ctl.closed,mode=ctl.mode,tail=tail,injected=counts,speed=speed),indent=2)+"\\\\n")


if __name__=="__main__":
    cv2.setNumThreads(1)
    main(Path(sys.argv[1]),*sys.argv[2:])
'''
p.write_text(s)
