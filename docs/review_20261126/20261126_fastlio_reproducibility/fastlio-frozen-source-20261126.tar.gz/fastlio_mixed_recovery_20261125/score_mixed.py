"""Matched physical scan scoring plus output-frame point samples for the figures."""
from pathlib import Path
import json
import csv
import sys
import numpy as np
import rosbag
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent/"ntuviral_fastlio_step5_20261125"
sys.path.insert(0,str(BASE))
from ground_truth_eval import PRISM_IN_BODY, read_gt, interp
from slam_recovery.ros.recovery_node import pose_to_matrix
from replay import records,time_to_ros
NS=10**9

SCENARIOS={
 "eee_narrow_sync":("eee_03","eee_narrow_sync_terminal"),
 "eee_z_occlusion":("eee_03","eee_z_occlusion_plain"),
 "sbs_sync_narrow":("sbs_02","sbs_sync_narrow_plain"),
 "eee_attenuation_rigid":("eee_03","eee_attenuation_rigid_plain"),
}

def read_json(path):
    return json.loads(path.read_text())

def mat(row):
    return pose_to_matrix(row[2:5],row[5:9])

def p(row):
    a=mat(row)
    return a[:3,3]+a[:3,:3]@PRISM_IN_BODY

def summary(errors):
    a=np.asarray(errors)
    return {"n":len(a),"rmse_m":float(np.sqrt(np.mean(a*a))) if len(a) else None}

def status(path,windows,relay):
    r=read_json(path/"receipt.json")
    out=[]
    for num,event in enumerate(windows,1):
        tr=[e for e in r["events"] if e["action"]=="triggered" and
            any(x["event"]==num and x["fed_ns"]==e["alarm_scan_ns"] for x in relay)]
        if not tr:
            out.append({"decision":"NO_TRIGGER"})
            continue
        e=tr[0]
        eid=e["episode"]
        group=[q for q in r["events"] if q["episode"]==eid]
        release=next((q["action"] for q in group if q["action"] in
                      ["committed_released","refused_caught_up_released"]),"INCOMPLETE")
        selected=[q for q in r["refusal_receipts"] if q["episode"]==eid]
        actual={int(q["scan_ns"]) for q in selected if q["math"]=="imu_only"}
        expected=[x["fed_ns"] for x in relay if x["event"]==num]
        count=sum(any(abs(t-a)<=1024 for a in actual) for t in expected)
        out.append(dict(decision=release,channels=e["channels"],
            rearmed=any(q["action"]=="rearmed" for q in group),
            first_live_ns=next((q["first_new_public_pose_ns"] for q in group if q["action"]=="rearmed"),None),
            bridge_applied=next((q for q in r["bridge_applied"] if q["episode"]==eid),None),
            native_refusal_fault_identities=count,expected_faults=len(expected),
            native_healthy_groups=sum(q["math"]=="lidar_update" for q in selected)))
    return dict(exit=r["code"],public=r["public"],no_private_leak=r["private_leaked"]==0,
                public_increasing=r["public_increasing"],control_false_alarms=sum(e["action"]=="triggered" for e in r["events"])-sum(q["decision"]!="NO_TRIGGER" for q in out),events=out)

def xyz_samples(site,selected):
    values={}
    low=min(selected)
    high=max(selected)
    with rosbag.Bag(str(BASE/site/"study.bag")) as bag:
        for _,msg,_ in bag.read_messages(topics=["/velodyne_points"], start_time=time_to_ros(low-NS),end_time=time_to_ros(high+NS)):
            t=msg.header.stamp.to_nsec()
            if t not in selected:
                continue
            raw,layout=records(msg)
            view=raw.view(layout).reshape(-1)
            xyz=np.column_stack([view[k] for k in "xyz"])
            keep=np.flatnonzero(np.isfinite(xyz).all(axis=1)&(np.linalg.norm(xyz,axis=1)>4.)&(np.linalg.norm(xyz,axis=1)<26.))
            ids=keep[np.linspace(0,len(keep)-1,min(1800,len(keep)),dtype=int)]
            values[t]=xyz[ids]
    return values

def main():
    report={}
    table=[]
    for name,(site,plain_name) in SCENARIOS.items():
        paths=[ROOT/(name+"_native"),ROOT/plain_name,ROOT/(name+"_bridge")]
        if not all((path/"trajectory.json").is_file() for path in paths):
            continue
        arms=("native","imu_refusal","lidar_imu_refusal")
        data=[read_json(p/"trajectory.json") for p in paths]
        relay=data[0]["input_identities"]
        assert all(d["input_identities"]==relay for d in data),name
        origin=read_json(BASE/site/"population.json")["start_ns"]
        windows=[e for e in read_json(BASE/site/"events.json") if e["inject_z_m"]]
        gt=read_gt(BASE/"incoming"/(site+"_gt.csv"))
        poses=[{r[0]:r for r in d["selected"]} for d in data]
        common=sorted(set.intersection(*(set(a) for a in poses)))
        lookup={t:interp(*gt,poses[0][t][1]) for t in common}
        qualified=[t for t in common if lookup[t] is not None]
        report[name]={"site":site,"inputs_exact":True,"methods":{},"chosen_plot_frames":[]}
        methods=report[name]["methods"]
        for label,path in zip(arms,paths):
            methods[label]=status(path,windows,relay)
        transforms={}
        before=next((t for t in reversed(common) if t<windows[0]["onset_ns"]-500_000_000),None)
        assert before is not None
        for j,label in enumerate(arms):
            transforms[label]=mat(poses[0][before])@np.linalg.inv(mat(poses[j][before]))
        wanted=[]
        for index,e in enumerate(windows):
            a,b=e["onset_ns"],e["end_ns"]
            prior=next((t for t in reversed(qualified) if t<a),None)
            segment=[t for t in qualified if a<=t<b+3*NS]
            for j,label in enumerate(arms):
                metrics={}
                selected=poses[j]
                for part,subset in (("fault",[t for t in segment if t<b]),("following_3s",[t for t in segment if t>=b]),("combined",segment)):
                    err=[]
                    if prior is not None:
                        for t in subset:
                            err.append(abs(np.linalg.norm(p(selected[t])-p(selected[prior]))-np.linalg.norm(lookup[t]-lookup[prior])))
                    metrics[part]=summary(err)
                    table.append([name,index+1,label,part,metrics[part]["n"],metrics[part]["rmse_m"]])
                q=methods[label]["events"][index]
                q["matched_displacement_length_rmse"]=metrics
                pub=[r for r in selected.values() if r[-1]==1 and r[0]>=b]
                if label!="native" and q.get("first_live_ns") and pub and prior is not None:
                    post=min(pub,key=lambda x:abs(x[1]-q["first_live_ns"]))
                    target=interp(*gt,post[1])
                    if target is not None and abs(post[1]-q["first_live_ns"])<=5000:
                        gt_m=float(np.linalg.norm(target-lookup[prior]))
                        native_m=float(np.linalg.norm(p(post)-p(selected[prior])))
                        q["reentry_length"]={"native_m":native_m,"prism_m":gt_m,"difference_m":native_m-gt_m}
                offered={r[0]:r for r in data[j]["candidate"]}
                cand_times=[t for t in segment if t in offered]
                if prior is not None and cand_times:
                    methods[label]["events"][index]["private_candidate_rmse"]=summary(
                        [abs(np.linalg.norm(p(offered[t])-p(selected[prior]))-np.linalg.norm(lookup[t]-lookup[prior]))
                         for t in cand_times])
                    methods[label]["events"][index]["selected_path_on_same_candidate_frames_rmse"]=summary(
                        [abs(np.linalg.norm(p(selected[t])-p(selected[prior]))-np.linalg.norm(lookup[t]-lookup[prior]))
                         for t in cand_times])
            common_public=[t for t in common if b<=t<b+3*NS and all(d[t][-1]==1 for d in poses)]
            if len(common_public)>=3:
                limit=(common_public[-1]-b)/NS
                targets=np.linspace((common_public[0]-b)/NS,limit,3) if limit<2.4 else (0.5,1.4,2.4)
                unused=set(common_public)
                selection=[]
                for offset in targets:
                    t=min(unused,key=lambda t:(abs(t-(b+int(offset*NS))),t))
                    unused.remove(t)
                    selection.append(t)
                wanted.extend((index+1,(t-b)/NS,t) for t in sorted(selection))
        raw=xyz_samples(site,{t for _,_,t in wanted})
        out={}
        for panel,(event,shift,t) in enumerate(wanted):
            point=raw[t] + np.array([-.05,0.,.055])
            for j,label in enumerate(arms):
                pose=transforms[label]@mat(poses[j][t])
                out[f"{panel}_{label}"]=(point@pose[:3,:3].T+pose[:3,3]).astype(np.float32)
            report[name]["chosen_plot_frames"].append([event,shift,(t-origin)/NS,len(point)])
        np.savez_compressed(ROOT/(name+"_points.npz"),**out)
    for name in ("eee_clean","sbs_clean"):
        if (ROOT/name/"receipt.json").is_file():
            d=read_json(ROOT/name/"receipt.json")
            report[name]=dict(exit=d["code"],alarms=sum(e["action"]=="triggered" for e in d["events"]),
                public=d["public"],public_increasing=d["public_increasing"])
    (ROOT/"RESULTS.json").write_text(json.dumps(report,indent=2,allow_nan=False)+"\n")
    with (ROOT/"RMSE.csv").open("w",newline="") as f:
        w=csv.writer(f)
        w.writerow(["scenario","event","strategy","segment","common_frames","displacement_length_rmse_m"])
        w.writerows(table)
    selected={(name,evt,method,region):(n,rmse) for name,evt,method,region,n,rmse in table}
    with (ROOT/"RMSE_DELTAS.csv").open("w",newline="") as f:
        w=csv.writer(f)
        w.writerow(["scenario","event","segment","pairs","native_rmse_m","imu_rmse_m","short_rmse_m","short_minus_imu_m","short_minus_native_m"])
        for (name,evt,method,region),(n,value) in selected.items():
            if method!="lidar_imu_refusal":
                continue
            native=selected[(name,evt,"native",region)][1]
            imu=selected[(name,evt,"imu_refusal",region)][1]
            w.writerow([name,evt,region,n,native,imu,value,None if value is None or imu is None else value-imu,
                        None if value is None or native is None else value-native])


if __name__=="__main__":
    main()
