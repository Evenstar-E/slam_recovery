import unittest

from sensor_clock_retiming import SensorStep


class SensorStepTest(unittest.TestCase):
    def test_shift_and_clean_suffix(self):
        gate = SensorStep(100_000_000, 100_000_000, 50_000_000)
        self.assertEqual([gate.observe(t) for t in (150_000_000, 250_000_000, 300_000_000, 400_000_000)],
                         ["shifted", "shifted", "returned", "returned"])

    def test_incompatible_cadence_is_latched(self):
        gate = SensorStep(100_000_000, 100_000_000, 50_000_000)
        self.assertEqual(gate.observe(150_000_000), "shifted")
        self.assertEqual(gate.observe(355_000_000), "invalid")
        self.assertEqual(gate.observe(350_000_000), "invalid")

    def test_second_step_before_reentry_rejects(self):
        gate = SensorStep(100_000_000, 100_000_000, -50_000_000)
        self.assertEqual([gate.observe(t) for t in (50_000_000, 200_000_000, 250_000_000)],
                         ["shifted", "returned", "invalid"])

    def test_ambiguous_header_remains_unverified(self):
        gate = SensorStep(100_000_000, 100_000_000, 50_000_000)
        self.assertEqual(gate.observe(125_000_000), "invalid")


if __name__ == "__main__":
    unittest.main(verbosity=2)
