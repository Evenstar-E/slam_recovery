"""Follow one confirmed LiDAR timestamp step without measuring it again at receipt."""
from dataclasses import dataclass, replace
import json

from clock_confirmation import CHANNEL, LIMIT_NS


@dataclass
class SensorStep:
    """Track two possible timestamp epochs on the calibrated scan cadence."""
    expected_ns: int
    interval_ns: int
    offset_ns: int
    returned: bool = False
    invalid: bool = False
    invalid_reported: bool = False

    def observe(self, stamp_ns):
        delta_ns = stamp_ns - self.expected_ns
        self.expected_ns += self.interval_ns
        shifted_error = abs(delta_ns - self.offset_ns)
        clean_error = abs(delta_ns)
        if self.invalid:
            return "invalid"
        if shifted_error < clean_error and shifted_error <= LIMIT_NS and not self.returned:
            return "shifted"
        if clean_error < shifted_error and clean_error <= LIMIT_NS:
            self.returned = True
            return "returned"
        self.invalid = True
        return "invalid"


class RetimeConfirmedStep:
    """Use header evidence for each scan while the original host is isolated."""
    def __init__(self, *args):
        super().__init__(*args)
        self.sensor_step = None

    def _record_clock(self, action, sample, **fields):
        if action == "clock_confirmed":
            next_ns = self.last_forwarded_input_ns + self.nominal_interval_ns
            self.sensor_step = SensorStep(next_ns, self.nominal_interval_ns, sample.stamp_ns - next_ns)
            fields["header_offset_ns"] = self.sensor_step.offset_ns
        return super()._record_clock(action, sample, **fields)

    def _header_diagnosis(self, stamp_ns, diagnosis):
        reasons, measured_phase, coverage = diagnosis
        state = self.sensor_step.observe(stamp_ns)
        self.event_file.write(json.dumps(dict(
            action="sensor_clock_frame", episode=len(self.closed) + 1,
            scan_ns=stamp_ns, state=state, measured_receiver_phase_ns=measured_phase,
            header_offset_ns=self.sensor_step.offset_ns)) + "\n")
        other = [reason for reason in reasons if reason != CHANNEL]
        if state == "shifted":
            return other + [CHANNEL], self.sensor_step.offset_ns, coverage
        if state == "returned":
            return other, 0, coverage
        # Poison the pure-clock eligibility once. Keep the existing detection
        # and recovery path to decide when the live input can be released.
        if not self.sensor_step.invalid_reported:
            self.sensor_step.invalid_reported = True
            return reasons + ["clock_header_unverified"], measured_phase, coverage
        return diagnosis

    def _forward_sample(self, sample, origin, confirmed):
        if self.sensor_step is not None:
            reasons, phase, _ = self._header_diagnosis(
                sample.stamp_ns, (sample.reasons, sample.phase_ns, sample.coverage))
            sample = replace(sample, reasons=reasons, phase_ns=phase)
        return super()._forward_sample(sample, origin, confirmed)

    def diagnose(self, msg, origin, receiver_ns):
        diagnosis = super().diagnose(msg, origin, receiver_ns)
        if self.sensor_step is None or self.precomputed_diagnosis is not None:
            return diagnosis
        return self._header_diagnosis(msg.header.stamp.to_nsec(), diagnosis)

    def finish_episode(self, origin):
        try:
            return super().finish_episode(origin)
        finally:
            self.sensor_step = None
