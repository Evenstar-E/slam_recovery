"""Replay archived receiver time or the separately paced control."""
import hashlib
import json
import os
from pathlib import Path
import sys
import time

import cv2
import rosbag
import rospy

from run_confirmation import ConfirmedController, frozen
from sensor_clock_retiming import RetimeConfirmedStep


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "independent"
NS = frozen.NS


class RetimedController(RetimeConfirmedStep, ConfirmedController):
    pass


def main(output, profile, strategy):
    version = Path(os.environ["FROZEN_VERSION_DIR"])
    assert Path(frozen.__file__).resolve() == version/"mixed_controller.py"
    protocol = json.loads((ROOT/"protocol.json").read_text())["independent"]
    origin = json.loads((DATA/"population.json").read_text())["start_ns"]
    event = json.loads((DATA/"events.json").read_text())[0]
    read_lo, read_hi = [frozen.time_to_ros(origin+t*NS) for t in protocol["read_window_s"]]
    feed_lo, feed_hi = [origin+t*NS for t in protocol["feed_window_s"]]
    trace = json.loads((ROOT/"RECEIVER_FIXTURES.json").read_text()).get(profile)
    receivers = {row[0]: row[1:] for row in trace} if trace else {}
    speed = 1.65
    with rosbag.Bag(str(DATA/"study.bag")) as bag:
        imu = [msg for _, msg, _ in bag.read_messages(topics=["/imu_raw"], start_time=read_lo, end_time=read_hi)]
        rospy.init_node("clock_retiming", disable_signals=True)
        controller = (RetimedController if strategy == "retimed" else ConfirmedController)(output, imu)
        controller.arm = "sparse_localization"
        controller.wait(lambda: controller.native_pub.get_num_connections()>0
                        and controller.imu_pub.get_num_connections()>0, 12, "missing native inputs")
        wall = None
        injected = 0
        for _, msg, recorded in bag.read_messages(topics=["/velodyne_points"], start_time=read_lo, end_time=read_hi):
            stamp = msg.header.stamp.to_nsec()
            if not feed_lo <= stamp < feed_hi:
                continue
            position = (recorded.to_nsec()-origin)/NS
            if wall is None:
                wall = time.monotonic()-position/speed
            delay = wall+position/speed-time.monotonic()
            if delay > 0:
                time.sleep(delay)
            now = time.monotonic()
            event_id = None
            if profile != "challenge" and event["onset_ns"] <= stamp < event["end_ns"]:
                injected += 1
                msg = frozen.mutate(msg, "sync", event, injected)
                event_id = 1
            fed = msg.header.stamp.to_nsec()
            if receivers:
                expected_fed, recv_ns = receivers[stamp]
                assert fed == expected_fed
            else:
                recv_ns = origin+round((now-wall)*speed*NS)
            if stamp < origin+31*NS:
                controller.diagnose(msg, origin, recv_ns)
            row = dict(stamp_ns=stamp, fed_ns=fed, event=event_id, sha256=hashlib.sha256(msg.data).hexdigest(),
                       receiver_ns=recv_ns, received_wall_ns=round(now*NS), wall_feed_ns=time.monotonic_ns())
            controller.input_file.write(json.dumps(row)+"\n")
            controller.receive(msg, origin, recv_ns, row["received_wall_ns"])
            if controller.mode in ("AWAIT_LIVE", "REENTRY"):
                wall += max(0., time.monotonic()-now)
        controller.flush_clock(origin)
        if controller.mode == "ARMED":
            controller.wait_pose(controller.latest_scan, 10)
        tail = controller.send("status")
        (output/"completion.json").write_text(json.dumps(dict(
            site="rtp_03", scenario=profile, arm=strategy, events=controller.closed, mode=controller.mode,
            tail=tail, injected=injected, speed=speed), indent=2)+"\n")


if __name__ == "__main__":
    cv2.setNumThreads(1)
    main(Path(sys.argv[1]), sys.argv[2], sys.argv[3])
