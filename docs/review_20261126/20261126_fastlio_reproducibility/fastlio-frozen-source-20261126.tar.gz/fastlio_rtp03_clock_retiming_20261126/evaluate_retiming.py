"""Score the archived jitter regression with the original physical-scan contract."""
import json
import re
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
PRIOR = ROOT.parent/"fastlio_rtp03_v2_acceptance_20261126"
sys.path.insert(0, str(PRIOR))
import evaluate as scoring


ARMS = dict(noisy_previous="noisy", noisy_retimed="noisy", steady_retimed="steady",
            challenge_retimed="challenge", paced_retimed="paced")


def events(arm, action):
    return [row for row in arm["receipt"]["events"] if row["action"] == action]


def main():
    data = ROOT/"independent"
    expected = scoring.read(data/"expected_inputs.json")
    origin = scoring.read(data/"population.json")["start_ns"]
    fixtures = scoring.read(ROOT/"RECEIVER_FIXTURES.json")
    window = scoring.read(data/"events.json")[0]
    lo, hi = window["onset_ns"], window["end_ns"]
    tail = hi + 3*scoring.NS
    target = [row["stamp_ns"] for row in expected["clean"] if lo <= row["stamp_ns"] < tail]
    clock = [fault if fault["event"] == 1 else clean
             for fault, clean in zip(expected["fault"], expected["clean"])]
    shifted = [row for row in clock if row["event"] == 1]
    preceding = max(row["stamp_ns"] for row in clock if row["stamp_ns"] < lo)
    native_fault = scoring.load_arm("native_fault", expected["fault"])
    native_clean = scoring.load_arm("native_clean", expected["clean"])
    scoring.ROOT = ROOT
    check_prefix = scoring.check_prefix

    def check_inputs(rows, reference):
        check_prefix([{key: row[key] for key in reference[0]} for row in rows], reference)

    scoring.check_prefix = check_inputs
    arms = {name: scoring.load_arm(name, expected["clean"] if profile == "challenge" else clock)
            for name, profile in ARMS.items()}
    result = dict(arms={}, trajectory={})
    for name, arm in arms.items():
        profile = ARMS[name]
        receipt = arm["receipt"]
        row = dict(exit=receipt["code"], complete=arm["complete_input"],
                   inputs=len(arm["relay"]), public=len(arm["public"]), resets=arm["health"],
                   isolated=len(events(arm, "triggered")), private_leaked=receipt["private_leaked"],
                   strict_public=receipt["public_increasing"],
                   exact_receiver_trace=[item[:3] for item in arm["telemetry"]["receiver_trace"]]
                       == fixtures[profile] if profile in fixtures else None)
        result["arms"][name] = row
        if profile == "challenge":
            row["full_native_clean_output"] = set(arm["public"]) == set(native_clean["public"])
            continue
        row.update(scoring.frozen_lifecycle(arm, 1, window, clock))
        triggered = events(arm, "triggered")
        prior = max((t for t in arm["public"] if t < lo), default=None)
        restored = min((t for t in arm["public"] if t >= hi), default=None)
        row.update(public_in_window=sum(t in arm["public"] for t in target), public_slots=len(target),
                   gap_s=(restored-prior)/scoring.NS if prior and restored else None)
        if len(triggered) == 1:
            cp = int(re.search(r"stamp_ns=(\d+)", triggered[0]["checkpoint"]).group(1))
            row["checkpoint_ns"] = cp
            row["checkpoint_binds_last_clean"] = any(
                fate["fate"] == "ingested" and fate["stamp_ns"] == cp
                and abs(preceding-round(fate["beg_s"]*scoring.NS)) <= 2500
                for fate in arm["telemetry"]["fates"])
        header = events(arm, "sensor_clock_frame")
        row["shifted_header_frames"] = sum(r["state"] == "shifted" for r in header)
        row["returned_header_frames"] = sum(r["state"] == "returned" for r in header)
        row["invalid_header_frames"] = sum(r["state"] == "invalid" for r in header)
        observed = {r["stamp_ns"]: r["clock_error_ns"] for r in arm["telemetry"]["detector"]}
        observed.update({r["scan_ns"]: r["measured_receiver_phase_ns"] for r in header})
        row["opposite_receiver_ms"] = [observed[r["fed_ns"]]/1e6 for r in shifted
                                      if observed.get(r["fed_ns"], 0) < 0]
        decision = events(arm, "sparse_localization")
        if len(decision) == 1:
            phase = decision[0]["clock_phase_ns"]
            row["offset_ms"] = phase/1e6 if phase is not None else None
        row["retimed_identities_exact"] = sorted(
            r["scan_ns"] for r in receipt["refusal_receipts"] if r.get("retimed", False))
        original_ns = [r["fed_ns"] for r in shifted]
        retimed_keys = row.pop("retimed_identities_exact")
        row["retimed_identities_exact"] = len(retimed_keys) == len(original_ns) and all(
            abs(left-right) <= 1024 for left, right in zip(retimed_keys, original_ns))
    truth = scoring.read_gt(data/"rtp_03_gt.csv")
    candidates = {"native": native_fault, **{name: arm for name, arm in arms.items() if name != "challenge_retimed"}}
    common = sorted(set.intersection(*(set(arm["poses"]) for arm in candidates.values())))
    reference = {t: v for t in common if (v := scoring.interp(*truth, native_fault["poses"][t][1])) is not None}
    before = max(t for t in reference if t < lo)
    for name, arm in candidates.items():
        result["trajectory"][name] = {label: scoring.displacement_error(
            arm, [t for t in reference if a <= t < b], before, reference)
            for label, a, b in (("whole",lo,tail), ("post_3s",hi,tail))}
    rows = result["arms"]
    old = rows["noisy_previous"]
    clean = rows["challenge_retimed"]
    result["checks"] = dict(
        full_inputs_and_clean_exits=all(row["exit"] == 0 and row["complete"] for row in rows.values()),
        replayed_receivers_exact=all(row["exact_receiver_trace"] for row in rows.values()
                                     if row["exact_receiver_trace"] is not None),
        old_refusal_reproduced=old["retimed"] == 0 and len(old["opposite_receiver_ms"]) == 2 and old["rearmed"],
        no_false_isolation=clean["isolated"] == 0 and clean["full_native_clean_output"],
        no_private_output=all(not row["private_leaked"] and row["strict_public"] for row in rows.values()),
        no_earlier_input_loss=all(row["checkpoint_binds_last_clean"] and row["checkpoint_ns"] == old["checkpoint_ns"]
                                  for name, row in rows.items() if name.endswith("_retimed") and name != "challenge_retimed"),
        full_clock_recovery=all(row["retimed_identities_exact"] and row["healthy_updates"] == 2
                                and row["rearmed"] and row["isolated"] == 1
                                for name, row in rows.items() if name.endswith("_retimed") and name != "challenge_retimed"),
        paired_rmse_better=(
            result["trajectory"]["noisy_retimed"]["whole"]["rmse_m"]
            < result["trajectory"]["noisy_previous"]["whole"]["rmse_m"]))
    result["event_seconds"] = [(t-origin)/scoring.NS for t in (lo, hi)]
    (ROOT/"RESULTS.json").write_text(json.dumps(result, indent=2, allow_nan=False)+"\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
