#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
base=$(dirname "$PWD")
version="$base/fastlio_stability_20261126/v2"
population="$base/fastlio_rtp03_v2_acceptance_20261126"
confirmation="$base/fastlio_rtp03_clock_confirmation_20261126"
sha256sum -c --quiet EXPERIMENT.sha256
(cd "$version" && sha256sum -c --quiet FREEZE.sha256 && sha256sum -c --quiet HOST_SHA256)
(cd "$confirmation" && sha256sum -c --quiet REVIEW_EVIDENCE.sha256)
(cd independent && sha256sum -c --quiet download.sha256)
bash offline.sh prepare.py
sha256sum -c --quiet "$population/LOCKED_POPULATION.sha256"
unlink independent/rtp_03.zip
while read -r name condition strategy; do
    rc=0
    bash run_case.sh "$name" "$condition" "$strategy" || rc=$?
    printf '%s %s\n' "$name" "$rc" >> STATUS.txt
    if [[ -d "$name" && -s "$name/finished_at.txt" ]]; then
        if [[ ! -s "$name/exit.txt" ]]; then printf '%s\n' "$rc" > "$name/exit.txt"; fi
        bash offline.sh compact.py "$name"
    fi
done <<'TABLE'
noisy_previous noisy confirmed
noisy_retimed noisy retimed
steady_retimed steady retimed
challenge_retimed challenge retimed
paced_retimed paced retimed
TABLE
(cd "$version" && sha256sum -c --quiet FREEZE.sha256 && sha256sum -c --quiet HOST_SHA256)
unlink independent/study.bag
printf '%s\n' 'Verified source ZIP and crop against frozen SHA. Removed ZIP, extracted raw, shared crop, per-run logs, and private maps. No per-run bag.' > CLEANUP.txt
