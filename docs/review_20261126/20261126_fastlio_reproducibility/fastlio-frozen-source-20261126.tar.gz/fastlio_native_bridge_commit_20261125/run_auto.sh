#!/usr/bin/env bash
set -eo pipefail
root=$(cd "$(dirname "$0")" && pwd)
cd "$root"
source /opt/ros/noetic/setup.bash
source "$root/ws/devel/setup.bash"
export OMP_NUM_THREADS=2 OMP_THREAD_LIMIT=2 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
export ROS_HOSTNAME=127.0.0.1
export LIO_TWO_EVENT_DIAGNOSTIC=1 LIO_FOUR_POLICY_DIAGNOSTIC=1 LIO_STEP5_EXACT_SCAN_KEY=1
parent="$(dirname "$root")"
export STEP5_INPUT="$parent/ntuviral_fastlio_step5_20261125/eee_03"
export PYTHONPATH="$parent/fastlio_fault_bridge_matrix_20261125:$parent/rigid_ramp_bridge_20261125:$parent/short_window_bridge_20261125:$parent/ntuviral_fastlio_step5_20261125:/home/tong/src/slam_recovery:$PYTHONPATH"
test "$(cat BUILD_REFUSAL_EXIT.txt)" = 0
(cd ws && sha256sum -c --quiet ../BINARY.sha256)
out="$root/$1"
mkdir "$out" "$out/ctl"
date -Is > "$out/started_at.txt"
port=$(/usr/bin/python3 -c 'import socket; s=socket.socket(); s.bind(("127.0.0.1",0)); print(s.getsockname()[1])')
export ROS_MASTER_URI="http://127.0.0.1:$port" ROS_HOME="$out/ros_home" ROS_LOG_DIR="$out/ros_logs"
pids=()
cleanup() {
  for pid in "${pids[@]}"; do kill -INT -- "-$pid" 2>/dev/null || true; done
  for i in $(seq 1 20); do
    alive=false
    for pid in "${pids[@]}"; do if kill -0 -- "-$pid" 2>/dev/null; then alive=true; fi; done
    if ! $alive; then break; fi
    sleep .2
  done
  for pid in "${pids[@]}"; do kill -TERM -- "-$pid" 2>/dev/null || true; done
  for pid in "${pids[@]}"; do wait "$pid" 2>/dev/null || true; done
  date -Is > "$out/finished_at.txt"
}
trap cleanup EXIT
setsid roscore -p "$port" > "$out/roscore.log" 2>&1 & pids+=($!)
for i in $(seq 1 60); do rosparam list >/dev/null 2>&1 && break; sleep .2; done
rosparam set /native_recovery_dir "$out/ctl"
setsid roslaunch "$root/ntulab.launch" > "$out/host.log" 2>&1 & pids+=($!)
for i in $(seq 1 70); do test -s "$out/ctl/capabilities.json" && break; sleep .2; done
test -s "$out/ctl/capabilities.json"
set +e
timeout --signal=TERM --kill-after=5s 240s /usr/bin/python3 -u auto_native.py "$out" "${2:-$1}" > "$out/run.log" 2>&1
code=$?
echo "$code" > "$out/exit.txt"
exit "$code"
