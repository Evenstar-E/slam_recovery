from pathlib import Path
p=Path("ws/src/FAST-LIO/src/laserMapping.cpp")
s=p.read_text()

def edit(a,b):
    global s
    assert s.count(a)==1, a
    s=s.replace(a,b)

edit("    bool repaired = false;\n};","    bool repaired = false;\n    bool imu_only = false;\n    bool refusal_suffix = false;\n};")
edit("static long long lab_end_ns = 0;","""static long long lab_end_ns = 0;
static int lab_refusal_expected = 0;
static int lab_refusal_consumed = 0;
static int lab_refusal_imu = 0;
static int lab_refusal_suffix = 0;
static std::ofstream lab_refusal_updates;""")
edit("        else if (cmd == \"lab_release\" && lab_dual)","""        else if (cmd == "reprocess_refusal" && lab_dual)
        {
            long long first_healthy = 0, last_healthy = 0;
            std::istringstream args(payload);
            std::lock_guard<std::mutex> lk(g_nr_mtx);
            if (!(args >> first_healthy >> last_healthy) || !lab_frozen || !g_nr_hold.load() ||
                g_nr_replay_remaining || !g_nr_cp.valid || g_nr_groups.size() < 3 ||
                first_healthy >= last_healthy ||
                std::llabs((long long)std::llround(g_nr_groups.back().beg*1e9) - last_healthy) > 1024 ||
                std::llabs((long long)std::llround(g_nr_groups[g_nr_groups.size()-2].beg*1e9) - first_healthy) > 1024 ||
                std::any_of(g_nr_groups.begin(), g_nr_groups.end(),
                            [](const NrGroup& group) { return group.imu.empty(); }))
            {
                nr_write_ack("OK reprocess_refusal valid=0 reason=invalid_frozen_capture");
                return;
            }
            std::string why;
            if (!nr_restore_locked(why))
            {
                nr_write_ack("OK reprocess_refusal valid=0 reason=" + why);
                return;
            }
            lab_refusal_expected = (int)g_nr_groups.size();
            lab_refusal_consumed = lab_refusal_imu = lab_refusal_suffix = 0;
            lab_arm = "refusal";
            for (int i = 0; i < lab_refusal_expected; ++i)
            {
                NrGroup group = g_nr_groups[i];
                group.imu_only = i + 2 < lab_refusal_expected;
                group.refusal_suffix = !group.imu_only;
                g_nr_replay_groups.push_back(std::move(group));
            }
            g_nr_repaired.clear();
            g_nr_replay_remaining = lab_refusal_expected;
            g_nr_replay.store(true);
            nr_write_ack("OK reprocess_refusal valid=1 checkpoint_stamp_ns=" +
                         std::to_string((long long)std::llround(g_nr_cp.stamp*1e9)) +
                         " queued=" + std::to_string(lab_refusal_expected) +
                         " target_ns=" + std::to_string((long long)std::llround(g_nr_groups.back().end*1e9)));
        }
        else if (cmd == "lab_release" && lab_dual)""")
edit('                (payload != "applied" && payload != "restored"))',
     '''                (payload != "applied" && payload != "restored" && payload != "refusal") ||
                (payload == "refusal" && (lab_refusal_expected == 0 ||
                 lab_refusal_consumed != lab_refusal_expected || lab_refusal_suffix != 2)))''')
edit('              << " lab_frozen=" << (lab_frozen ? 1 : 0)', '''              << " refusal_consumed=" << lab_refusal_consumed
              << " refusal_imu=" << lab_refusal_imu
              << " refusal_suffix=" << lab_refusal_suffix
              << " lab_frozen=" << (lab_frozen ? 1 : 0)''')
edit('            lab_dual = true;\n            lab_trace.open(g_nr_dir + "/lab_trace.jsonl", std::ios::out);',
     '            lab_dual = true;\n            lab_trace.open(g_nr_dir + "/lab_trace.jsonl", std::ios::out);\n            lab_refusal_updates.open(g_nr_dir + "/refusal_updates.jsonl", std::ios::out);')
edit("        g_nr_cur_repaired = false;\n        if (g_nr_cur_is_replay", """        g_nr_cur_repaired = false;
        bool refusal_imu_only = false, refusal_suffix = false;
        if (g_nr_cur_is_replay""")
edit("                g_nr_cur_repaired = group.repaired;\n", """                g_nr_cur_repaired = group.repaired;
                refusal_imu_only = group.imu_only;
                refusal_suffix = group.refusal_suffix;
""")
edit("            pos_lid = state_point.pos + state_point.rot * state_point.offset_T_L_I;\n\n            if (feats_undistort", """            pos_lid = state_point.pos + state_point.rot * state_point.offset_T_L_I;

            if (refusal_imu_only)
            {
                g_nr_lidar_end = lidar_end_time;
                ++g_nr_frame;
                ++lab_refusal_imu;
                ++lab_refusal_consumed;
                nr_log_fate(lidar_end_time, Measures.lidar_beg_time, "replayed_imu_only");
                lab_refusal_updates << "{\\\"episode\\\":" << lab_episode
                    << ",\\\"scan_ns\\\":" << (long long)std::llround(Measures.lidar_beg_time*1e9)
                    << ",\\\"stamp_ns\\\":" << (long long)std::llround(lidar_end_time*1e9)
                    << ",\\\"math\\\":\\\"imu_only\\\",\\\"map_points\\\":" << ikdtree.validnum() << "}" << std::endl;
                continue;
            }

            if (feats_undistort""")
edit('            if ((g_nr_cur_is_replay || (lab_policy && g_nr_hold.load())) && lab_trace.is_open())',
     '''            if (refusal_suffix)
            {
                ++lab_refusal_consumed;
                ++lab_refusal_suffix;
                lab_refusal_updates << "{\\\"episode\\\":" << lab_episode
                    << ",\\\"scan_ns\\\":" << (long long)std::llround(Measures.lidar_beg_time*1e9)
                    << ",\\\"stamp_ns\\\":" << (long long)std::llround(lidar_end_time*1e9)
                    << ",\\\"math\\\":\\\"lidar_update\\\",\\\"map_points\\\":" << ikdtree.validnum()
                    << ",\\\"matched_features\\\":" << effct_feat_num << "}" << std::endl;
            }
            if ((g_nr_cur_is_replay || (lab_policy && g_nr_hold.load())) && lab_trace.is_open())''')
p.write_text("#include <algorithm>\n" + s)
