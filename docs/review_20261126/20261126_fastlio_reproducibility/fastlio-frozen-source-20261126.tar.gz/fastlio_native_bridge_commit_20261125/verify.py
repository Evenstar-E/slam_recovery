"""Read arm receipts from FAST-LIO, confirm the final decision, then score against prism."""
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

ROOT=Path(__file__).resolve().parent
REF=ROOT.parent/"ntuviral_fastlio_step5_20261125"
sys.path.insert(0,str(REF))
from ground_truth_eval import PRISM_IN_BODY, interp, read_gt
from slam_recovery.ros.recovery_node import pose_to_matrix

NS=1_000_000_000


def read(path):
    return [json.loads(x) for x in path.read_text().splitlines()]


def fields(s):
    return dict(p.split("=",1) for p in s.split() if "=" in p)


def associate(expected, actual, tolerance=1024):
    actual=np.sort(np.asarray(actual,dtype=np.int64))
    expected=np.asarray(expected,dtype=np.int64)
    n=np.searchsorted(actual,expected)
    low=actual[np.maximum(0,n-1)]
    hi=actual[np.minimum(len(actual)-1,n)]
    best=np.where(np.abs(low-expected)<=np.abs(hi-expected),low,hi)
    good=np.abs(best-expected)<=tolerance
    return [int(v) if yes else None for v,yes in zip(best,good)]


def prism_trace(trace, anchors):
    by_scan={r["scan_stamp_ns"]:r for r in trace}
    matched=associate(anchors,list(by_scan))
    assert all(x is not None for x in matched) and len(set(matched))==len(anchors)
    results=[]
    for idx in matched:
        row=by_scan[idx]
        mat=pose_to_matrix(row["pose"][:3],row["pose"][3:])
        results.append((row["stamp_ns"],mat[:3,:3]@PRISM_IN_BODY+mat[:3,3]))
    return results


def verify():
    injected=ROOT/(sys.argv[1] if len(sys.argv)>1 else "injected")
    healthy=ROOT/"clean"
    original=json.loads((REF/"eee_03"/"population.json").read_text())
    origin=original["start_ns"]
    event_inputs=read(injected/"relay_frames.jsonl")
    clean_inputs=read(healthy/"relay_frames.jsonl")
    clean_by_ns={r["stamp_ns"]:r["sha256"] for r in clean_inputs}
    assert all((clean_by_ns[r["stamp_ns"]]!=r["sha256"])==r["changed"] for r in event_inputs)
    clean_obs=read(healthy/"observations.jsonl")
    assert all(x["healthy"] for x in clean_obs)
    assert not read(healthy/"events_result.jsonl")
    events=read(injected/"events_result.jsonl")
    trace=read(injected/"ctl"/"lab_trace.jsonl")
    updates=read(injected/"ctl"/"repair_updates.jsonl")
    rejection=injected/"ctl"/"refusal_updates.jsonl"
    refusal_updates=read(rejection) if rejection.exists() else []
    inputs=read(injected/"ctl"/"input_fates.jsonl")
    gt_t, gt=read_gt(REF/"incoming"/"eee_03_gt.csv")
    output=dict(clean_false_triggers=0,clean_observations=len(clean_obs),episodes={})
    for eid in sorted({x["episode"] for x in events}):
        seq=[r for r in events if r["episode"]==eid]
        if len(seq)<2:
            continue
        tg,tr=seq[:2]
        expected=[r["stamp_ns"] for r in event_inputs if r["event"]==eid]
        assert expected==tr["fault_stamps_ns"]
        item=dict(fault_input_count=len(expected),checkpoint_ns=tr["checkpoint_ns"],
            trigger_data_s=(tg["alarm_scan_ns"]-origin)/NS,healthy_suffix_data_s=[
              (x-origin)/NS for x in tr["healthy_suffix_ns"]],
            beam_pass=tr["beam_pass"],map_pass=tr.get("local_gate_pass"),decision=seq[-1]["action"])
        if "candidate" in tr:
            for mode in ("raw","candidate"):
                rows=[r for r in trace if r["episode"]==eid and r["arm"]==mode]
                p=prism_trace(rows,expected)
                if mode=="candidate":
                    assert sum(r["replacement"] for r in rows)==len(expected)
                    linked=associate(expected,[r["scan_stamp_ns"] for r in updates])
                    assert all(x is not None for x in linked)
                d=(injected/"ctl"/f"E{eid}_{mode}.xyz32").read_bytes()
                item[mode]=dict(groups=len(rows),map_points=len(d)//12,map_sha256=hashlib.sha256(d).hexdigest())
                ref=[interp(gt_t,gt,int(t)) for t,_ in p]
                if all(v is not None for v in ref):
                    a=np.stack([v for _,v in p]); b=np.asarray(ref)
                    # Same fault-window endpoints; use independent displacement magnitudes.
                    peak=np.linalg.norm(a[-1]-a[0])
                    target=np.linalg.norm(b[-1]-b[0])
                    item[mode].update(endpoint_length_m=float(peak),prism_length_m=float(target),
                        endpoint_error_m=float(abs(peak-target)))
            assert item["candidate"]["map_sha256"]!=item["raw"]["map_sha256"]
            item["local_map_gate_result"]=tr["map_result"]
            item["bridge"]=tr["short_window"]
        decided=[x for x in seq if x["action"] in ("committed_released","refused_caught_up_released")]
        if decided:
            commit=decided[0]
            rearm=next(x for x in seq if x["action"]=="rearmed")
            release,status=fields(commit["native_response"]),fields(commit["native_status"])
            assert release["map_writes"]=="released" and status["map_writes"]=="released"
            if commit["action"]=="committed_released":
                assert int(status["repaired_map_updates"])==len(expected)
                assert int(status["map_points"])==item["candidate"]["map_points"]
                assert item["candidate"]["map_sha256"]==commit["live_candidate_map_sha256"]
            else:
                rr=[r for r in refusal_updates if r["episode"]==eid]
                lr=[r for r in rr if r["math"]=="lidar_update"]
                ir=[r for r in rr if r["math"]=="imu_only"]
                assert len(lr)==2 and len(ir)==len(expected)
                assert all(v is not None for v in associate(expected,[r["scan_ns"] for r in ir]))
                assert all(v is not None for v in associate(tr["healthy_suffix_ns"],[r["scan_ns"] for r in lr]))
                assert len({r["map_points"] for r in ir})==1
                h=hashlib.sha256((injected/"ctl"/f"E{eid}_refusal.xyz32").read_bytes()).hexdigest()
                assert h==commit["live_refusal_map_sha256"]
                assert h!=item["candidate"]["map_sha256"]
                item["refusal"]={"raw_imu_only":len(ir),"healthy_lidar":len(lr),
                    "healthy_matches":[r["matched_features"] for r in lr],
                    "frozen_map_count":ir[0]["map_points"],
                    "target_map_sha256":h}
            item["decision"]=commit["action"]
            item["release_data_s"]=(int(release["stamp_ns"])-origin)/NS
            item["first_live_data_s"]=(rearm["first_new_public_pose_ns"]-origin)/NS
            assert item["first_live_data_s"]>item["release_data_s"]
            item["rearm_verified"]=True
        output["episodes"][str(eid)]=item
    if (injected/"completion.json").is_file():
        p=read(injected/"public_odom.jsonl")
        public=np.array([x["stamp_ns"] for x in p],dtype=np.int64)
        assert np.all(np.diff(public)>0)
        assert all(x is None for x in associate(public,[r["stamp_ns"] for r in trace]))
        kind=json.loads((injected/"completion.json").read_text())["kind"]
        expected_episodes={"1"} if kind=="static_positive" else {"1","2"}
        assert set(output["episodes"])==expected_episodes
        if "2" in output["episodes"]:
            assert output["episodes"]["1"]["first_live_data_s"]<output["episodes"]["2"]["trigger_data_s"]
        last=(int(public[-1])-origin)/NS
        output.update(public_poses=len(public),tail_data_s=last)
        for eid,item in output["episodes"].items():
            end=output["episodes"]["2"]["trigger_data_s"] if eid=="1" and "2" in output["episodes"] else last+1
            live=[r for r in inputs if r["fate"]=="ingested" and
                  item["first_live_data_s"]-1e-5 <= (int(r["stamp_ns"])-origin)/NS < end]
            item["later_native_consumption"]=len(live)
            assert live
            cp=item["checkpoint_ns"]
            obs=min(p,key=lambda x:abs(x["stamp_ns"]-cp))
            dst=min(p,key=lambda x:abs(x["stamp_ns"]-(origin+item["first_live_data_s"]*NS)))
            assert abs(obs["stamp_ns"]-cp)<=1024
            def pos(a):
                m=pose_to_matrix(a["p"][:3],a["p"][3:])
                return m[:3,3]+m[:3,:3]@PRISM_IN_BODY
            g0=interp(gt_t,gt,obs["stamp_ns"])
            g1=interp(gt_t,gt,dst["stamp_ns"])
            item["checkpoint_to_first_live_m"]={"native":float(np.linalg.norm(pos(dst)-pos(obs))),
                "prism":float(np.linalg.norm(g1-g0)) if g0 is not None and g1 is not None else None}
    (ROOT/f"VERIFICATION_{injected.name}.json").write_text(json.dumps(output,indent=2,allow_nan=False)+"\n")


if __name__=="__main__":
    verify()
