#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "$0")"
source /opt/ros/noetic/setup.bash
export OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="/home/tong/src/slam_recovery:$PYTHONPATH"
exec /usr/bin/python3 verify.py "$1"
