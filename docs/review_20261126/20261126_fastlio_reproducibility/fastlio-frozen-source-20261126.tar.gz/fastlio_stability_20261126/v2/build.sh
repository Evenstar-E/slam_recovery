#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "$0")/ws"
source /opt/ros/noetic/setup.bash
export OMP_NUM_THREADS=2 OMP_THREAD_LIMIT=2 OPENBLAS_NUM_THREADS=1
code=0
timeout --signal=TERM --kill-after=15s 450s catkin_make -j2 -l2 > ../BUILD.log 2>&1 || code=$?
printf '%s\n' "$code" > ../BUILD_TELEMETRY_EXIT.txt
if [[ "$code" = 0 ]]; then
  sha256sum devel/lib/fast_lio/fastlio_mapping > ../BINARY.sha256
  tail -12 ../BUILD.log > ../BUILD_RECEIPT.txt
else
  tail -40 ../BUILD.log > ../BUILD_RECEIPT.txt
  cat ../BUILD_RECEIPT.txt >&2
fi
unlink ../BUILD.log
exit "$code"
