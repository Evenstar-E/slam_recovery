#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export OMP_NUM_THREADS=2 OMP_THREAD_LIMIT=2 OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
rc=0
bash run_case.sh "$@" || rc=$?
printf '%s %s\n' "$1" "$rc" >> STATUS.txt
if [[ -s "$1/exit.txt" && -s "$1/relay_frames.jsonl" ]]; then
  /usr/bin/python3 compact.py "$1"
elif [[ -d "$1" ]]; then
  printf 'No durable replay/input receipt for %s. Review technical failure outputs before cleanup.\n' "$1" >&2
fi
for emitted in H_OUT.txt imu.txt pos_log.txt; do
  target="ws/src/FAST-LIO/Log/$emitted"
  if [[ -f "$target" && ! -L "$target" ]]; then
    sha256sum "$target" >> "$1/log_fingerprints.txt"
    unlink "$target"
  fi
done
exit "$rc"
