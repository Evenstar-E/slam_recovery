"""Rebind captured IMU to validated constant LiDAR clock steps in private replay."""
from pathlib import Path

p=Path("ws/src/FAST-LIO/src/laserMapping.cpp")
code=p.read_text()

def change(old,new):
    global code
    assert code.count(old)==1,old
    code=code.replace(old,new)

change("    bool refusal_suffix = false;\n};","""    bool refusal_suffix = false;
    bool retimed = false;
    double input_beg = 0.0;
};""")
mark="static void nr_execute(const std::string& cmd, const std::string& payload)\n"
change(mark,r'''static bool nr_rebind_clock(std::vector<NrGroup> &groups, long long step_ns)
{
    // The final two healthy scans keep their original bounds. Reuse every
    // captured IMU sample exactly once and preserve the recorded LiDAR key.
    const double offset = static_cast<double>(step_ns) * 1e-9;
    std::vector<NrGroup> trial = groups;
    std::vector<sensor_msgs::Imu::ConstPtr> imu;
    double previous_imu = -1.0;
    for (const auto &group : groups)
        for (const auto &sample : group.imu)
        {
            const double stamp = sample->header.stamp.toSec();
            if (!(stamp > previous_imu))
                return false;
            previous_imu = stamp;
            imu.push_back(sample);
        }

    size_t cursor = 0;
    double previous_begin = -1.0, previous_end = g_nr_cp.stamp;
    for (size_t i = 0; i < trial.size(); ++i)
    {
        auto &group = trial[i];
        if (i + 2 < trial.size())
        {
            if (!(abs(offset) < group.end - group.beg))
                return false;
            group.input_beg = group.beg;
            group.beg -= offset;
            group.end -= offset;
            group.retimed = true;
        }
        if (!(group.beg > previous_begin && group.end > previous_end && group.end > group.beg))
            return false;
        const size_t begin = cursor;
        while (cursor < imu.size() && imu[cursor]->header.stamp.toSec() <= group.end)
            ++cursor;
        if (cursor == begin || !(imu[begin]->header.stamp.toSec() > previous_end))
            return false;
        group.imu.assign(imu.begin() + begin, imu.begin() + cursor);
        previous_begin = group.beg;
        previous_end = group.end;
    }
    if (cursor != imu.size())
        return false;
    groups.swap(trial);
    return true;
}
''' + mark)
change('''            args >> std::ws;
            if (args.peek() == 'l')''','''            long long clock_step_ns = 0;
            bool clock_requested = false;
            args >> std::ws;
            if (args.peek() == 'l' || args.peek() == 't')''')
change('''                if (!args || mode != "localize" ||''','''                clock_requested = mode == "time";
                if (clock_requested)
                    args >> clock_step_ns;
                if (!args || (mode != "localize" && !clock_requested) ||''')
change('''            lab_refusal_expected = (int)g_nr_groups.size();''','''            std::vector<NrGroup> prepared(g_nr_groups.begin(), g_nr_groups.end());
            const bool clock_rebound = clock_requested && nr_rebind_clock(prepared, clock_step_ns);
            if (clock_requested && !clock_rebound)
                lab_refusal_use_geometry = false;
            lab_refusal_expected = static_cast<int>(prepared.size());''')
change('                NrGroup group = g_nr_groups[i];','                NrGroup group = std::move(prepared[i]);')
change('''                         " queued=" + std::to_string(lab_refusal_expected) +
                         " target_ns="''','''                         " queued=" + std::to_string(lab_refusal_expected) +
                         " clock_rebound=" + std::to_string(clock_rebound) +
                         " target_ns="''')
change('''        bool refusal_imu_only = false, refusal_suffix = false;''','''        bool refusal_imu_only = false, refusal_suffix = false, refusal_retimed = false;
        double refusal_input_beg = 0.0;''')
change('''                refusal_suffix = group.refusal_suffix;''','''                refusal_suffix = group.refusal_suffix;
                refusal_retimed = group.retimed;
                refusal_input_beg = refusal_retimed ? group.input_beg : group.beg;''')
change('''                nr_log_fate(lidar_end_time, Measures.lidar_beg_time,
                            localized ? "replayed_localization_only" : "replayed_imu_only");''','''                nr_log_fate(lidar_end_time, refusal_input_beg,
                            localized ? "replayed_localization_only" : "replayed_imu_only");''')
change(r'''                lab_refusal_updates << "{\"episode\":" << lab_episode
                    << ",\"scan_ns\":" << (long long)std::llround(Measures.lidar_beg_time*1e9)
                    << ",\"stamp_ns\":" << (long long)std::llround(lidar_end_time*1e9)
                    << ",\"math\":\""''',r'''                lab_refusal_updates << "{\"episode\":" << lab_episode
                    << ",\"scan_ns\":" << (long long)std::llround(refusal_input_beg*1e9)
                    << ",\"retimed\":" << (refusal_retimed ? "true" : "false")
                    << ",\"corrected_scan_ns\":" << (long long)std::llround(Measures.lidar_beg_time*1e9)
                    << ",\"stamp_ns\":" << (long long)std::llround(lidar_end_time*1e9)
                    << ",\"math\":\""''')
p.write_text(code)

p=Path("mixed_controller.py")
s=p.read_text()
anchor='''                self.event_file.write(json.dumps(dict(action="sparse_localization",episode=eid,
                    eligible=eligible,point_limit=point_limit,
                    maximum_fault_points=max(self.scan_points[t] for t in stamps)))+"\\n")
                if eligible:
                    payload+=" localize {} {}".format(self.frozen_limits["support_lower_bound"],
                                                        self.frozen_limits["distance_rms_upper_bound_m"])'''
updated='''                gate="{} {}".format(self.frozen_limits["support_lower_bound"],
                                     self.frozen_limits["distance_rms_upper_bound_m"])
                clock_phase=None
                if all(self.observed[t][0]==["transport_clock"] for t in stamps):
                    phases=[self.observed[t][1] for t in stamps]
                    median=int(np.median(phases))
                    if all(p*median>0 and abs(p-median)<=27_000_000 for p in phases):
                        clock_phase=median
                self.event_file.write(json.dumps(dict(action="sparse_localization",episode=eid,
                    eligible=eligible,point_limit=point_limit,clock_phase_ns=clock_phase,
                    maximum_fault_points=max(self.scan_points[t] for t in stamps)))+"\\n")
                if clock_phase is not None:
                    payload+=" time {} {}".format(gate,clock_phase)
                elif eligible:
                    payload+=" localize "+gate'''
assert s.count(anchor)==1
s=s.replace(anchor,updated)
p.write_text(s)

p=Path("compact.py")
s=p.read_text()
a='    def add(dst,epoch,pose,kind):'
assert s.count(a)==1
s=s.replace(a,'    def add(dst,epoch,pose,kind,retimed=False):')
s=s.replace('        data_ns=base+int(epoch-fed[i])','        data_ns=int(epoch) if retimed else base+int(epoch-fed[i])')
s=s.replace('            add(pos,x["stamp_ns"],x["pose"],0)\n    with','            add(pos,x["stamp_ns"],x["pose"],0,retimed=x.get("retimed",False))\n    with')
p.write_text(s)
