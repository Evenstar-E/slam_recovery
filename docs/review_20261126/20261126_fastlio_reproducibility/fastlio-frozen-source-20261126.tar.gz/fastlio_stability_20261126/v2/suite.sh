#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum -c --quiet FREEZE.sha256
while read -r name site case; do
  if ! bash execute.sh "$name" "$site" "$case" "$1"; then
    printf 'Arm failed: %s. Preserving result.\n' "$name" >&2
  fi
done < pop.tsv
