"""Causal Z-shift repair trigger, native trial and verified resume, for the isolated EEE run."""
from copy import copy
from bisect import bisect_right
from collections import deque
import hashlib
import json
from pathlib import Path
import sys
import time

import cv2
import numpy as np
import rosbag
import rospy
from sensor_msgs.msg import Imu, PointCloud2

from replay import INPUT, NS, mutate, time_to_ros, capture, vector, records
from score import PRISM_IN_BODY
from step3_controller import Dual, integer, measures, odd_error, estimate, map_score, summary
from native_probe import Probe
from slam_recovery.ros.cloud_repair import shift_z_cloud
from slam_recovery.ros.recovery_node import pose_to_matrix
from slam_recovery.validation.wilson_validator import evaluate_paired_sequential_benefit
from assess import chain
from run_bridge_event1 import interp_matrix

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent.parent/"ntuviral_fastlio_step5_20261125"
# Same numerical round-off slack and two healthy windows as the archived probes.
RAY_SLACK_M=1e-5
HEALTHY_DWELL=2
# Arm masks use the controller's episode counter. They never inspect the injection labels.
BRIDGE_EPISODES = {
    "native": frozenset(),
    "sparse_localization": frozenset(),
    "plain": frozenset(),
    "bridge_first": frozenset({1}),
    "bridge_second": frozenset({2}),
    "bridge": frozenset({1, 2}),
}


class AutoZ(Dual):
    def __init__(self, out, imu):
        Probe.__init__(self,out)
        self.next_request=1
        self.phase_prefix=[]
        self.point_count_prefix=[]
        self.scan_points={}
        self.sector_prefix=[]
        self.observed={}
        self.odom=(out/"public_poses.jsonl").open("x",buffering=1)
        self.snapshot_request=None
        self.latest_scan=None
        self.previous=None
        self.model=None
        self.training=[]
        self.calibration=[]
        self.limit=None
        self.mode="CALIBRATING"
        self.active=[]
        self.streak=[]
        self.closed=[]
        self.arm_after_stamp=None
        self.native_pub=rospy.Publisher("/velodyne_points",PointCloud2,queue_size=64,tcp_nodelay=True)
        self.imu_pub=rospy.Publisher("/imu_raw",Imu,queue_size=2048,tcp_nodelay=True)
        self.imu=imu
        self.imu_t=np.array([m.header.stamp.to_nsec() for m in imu],dtype=np.int64)
        self.gyro=np.array([vector(m.angular_velocity) for m in imu])
        self.accel=np.array([vector(m.linear_acceleration) for m in imu])
        assert np.all(np.diff(self.imu_t)>0)
        self.sent_imu=0
        self.beam_file=(out/"observations.jsonl").open("x",buffering=1)
        self.event_file=(out/"events_result.jsonl").open("x",buffering=1)
        self.input_file=(out/"relay_frames.jsonl").open("x",buffering=1)
        self.frozen_limits=json.loads((SOURCE/"calibration.json").read_text())["local_map"]

    def pose(self,msg):
        super().pose(msg)
        p,q=msg.pose.pose.position,msg.pose.pose.orientation
        self.odom.write(json.dumps(dict(stamp_ns=msg.header.stamp.to_nsec(),p=[p.x,p.y,p.z,q.x,q.y,q.z,q.w]))+"\n")

    def diagnose(self,msg,origin,receiver_ns):
        stamp=msg.header.stamp.to_nsec()
        rows,layout=records(msg)
        r=rows.view(layout).reshape(-1)
        x,y=r["x"],r["y"]
        good=np.isfinite(x)&np.isfinite(y)&(np.hypot(x,y)>1.)
        sector=len(np.unique(np.floor((np.arctan2(y[good],x[good])+np.pi)*36/(2*np.pi)).astype(int).clip(0,35)))
        phase=stamp-receiver_ns
        if stamp<origin+31*NS:
            self.phase_prefix.append(phase)
            self.sector_prefix.append(sector)
        clock_error=phase-int(np.median(self.phase_prefix)) if self.phase_prefix else 0
        count=int(np.count_nonzero(good & (r["range"] > 0)))
        self.scan_points[stamp]=count
        if stamp<origin+31*NS:
            self.point_count_prefix.append(count)
        reasons=[]
        if self.phase_prefix and abs(clock_error)>27_000_000:
            reasons.append("transport_clock")
        if self.sector_prefix and sector<.5*np.median(self.sector_prefix):
            reasons.append("azimuth_coverage")
        return reasons,clock_error,sector

    def log(self, data):
        super().log(dict(**data,monotonic_s=time.monotonic()))

    def wait_status(self, scan_start, timeout=10):
        def observed():
            s=self.send("status")
            return s if "stamp_ns=NA" not in s and integer(s,"stamp_ns")>scan_start else None
        return self.wait(observed,timeout,f"host did not consume scan {scan_start}")

    def freeze_calibration(self):
        columns=[np.concatenate([v[i] for v in self.training]) for i in range(3)]
        r,z,ring=columns
        self.model={}
        for k in sorted(set(ring.tolist())):
            use=ring==k
            assert np.count_nonzero(use)>=20
            self.model[int(k)]=tuple(np.linalg.lstsq(
                np.column_stack((r[use],np.ones(np.count_nonzero(use)))),z[use],rcond=None)[0])
        probes=[max(abs(estimate(m,self.model)[0]),odd_error(m,self.model)) for m in self.calibration]
        assert len(probes)>=8 and all(np.isfinite(probes))
        self.limit=max(probes)+RAY_SLACK_M
        (self.root/"beam_calibration.json").write_text(json.dumps(dict(model=self.model,
            limit_m=self.limit,training_arrays=len(self.training),
            calibration_stamps=[m.header.stamp.to_nsec() for m in self.calibration],
            validation_values_m=probes,frozen_map_gate=self.frozen_limits),indent=2)+"\n")
        self.training.clear()
        self.calibration.clear()
        self.mode="ARMED"

    def imu_through(self, stamp):
        mark=bisect_right(self.imu_t,stamp+140_000_000)
        for i in range(self.sent_imu,mark):
            self.imu_pub.publish(self.imu[i])
        self.sent_imu=mark

    def handle(self, msg, origin, receiver_ns):
        entered=time.monotonic()
        stamp=msg.header.stamp.to_nsec()
        elapsed=(stamp-origin)/NS
        if self.mode=="CALIBRATING":
            if 28<=elapsed<29:
                r,z,k,ok=measures(msg)
                self.training.append((r[ok],z[ok],k[ok]))
            elif 29<=elapsed<31:
                self.calibration.append(msg)
            elif elapsed>=31:
                self.freeze_calibration()
        if self.mode=="REENTRY":
            # The prior resume was acknowledged. Require a newer actual input and odometry
            # before arming this controller to detect a second fault.
            self.wait_pose(self.arm_after_stamp+1,8)
            checked=self.wait_status(self.arm_after_stamp)
            assert "map_writes=released" in checked
            self.event_file.write(json.dumps(dict(action="rearmed",episode=len(self.closed),
                first_new_public_pose_ns=next(t for t,_ in self.poses if t>self.arm_after_stamp),
                native_status=checked))+"\n")
            self.mode="ARMED"
        close_after=False
        if self.mode!="CALIBRATING":
            shift=estimate(msg,self.model)[0]
            raw=odd_error(msg,self.model)
            reasons,clock_error,sector=self.diagnose(msg,origin,receiver_ns)
            if max(abs(shift),raw)>self.limit:
                reasons.append("beam")
            self.observed[stamp]=(reasons,clock_error)
            healthy=not reasons
            self.beam_file.write(json.dumps(dict(stamp_ns=stamp,state=self.mode,estimate_z_m=shift,
                holdout_raw_m=raw,healthy=bool(healthy),channels=reasons,clock_error_ns=clock_error,occupied_azimuth_bins=sector))+"\n")
            if self.mode=="ARMED" and not healthy:
                # Host has not received the alarming scan. Capture its actual preceding state.
                assert self.latest_scan is not None and self.previous is not None
                self.wait_status(self.latest_scan)
                snapshot=self.send("snapshot")
                self.cp=integer(snapshot,"stamp_ns")
                assert integer(snapshot,"valid")==1 and self.cp<stamp
                assert integer(snapshot,"map_points")>1000
                self.onset=stamp
                held=self.send("hold")
                assert integer(held,"stamp_ns")==self.cp and "map_writes=held" in held
                self.previous_cloud=self.previous
                self.pose_prefix=[(t,np.array(p)) for t,p in self.poses if self.cp-500_000_000<=t<=self.cp+1024]
                assert len(self.pose_prefix)>=2
                self.event_file.write(json.dumps(dict(action="triggered",episode=len(self.closed)+1,
                    alarm_scan_ns=stamp,checkpoint=snapshot,hold=held,channels=reasons,
                    handle_to_hold_s=time.monotonic()-entered))+"\n")
                self.mode="HELD"
            if self.mode=="HELD":
                self.active.append((msg,shift,raw,bool(healthy)))
                if healthy:
                    self.streak.append(stamp)
                else:
                    self.streak.clear()
                if len(self.streak)>=HEALTHY_DWELL:
                    # Set the diagnostic capture endpoint using the just-arrived qualifying
                    # frame and its ordinary acquisition duration, after the health decision.
                    self.wait_status(self.latest_scan)
                    end=self.send("lab_capture",str(stamp+20_000_000))
                    assert integer(end,"episode")==len(self.closed)+1
                    close_after=True
        self.imu_through(stamp)
        self.native_pub.publish(msg)
        self.latest_scan=stamp
        self.previous=msg
        if self.mode=="AWAIT_LIVE":
            self.mode="REENTRY"
        if close_after:
            self.finish_episode(origin)

    def bridge_displacement(self, messages, origin, native_trial=None):
        """Independent relative displacement estimate using current repaired clouds and raw IMU."""
        rotation=[]; scan_points=[]; stamps=[]; start_stamps=[]
        for msg in messages:
            start=msg.header.stamp.to_nsec()
            xyz, offsets, end=capture(msg)
            scan_points.append((xyz, offsets.astype(np.int64)+start))
            stamps.append(start+end)
            start_stamps.append(start)
        stamps=np.asarray(stamps,dtype=np.int64)
        quiet=(self.imu_t>=origin+29*NS)&(self.imu_t<origin+31*NS)
        lo=int(np.searchsorted(self.imu_t,stamps[0]-200_000_000))
        hi=int(np.searchsorted(self.imu_t,stamps[-1]+200_000_000))
        t=self.imu_t[lo:hi]
        gyro=self.gyro[lo:hi]-self.gyro[quiet].mean(axis=0)
        orientations=[np.eye(3)]
        for j,dt in enumerate(np.diff(t)*1e-9):
            orientations.append(orientations[-1]@cv2.Rodrigues(.5*(gyro[j]+gyro[j+1])*dt)[0])
        orientations=np.asarray(orientations)
        first_pose=pose_to_matrix(self.pose_prefix[-1][1][:3],self.pose_prefix[-1][1][3:])
        u,_,vt=np.linalg.svd(interp_matrix(stamps[:1],t,orientations)[0])
        world_from_relative=first_pose[:3,:3]@(u@vt).T
        orientations=world_from_relative@orientations
        u,_,vt=np.linalg.svd(interp_matrix(stamps,t,orientations))
        rot=u@vt
        p=np.array([q[:3] for _,q in self.pose_prefix])
        tt=(np.asarray([k for k,_ in self.pose_prefix],dtype=np.int64)-self.cp)*1e-9
        v=np.linalg.lstsq(np.column_stack((np.ones(len(tt)),tt)),p,rcond=None)[0][1]
        aw=np.einsum("nij,nj->ni",orientations,self.accel[lo:hi])
        # Express gravity/accelerometer constant from the prior known static prefix
        # in this checkpoint-local world frame using the first local attitude.
        aw-=rot[0]@self.accel[quiet].mean(axis=0)
        encounter=np.array([np.interp((stamps-t[0])*1e-9,(t-t[0])*1e-9,a) for a in aw.T]).T
        clouds=[np.einsum("nij,nj->ni",interp_matrix(times,t,orientations),xyz)@R
                for (xyz,times),R in zip(scan_points,rot)]
        extr_t=np.array([-.05,0.,.055])
        positions,available,_=chain(clouds,stamps,rot,encounter,p[-1],v,extr_t)
        delta=positions[-1]-positions[0]
        k=len(stamps)-3
        motion_body=(positions[k,1]-positions[0,1])-(rot[k]-rot[0])@PRISM_IN_BODY
        native_length=None if native_trial is None else float(np.linalg.norm(np.array(native_trial[start_stamps[-1]][:3])-p[-1]))
        return dict(edges=len(stamps)-1,usable=int(available.sum()),
                    fault_edges=k, fault_usable=int(available[1:k+1].sum()),
                    terminal_fault_supported=bool(available[k]), terminal_body_delta_m=motion_body.tolist(),
                    estimated_lengths_m=np.linalg.norm(delta,axis=1).tolist(),
                    native_displacement_m=native_length,starts_ns=start_stamps)

    def finish_episode(self, origin):
        eid=len(self.closed)+1
        def frozen():
            st=self.send("status")
            return st if "lab_frozen=1" in st and integer(st,"stamp_ns")>self.latest_scan else None
        before=self.wait(frozen,10,"could not freeze native capture at healthy suffix")
        cpfile=self.ctl/f"E{eid}_checkpoint.xyz32"
        pts=np.fromfile(cpfile,"<f4").reshape(-1,3)
        dirty=[(m,d,w) for m,d,w,ok in self.active if not ok]
        assert len(pts)>1000 and dirty
        last_seq=[m.header.stamp.to_nsec() for m,*_ in self.active]
        stamps=[m.header.stamp.to_nsec() for m,_,_ in dirty]
        candidate=[shift_z_cloud(m,-d) for m,d,_ in dirty]
        odd_before=np.asarray([w for _,_,w in dirty])
        odd_after=np.asarray([odd_error(m,self.model) for m in candidate])
        paired=evaluate_paired_sequential_benefit(odd_before,odd_after,min_observations=8)
        mechanisms={k for stamp in stamps for k in self.observed[stamp][0]}
        mea=bool(mechanisms=={"beam"} and paired.approved and np.max(odd_after)<=self.limit)
        accepted=False
        row=dict(action="private_trial",episode=eid,checkpoint_ns=self.cp,alarm_ns=self.onset,
                 healthy_suffix_ns=self.streak.copy(),fault_stamps_ns=stamps,
                 freeze_status=before,checkpoint_points=len(pts),beam_pass=mea,beam_limit_m=self.limit,channels=sorted(mechanisms),
                 beam_wilson=float(paired.wilson_lower_bound),beam_before_m=odd_before.tolist(),
                 beam_after_m=odd_after.tolist(),
                 offered_payload_sha256=[hashlib.sha256(m.data).hexdigest() for m in candidate])
        if mea:
            # Raw and repaired trials use all of this episode's identical captured groups.
            _, row["raw"]=self.branch(eid,"raw",self.cp,stamps)
            trial, row["candidate"]=self.branch(eid,"candidate",self.cp,stamps,candidate)
            assert all(row["raw"][k]==row["candidate"][k] for k in ("groups","first_ns","last_ns"))
            map_result=summary(map_score(trial,candidate,pts))
            scientific=(map_result["support"]>=self.frozen_limits["support_lower_bound"] and
                       map_result["distance_rms_m"]<=self.frozen_limits["distance_rms_upper_bound_m"])
            record={m.header.stamp.to_nsec():m for m in candidate}
            suffix=list(record.get(m.header.stamp.to_nsec(),m) for m,*_ in self.active)
            native_trace=[json.loads(line) for line in (self.ctl/"lab_trace.jsonl").read_text().splitlines()]
            actual=[r for r in native_trace if r["episode"]==eid and r["arm"]=="candidate"]
            last_native={last_seq[-1]:actual[-1]["pose"]}
            row.update(map_result=map_result,local_gate_pass=scientific,
                short_window=self.bridge_displacement([self.previous_cloud]+suffix,origin,last_native))
            accepted=scientific
        row["accepted"]=accepted
        self.event_file.write(json.dumps(row,allow_nan=False)+"\n")
        if accepted:
            release=self.send("lab_release","applied")
            assert integer(release,"valid")==1 and "map_writes=released" in release
            self.arm_after_stamp=integer(release,"stamp_ns")
            current=self.send("status")
            assert integer(current,"stamp_ns")==self.arm_after_stamp
            assert integer(current,"repaired_map_updates")==len(candidate)
            self.event_file.write(json.dumps(dict(action="committed_released",episode=eid,native_response=release,
                native_status=current,live_candidate_map_sha256=hashlib.sha256(
                (self.ctl/f"E{eid}_candidate.xyz32").read_bytes()).hexdigest()))+"\n")
        else:
            assert len(self.streak)==2
            payload=" ".join(str(t) for t in self.streak)
            if eid in BRIDGE_EPISODES[self.arm]:
                decision=dict(used=False,reason="no_qualified_geometry")
                if mea:
                    fit=row["short_window"]
                elif mechanisms.issubset({"transport_clock","azimuth_coverage"}):
                    offsets=[clock for msg,*_ in self.active
                             for channels,clock in [self.observed[msg.header.stamp.to_nsec()]]
                             if "transport_clock" in channels]
                    step=int(np.median(offsets)) if offsets else 0
                    corrected=[]
                    for msg,*_ in self.active:
                        channels,_=self.observed[msg.header.stamp.to_nsec()]
                        c=copy(msg); c.header=copy(msg.header)
                        if "transport_clock" in channels:
                            c.header.stamp=time_to_ros(msg.header.stamp.to_nsec()-step)
                        corrected.append(c)
                    fit=self.bridge_displacement([self.previous_cloud]+corrected,origin)
                else:
                    fit=None
                if fit is not None:
                    decision.update(fit=fit)
                    if (fit["terminal_fault_supported"] and fit["fault_usable"]>=.60*fit["fault_edges"]):
                        payload+=" "+" ".join(str(v) for v in fit["terminal_body_delta_m"])
                        decision.update(used=True,reason="qualified_short_window")
                self.event_file.write(json.dumps(dict(action="bridge_decision",episode=eid,**decision))+"\n")
            if self.arm=="sparse_localization":
                point_limit=.5*float(np.median(self.point_count_prefix))
                eligible=("transport_clock" not in mechanisms and point_limit>0 and
                          all(self.scan_points[t]<point_limit for t in stamps))
                gate="{} {}".format(self.frozen_limits["support_lower_bound"],
                                     self.frozen_limits["distance_rms_upper_bound_m"])
                clock_phase=None
                if all(self.observed[t][0]==["transport_clock"] for t in stamps):
                    phases=[self.observed[t][1] for t in stamps]
                    median=int(np.median(phases))
                    if all(p*median>0 and abs(p-median)<=27_000_000 for p in phases):
                        clock_phase=median
                self.event_file.write(json.dumps(dict(action="sparse_localization",episode=eid,
                    eligible=eligible,point_limit=point_limit,clock_phase_ns=clock_phase,
                    maximum_fault_points=max(self.scan_points[t] for t in stamps)))+"\n")
                if clock_phase is not None:
                    payload+=" time {} {}".format(gate,clock_phase)
                elif eligible:
                    payload+=" localize "+gate
            queued=self.send("reprocess_refusal",payload)
            assert integer(queued,"valid")==1 and integer(queued,"checkpoint_stamp_ns")==self.cp
            q=integer(queued,"queued")
            assert q==len(last_seq)
            target=integer(queued,"target_ns")
            def done():
                ack=self.send("status")
                return ack if integer(ack,"replay_remaining")==0 else None
            done_ack=self.wait(done,30,"refusal catch-up timed out")
            assert integer(done_ack,"refusal_consumed")==q and integer(done_ack,"refusal_imu")+integer(done_ack,"refusal_localize")==q-2
            assert integer(done_ack,"refusal_suffix")==2 and integer(done_ack,"stamp_ns")==target
            assert "map_writes=held" in done_ack
            mark=self.send("lab_export","refusal")
            assert integer(mark,"valid")==1
            release=self.send("lab_release","refusal")
            assert integer(release,"valid")==1 and "map_writes=released" in release
            self.arm_after_stamp=integer(release,"stamp_ns")
            assert self.arm_after_stamp==target
            live_state=self.send("status")
            assert integer(live_state,"stamp_ns")==target and "map_writes=released" in live_state
            self.event_file.write(json.dumps(dict(action="refused_caught_up_released",episode=eid,
                queued=queued,native_completion=done_ack,native_response=release,native_status=live_state,
                live_refusal_map_sha256=hashlib.sha256(
                    (self.ctl/f"E{eid}_refusal.xyz32").read_bytes()).hexdigest()))+"\n")
        self.closed.append(eid)
        self.active.clear()
        self.streak.clear()
        self.mode="AWAIT_LIVE"


def main(out, site, scenario, arm):
    cfg=ROOT/"independent" if site=="nya_01" else SOURCE/site
    origin=json.loads((cfg/"population.json").read_text())["start_ns"]
    events=[e for e in json.loads((cfg/"events.json").read_text()) if e["inject_z_m"]]
    kinds={"narrow_sync":("narrow_fov","sync"),"z_occlusion":("z_shift","occlusion"),
           "sync_narrow":("sync","narrow_fov"),"attenuation_rigid":("attenuation","rigid_ramp"),
           "accept_refuse":("z_shift","attenuation"),"clean":()}[scenario]
    if scenario=="accept_refuse":
        events=[dict(onset_ns=origin+31_300_000_000,end_ns=origin+32_600_000_000,
                     inject_z_m=.5),events[0]]
    BRIDGE_EPISODES[arm]
    speed=1.65
    lo=time_to_ros(origin+26*NS)
    hi=time_to_ros(origin+65*NS)
    with rosbag.Bag(str(cfg/"study.bag")) as bag:
        imu=[m for _,m,_ in bag.read_messages(topics=["/imu_raw"],start_time=lo,end_time=hi)]
        rospy.init_node("auto_native_bridge_trial",disable_signals=True)
        ctl=AutoZ(out,imu)
        ctl.arm=arm
        ctl.wait(lambda:ctl.native_pub.get_num_connections()>0 and ctl.imu_pub.get_num_connections()>0,
                 12,"missing input connections")
        wall=None
        counts=[0,0]
        for _,msg,receipt in bag.read_messages(topics=["/velodyne_points"],start_time=lo,end_time=hi):
            stamp=msg.header.stamp.to_nsec()
            if not origin+27*NS<=stamp<origin+64*NS:
                continue
            transport=(receipt.to_nsec()-origin)/NS
            if wall is None:
                wall=time.monotonic()-transport/speed
            left=wall+transport/speed-time.monotonic()
            if left>0:
                time.sleep(left)
            now=time.monotonic()
            receive_ns=origin+round((now-wall)*speed*NS)
            if stamp<origin+31*NS and arm!="native":
                ctl.diagnose(msg,origin,receive_ns)
            idx=next((j for j,e in enumerate(events[:len(kinds)]) if e["onset_ns"]<=stamp<e["end_ns"]),None)
            if idx is not None:
                counts[idx]+=1
                msg=mutate(msg,kinds[idx],events[idx],counts[idx])
            ctl.input_file.write(json.dumps(dict(stamp_ns=stamp,fed_ns=msg.header.stamp.to_nsec(),
                event=idx+1 if idx is not None else None,sha256=hashlib.sha256(msg.data).hexdigest()))+"\n")
            if arm=="native":
                ctl.imu_through(msg.header.stamp.to_nsec())
                ctl.native_pub.publish(msg)
                ctl.latest_scan=msg.header.stamp.to_nsec()
            else:
                ctl.handle(msg,origin,receive_ns)
            wall+=max(0.,time.monotonic()-now) if ctl.mode in ("AWAIT_LIVE","REENTRY") else 0.
        if arm=="native" or ctl.mode=="ARMED":
            ctl.wait_pose(ctl.latest_scan,10)
        tail=ctl.send("status")
        (out/"completion.json").write_text(json.dumps(dict(site=site,scenario=scenario,arm=arm,
            events=ctl.closed,mode=ctl.mode,tail=tail,injected=counts,speed=speed),indent=2)+"\n")


if __name__=="__main__":
    cv2.setNumThreads(1)
    main(Path(sys.argv[1]),*sys.argv[2:])
