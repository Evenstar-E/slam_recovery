"""Bind both planned input streams before starting the replay processes."""
import hashlib
import json
from pathlib import Path

import rosbag

from replay import NS,mutate,time_to_ros

ROOT=Path(__file__).resolve().parent
DATA=ROOT/"independent"


def main():
    config=json.loads((ROOT/"protocol.json").read_text())["independent"]
    origin=json.loads((DATA/"population.json").read_text())["start_ns"]
    windows=json.loads((DATA/"events.json").read_text())
    start,end=[origin+t*NS for t in config["feed_window_s"]]
    counts=[0]*len(windows)
    out={"fault":[],"clean":[]}
    with rosbag.Bag(str(DATA/"study.bag")) as bag:
        for _,msg,_ in bag.read_messages(topics=["/velodyne_points"],
                                         start_time=time_to_ros(start),end_time=time_to_ros(end)):
            t=msg.header.stamp.to_nsec()
            if not start<=t<end:
                continue
            ref=dict(stamp_ns=t,fed_ns=t,event=None,sha256=hashlib.sha256(msg.data).hexdigest())
            out["clean"].append(ref)
            event=next((i for i,w in enumerate(windows) if w["onset_ns"]<=t<w["end_ns"]),None)
            if event is None:
                out["fault"].append(ref)
                continue
            counts[event]+=1
            x=mutate(msg,config["kinds"][event],windows[event],counts[event])
            out["fault"].append(dict(stamp_ns=t,fed_ns=x.header.stamp.to_nsec(),event=event+1,
                                     sha256=hashlib.sha256(x.data).hexdigest()))
    assert counts==[w["frames"] for w in windows]
    assert len(out["clean"])==len(out["fault"])>350
    assert all(
        out["fault"][i]["fed_ns"]<out["fault"][i+1]["fed_ns"]
        for i in range(len(out["fault"])-1)
    )
    (DATA/"expected_inputs.json").write_text(json.dumps(out,separators=(",",":"))+"\n")
    print("Precommitted canonical input count:",len(out["fault"]),counts)

if __name__=="__main__":
    main()
