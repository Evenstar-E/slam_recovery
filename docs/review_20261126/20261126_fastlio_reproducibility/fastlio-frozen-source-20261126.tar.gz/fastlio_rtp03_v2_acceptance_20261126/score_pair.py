"""Supplement the frozen three-arm result where a third arm lacks observations."""
import csv
import json
from evaluate import ROOT,DATA,NS,read,load_arm,read_gt,interp,displacement_error


def main():
    expected=read(DATA/"expected_inputs.json")["fault"]
    native=load_arm("native_fault",expected)
    v2=load_arm("v2_fault",expected)
    assert native["complete_input"] and v2["complete_input"]
    truth=read_gt(DATA/"rtp_03_gt.csv")
    shared=sorted(native["poses"].keys() & v2["poses"].keys())
    ref={key:value for key in shared if
         (value:=interp(*truth,native["poses"][key][1])) is not None}
    public=set(native["public"]) & set(v2["public"])
    results=[]
    lines=[]
    for i,w in enumerate(read(DATA/"events.json"),1):
        start,end=w["onset_ns"],w["end_ns"]
        before=max((t for t in ref if t<start),default=None)
        stats={}
        for name,s,e in (("fault",start,end),("post_3s",end,end+3*NS),("combined",start,end+3*NS)):
            keys=[t for t in ref if s<=t<e]
            paired={a:displacement_error(x,keys,before,ref) for a,x in (("native",native),("v2",v2))}
            stats[name]=paired
            lines.append([i,name,len(keys),paired["native"]["rmse_m"],paired["v2"]["rmse_m"]])
        off=[t for t in ref if end<=t<end+3*NS and t in public]
        common_prior=max((t for t in ref if t<start and t in public),default=None)
        results.append(dict(event=i,metrics=stats,public_only_post={a:displacement_error(x,off,common_prior,ref)
                           for a,x in (("native",native),("v2",v2))}))
    with (ROOT/"NATIVE_V2_PAIR.csv").open("w",newline="") as f:
        writer=csv.writer(f)
        writer.writerow(("event","segment","common_scans","native_rmse_m","v2_rmse_m"))
        writer.writerows(lines)
    (ROOT/"NATIVE_V2_PAIR.json").write_text(json.dumps(results,indent=2,allow_nan=False)+"\n")


if __name__=="__main__":
    main()
