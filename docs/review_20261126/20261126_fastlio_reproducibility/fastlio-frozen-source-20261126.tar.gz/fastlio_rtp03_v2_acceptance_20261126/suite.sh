#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
base=$(dirname "$PWD")
sha256sum -c --quiet PRECOMMIT.sha256
sha256sum -c --quiet ACCEPTANCE_HARNESS.sha256
for version in v0 v2; do
    path="$base/fastlio_stability_20261126/$version"
    (cd "$path" && sha256sum -c --quiet FREEZE.sha256 && sha256sum -c --quiet HOST_SHA256)
done
bash offline.sh prepare.py
bash offline.sh expected_inputs.py
sha256sum independent/{population.json,events.json,expected_inputs.json,study.bag,rtp_03_gt.csv} > LOCKED_POPULATION.sha256
sha256sum -c --quiet LOCKED_POPULATION.sha256
unlink independent/rtp_03.zip
printf '%s\n' 'Verified publisher ZIP, raw and crop. Removed temporary download and extraction after their digests were preserved.' > CLEANUP.txt
while read -r name version condition strategy; do
    rc=0
    bash run_case.sh "$name" "$version" "$condition" "$strategy" || rc=$?
    printf '%s %s\n' "$name" "$rc" >> STATUS.txt
    if [[ -d "$name" && -s "$name/finished_at.txt" ]]; then
        if [[ ! -s "$name/exit.txt" ]]; then printf '%s\n' "$rc" > "$name/exit.txt"; fi
        bash offline.sh compact.py "$name"
    fi
done <<'TABLE'
native_fault v2 fault native
v0_fault v0 fault plain
v2_fault v2 fault sparse_localization
native_clean v2 clean native
v0_clean v0 clean plain
v2_clean v2 clean sparse_localization
TABLE
bash offline.sh evaluate.py
