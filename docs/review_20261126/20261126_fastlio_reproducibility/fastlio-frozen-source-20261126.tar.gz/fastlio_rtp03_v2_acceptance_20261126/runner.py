"""Replay a fixed population through a byte-for-byte frozen controller."""
import hashlib
import json
import os
from pathlib import Path
import sys
import time

import cv2
import rosbag
import rospy
from std_msgs.msg import Bool

import mixed_controller as frozen

ROOT=Path(__file__).resolve().parent
DATA=ROOT/"independent"


class ObservedController(frozen.AutoZ):
    """Observe ROS odometry arrivals and host health signals."""
    def __init__(self,out,imu):
        self.wall_odom=(out/"wall_odom.jsonl").open("x",buffering=1)
        self.signal_log=(out/"host_signals.jsonl").open("x",buffering=1)
        super().__init__(out,imu)
        self.subscribers=[rospy.Subscriber(topic,Bool,self.host_signal,
                           callback_args=topic,queue_size=50)
                          for topic in ("/Issleeping","/Isbuilding")]

    def pose(self,msg):
        self.wall_odom.write(json.dumps(dict(stamp_ns=msg.header.stamp.to_nsec(),
                                            wall_ns=time.monotonic_ns()))+"\n")
        super().pose(msg)

    def host_signal(self,msg,topic):
        self.signal_log.write(json.dumps(dict(topic=topic,value=msg.data,
                                             wall_ns=time.monotonic_ns()))+"\n")


def main(out,condition,strategy):
    version=Path(os.environ["FROZEN_VERSION_DIR"])
    assert Path(frozen.__file__).resolve()==version/"mixed_controller.py"
    protocol=json.loads((ROOT/"protocol.json").read_text())["independent"]
    origin=json.loads((DATA/"population.json").read_text())["start_ns"]
    windows=json.loads((DATA/"events.json").read_text())
    kinds=protocol["kinds"] if condition=="fault" else ()
    counts=[0]*len(windows)
    lo,hi=protocol["read_window_s"]
    begin,end=protocol["feed_window_s"]
    lo=frozen.time_to_ros(origin+lo*frozen.NS)
    hi=frozen.time_to_ros(origin+hi*frozen.NS)
    speed=1.65
    with rosbag.Bag(str(DATA/"study.bag")) as bag:
        imu=[m for _,m,_ in bag.read_messages(topics=["/imu_raw"],start_time=lo,end_time=hi)]
        rospy.init_node("frozen_acceptance",disable_signals=True)
        controller=ObservedController(out,imu)
        controller.arm=strategy
        controller.wait(lambda:controller.native_pub.get_num_connections()>0 and
                        controller.imu_pub.get_num_connections()>0,12,"missing native inputs")
        wall=None
        for _,msg,recorded in bag.read_messages(topics=["/velodyne_points"],start_time=lo,end_time=hi):
            stamp=msg.header.stamp.to_nsec()
            if not origin+begin*frozen.NS<=stamp<origin+end*frozen.NS:
                continue
            position=(recorded.to_nsec()-origin)/frozen.NS
            if wall is None:
                wall=time.monotonic()-position/speed
            after=wall+position/speed-time.monotonic()
            if after>0:
                time.sleep(after)
            now=time.monotonic()
            recv_ns=origin+round((now-wall)*speed*frozen.NS)
            if stamp<origin+31*frozen.NS and strategy!="native":
                controller.diagnose(msg,origin,recv_ns)
            event=next((i for i,win in enumerate(windows[:len(kinds)])
                        if win["onset_ns"]<=stamp<win["end_ns"]),None)
            if event is not None:
                counts[event]+=1
                msg=frozen.mutate(msg,kinds[event],windows[event],counts[event])
            row=dict(stamp_ns=stamp,fed_ns=msg.header.stamp.to_nsec(),event=event+1 if event is not None else None,
                     sha256=hashlib.sha256(msg.data).hexdigest(),wall_feed_ns=time.monotonic_ns())
            controller.input_file.write(json.dumps(row)+"\n")
            if strategy=="native":
                controller.imu_through(msg.header.stamp.to_nsec())
                controller.native_pub.publish(msg)
                controller.latest_scan=msg.header.stamp.to_nsec()
            else:
                controller.handle(msg,origin,recv_ns)
            if controller.mode in ("AWAIT_LIVE","REENTRY"):
                wall+=max(0.,time.monotonic()-now)
        if strategy=="native" or controller.mode=="ARMED":
            controller.wait_pose(controller.latest_scan,10)
        tail=controller.send("status")
        (out/"completion.json").write_text(json.dumps(dict(site="rtp_03",scenario=condition,arm=strategy,
                                                       events=controller.closed,mode=controller.mode,
                                                       tail=tail,injected=counts,speed=speed),indent=2)+"\n")


if __name__=="__main__":
    cv2.setNumThreads(1)
    main(Path(sys.argv[1]),sys.argv[2],sys.argv[3])
