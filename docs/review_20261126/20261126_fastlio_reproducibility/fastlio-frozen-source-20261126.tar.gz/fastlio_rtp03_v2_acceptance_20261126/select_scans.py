"""Select up to three paired public scans after each planned fault."""
import json
import numpy as np
import rosbag
from evaluate import ROOT,DATA,NS,read,load_arm
from replay import records,time_to_ros
from score_mixed import mat

ARMS=("native","v2")


def main():
    expected=read(DATA/"expected_inputs.json")["fault"]
    arms=[load_arm(f"{label}_fault",expected) for label in ARMS]
    poses=[{t:r for t,r in a["poses"].items() if t in a["public"]} for a in arms]
    shared=sorted(set.intersection(*(set(a) for a in poses)))
    windows=read(DATA/"events.json")
    origin=read(DATA/"population.json")["start_ns"]
    chosen=[]
    for index,event in enumerate(windows,1):
        start=event["end_ns"]
        public=[t for t in shared if start<=t<start+3*NS]
        if len(public)>=3:
            chosen.extend((index, public[i]) for i in np.linspace(0,len(public)-1,3,dtype=int))
    if not chosen:
        return
    before=max(t for t in shared if t<windows[0]["onset_ns"])
    transforms=[mat(poses[0][before])@np.linalg.inv(mat(arm[before])) for arm in poses]
    data={}
    fixed={t:(i,event) for i,(event,t) in enumerate(chosen)}
    frames=[]
    with rosbag.Bag(str(DATA/"study.bag")) as bag:
        for _,msg,_ in bag.read_messages(topics=["/velodyne_points"],
                start_time=time_to_ros(min(fixed)-NS),end_time=time_to_ros(max(fixed)+NS)):
            t=msg.header.stamp.to_nsec()
            if t not in fixed:
                continue
            i,event=fixed[t]
            raw,layout=records(msg)
            info=raw.view(layout).reshape(-1)
            pts=np.column_stack([info[axis] for axis in "xyz"])
            distance=np.linalg.norm(pts,axis=1)
            keep=np.flatnonzero(np.isfinite(distance)&(distance>4)&(distance<26))
            if not len(keep):
                raise RuntimeError(f"No plotting points in {t}")
            pts=pts[keep[np.linspace(0,len(keep)-1,min(len(keep),1800),dtype=int)]]+np.array([-.05,0.,.055])
            frames.append(dict(event=event,stamp_ns=t,offset_s=(t-origin)/NS,points=len(pts)))
            for label,arm,transform in zip(ARMS,poses,transforms):
                target=transform@mat(arm[t])
                data[f"{i}_{label}"]=(pts@target[:3,:3].T+target[:3,3]).astype(np.float32)
    assert [f["stamp_ns"] for f in frames]==[t for _,t in chosen]
    np.savez_compressed(ROOT/"rtp03_points.npz",**data)
    (ROOT/"rtp03_plots.json").write_text(json.dumps(dict(arms=dict.fromkeys(ARMS),frames=frames),indent=2)+"\n")

if __name__=="__main__":
    main()
