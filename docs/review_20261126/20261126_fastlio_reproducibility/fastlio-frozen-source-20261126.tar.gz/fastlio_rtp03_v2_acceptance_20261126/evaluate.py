"""Score the already locked population without looking at injection labels online."""
import csv
import json
from bisect import bisect_left,bisect_right
from pathlib import Path
import re

import numpy as np

from score_mixed import p, read_gt, interp, summary

ROOT=Path(__file__).resolve().parent
DATA=ROOT/"independent"
NS=10**9
ARMS=("native","v0","v2")


def read(path):
    return json.loads(path.read_text())


def check_prefix(actual,expected):
    assert actual==expected[:len(actual)],"recorded input diverges from the precommitted population"


def closest_index(values,target):
    i=bisect_left(values,target)
    return min((j for j in (i-1,i) if 0<=j<len(values)),key=lambda j:abs(values[j]-target),default=None)


def frame_bind(telemetry,relay):
    """Pose receipt -> native node consumption -> physical scan timestamp."""
    data_keys=[r["fed_ns"] for r in relay]
    mapping={}
    for item in telemetry["fates"]:
        if item["fate"]!="ingested":
            continue
        began=round(item["beg_s"]*NS)
        i=closest_index(data_keys,began)
        if i is not None and abs(began-data_keys[i])<=2500:
            mapping[item["stamp_ns"]]=relay[i]["stamp_ns"]
    order=sorted(mapping)
    public={}
    unbound=[]
    for odom in telemetry["odom"]:
        t=odom["stamp_ns"]
        nearest=closest_index(order,t)
        if nearest is None or abs(order[nearest]-t)>1500:
            unbound.append(t)
            continue
        key=mapping[order[nearest]]
        if key not in public:
            public[key]=odom
    return public,unbound


def historical_native_phase(telemetry):
    times=[x[1] for x in telemetry["feeds"]]
    keys=[x[0] for x in telemetry["feeds"]]
    held=False
    cuts=[]
    for command in telemetry["commands"]:
        if command.get("command") not in ("hold","lab_release"):
            continue
        when=command.get("monotonic_s")
        ack=command.get("ack","")
        if when is not None and "valid=1" in ack:
            cuts.append((round(when*NS),command["command"]=="hold"))
    changes=iter(sorted(cuts))
    boundary=next(changes,None)
    catalog=[]
    for e in sorted(telemetry["host_markers"],key=lambda e:e["wall_ns"]):
        message=e["message"]
        wall=e["wall_ns"]
        while boundary is not None and boundary[0]<=wall:
            held=boundary[1]
            boundary=next(changes,None)
        i=bisect_right(times,wall)-1
        stamp=keys[i] if i>=0 else None
        m=re.search(r"Degeneracy has happened (\d+) times",message)
        if m:
            n=int(m.group(1))
            if n>=2:
                catalog.append(dict(kind="native_reset_deferred" if held else "native_re_slam",
                                    wall_ns=wall,last_fed_ns=stamp,native_count=n))
        elif "has disappear" in message:
            catalog.append(dict(kind="native_build_signal",wall_ns=wall,last_fed_ns=stamp))
        elif "reset when rosbag" in message:
            catalog.append(dict(kind="native_imu_reset",wall_ns=wall,last_fed_ns=stamp))
    return catalog


def load_arm(name,expected):
    path=ROOT/name
    receipt=read(path/"receipt.json")
    telemetry=read(path/"telemetry.json")
    track=read(path/"trajectory.json")
    relay=track["input_identities"]
    check_prefix(relay,expected)
    public,unbound=frame_bind(telemetry,relay)
    health=historical_native_phase(telemetry)
    return dict(receipt=receipt,relay=relay,telemetry=telemetry,
                public=public,unbound=unbound,health=health,
                poses={r[0]:r for r in track["selected"]},complete_input=len(relay)==len(expected))


def maximum_gap(public,lo,hi):
    body=[t for t in public if lo<t<hi]
    return float(max(np.diff([lo]+body+[hi])))*1e-9


def frozen_lifecycle(data,event,window,expected):
    receipt=data["receipt"]
    lookup={r["fed_ns"]:r["stamp_ns"] for r in expected if r["event"]==event}
    alarms=[r for r in receipt["events"] if r["action"]=="triggered" and r["alarm_scan_ns"] in lookup]
    if not alarms:
        return dict(decision="native" if receipt["final"] and receipt["final"]["arm"]=="native"
                    else "no_trigger_in_fault",rearmed=False)
    assert len(alarms)==1
    trigger=alarms[0]
    eid=trigger["episode"]
    block=[r for r in receipt["events"] if r["episode"]==eid]
    end=next((r for r in block if r["action"] in ("refused_caught_up_released","committed_released")),None)
    again=next((r for r in block if r["action"]=="rearmed"),None)
    original=lookup[trigger["alarm_scan_ns"]]
    faults=[r for r in receipt["refusal_receipts"] if r["episode"]==eid and r["math"]!="lidar_update"]
    good=[r for r in receipt["refusal_receipts"] if r["episode"]==eid and r["math"]=="lidar_update"]
    actual=sorted(r["scan_ns"] for r in faults)
    wanted=sorted(lookup)
    proof=len(actual)==len(wanted) and all(abs(a-b)<=1024 for a,b in zip(actual,wanted))
    return dict(decision=end["action"] if end else "held_or_incomplete",episode=eid,
                trigger_ns=original,channels=trigger["channels"],
                trigger_after_first_fault_ms=(original-min(lookup.values()))/1e6,
                trigger_after_nominal_ms=(original-window["onset_ns"])/1e6,
                handle_to_hold_ms=trigger.get("handle_to_hold_s",0)*1e3,
                first_rearmed_odom_ns=again["first_new_public_pose_ns"] if again else None,
                rearmed=bool(again),fault_receipts=len(faults),fault_identities_exact=proof,
                localization_updates=sum(r["math"]=="localization_only" for r in faults),
                retimed=sum(bool(r.get("retimed")) for r in faults),healthy_updates=len(good))


def displacement_error(data,keys,prior,reference):
    if prior is None or not keys:
        return summary([])
    pose=data["poses"]
    return summary([np.linalg.norm(p(pose[t])-p(pose[prior]))-
                    np.linalg.norm(reference[t]-reference[prior]) for t in keys])


def first_public_displacement(data,first,prior,truth,reference):
    if first is None or prior is None or first not in data["poses"] or prior not in data["poses"]:
        return None
    pose=data["poses"]
    target=interp(*truth,pose[first][1])
    if target is None:
        return None
    return float(np.linalg.norm(p(pose[first])-p(pose[prior]))-np.linalg.norm(target-reference[prior]))


def latencies(clean,keys):
    feed=dict(clean["telemetry"]["feeds"])
    return [(clean["public"][t]["wall_ns"]-feed[t])/1e6 for t in keys if t in feed]


def main():
    expected=read(DATA/"expected_inputs.json")
    windows=read(DATA/"events.json")
    config=read(ROOT/"protocol.json")["independent"]
    truth=read_gt(DATA/"rtp_03_gt.csv")
    all_arms={c:{a:load_arm(f"{a}_{c}",expected[c]) for a in ARMS} for c in ("fault","clean")}
    fault=all_arms["fault"]
    clean=all_arms["clean"]
    reference_pose=fault["native"]["poses"]
    public_keys={a:sorted(d["public"]) for a,d in fault.items()}
    common=sorted(set.intersection(*(set(d["poses"]) for d in fault.values())))
    refs={t:v for t in common if (v:=interp(*truth,reference_pose[t][1])) is not None}
    baseline_keys=[r["stamp_ns"] for r in expected["fault"]]
    clean_keys=[r["stamp_ns"] for r in expected["clean"]]
    clean_shared=sorted(set.intersection(*(set(d["public"]) for d in clean.values())))
    # The common clean output start excludes ordinary startup frames by construction.
    clean_start=clean_shared[0] if clean_shared else clean_keys[0]
    clean_slots=[t for t in clean_keys if t>=clean_start]
    events=[]
    csv_rows=[]
    for i,(w,kind) in enumerate(zip(windows,config["kinds"]),1):
        lo,hi=w["onset_ns"],w["end_ns"]
        tail=hi+3*NS
        prior=max((t for t in refs if t<lo),default=None)
        public_prior=max((t for t in refs if t<lo and all(t in role["public"] for role in fault.values())),default=None)
        target=[t for t in baseline_keys if lo<=t<tail]
        e=dict(event=i,kind=kind,onset_ns=lo,end_ns=hi,arms={})
        for label,d in fault.items():
            dt=frozen_lifecycle(d,i,w,expected["fault"])
            before=max((t for t in public_keys[label] if t<lo),default=None)
            # Next actual public pose of the corresponding release if the controller recorded one.
            release_stamp=dt.get("first_rearmed_odom_ns")
            if release_stamp is not None:
                candidates=[t for t in target if t>=hi and t in d["public"] and
                            d["public"][t]["stamp_ns"]==release_stamp]
            else:
                candidates=[t for t in target if t>=hi and t in d["public"]]
            first=min(candidates,default=None)
            missed=sum(t not in d["public"] for t in target)
            status=[x for x in d["health"] if x["last_fed_ns"] is not None and lo<=x["last_fed_ns"]<tail]
            dt.update(n_slots=len(target),published=len(target)-missed,missed=missed,
                      output_ratio=(len(target)-missed)/len(target),
                      tracking_markers=status,actual_resets=sum(x["kind"]=="native_re_slam" for x in status),
                      max_no_public_s=maximum_gap(public_keys[label],lo,tail),
                      first_public_after_end_s=(first-hi)/NS if first is not None else None,
                      before_to_first_s=(first-before)/NS if first is not None and before is not None else None,
                      first_public_error_m=first_public_displacement(d,first,public_prior,truth,refs))
            for tag,a,b in (("fault",lo,hi),("post_3s",hi,tail),("combined",lo,tail)):
                picked=[t for t in refs if a<=t<b]
                dt[tag]=displacement_error(d,picked,prior,refs)
            e["arms"][label]=dt
            csv_rows.append([i,kind,label,dt["decision"],dt["rearmed"],dt["actual_resets"],
                            dt["published"],dt["n_slots"],dt["max_no_public_s"],dt["first_public_after_end_s"],
                            dt["first_public_error_m"],dt["fault"]["rmse_m"],dt["post_3s"]["rmse_m"],
                            dt["combined"]["rmse_m"],dt["combined"]["n"]])
        native=e["arms"]["native"]
        e["native_class"]=(
            "observed_native_loss_or_reset" if native["actual_resets"] else
            "native_public_gap_without_reset_marker" if native["missed"] else
            "continued_native_output")
        events.append(e)
    clean_metrics={}
    for role,d in clean.items():
        values=latencies(d,clean_shared)
        clean_metrics[role]=dict(exit=d["receipt"]["code"],input_complete=d["complete_input"],
            alarms=sum(r["action"]=="triggered" for r in d["receipt"]["events"]),
            isolates=sum(r["action"]=="triggered" and "map_writes=held" in r["hold"]
                         for r in d["receipt"]["events"]),
            public=len(d["public"]),eligible_slots=len(clean_slots),
            missing=sum(t not in d["public"] for t in clean_slots),
            actual_resets=sum(r["kind"]=="native_re_slam" for r in d["health"]),
            latency_pairs=len(values),latency_p50_ms=float(np.median(values)) if values else None,
            latency_p95_ms=float(np.quantile(values,.95)) if values else None)
    if clean_shared:
        ref=np.array(latencies(clean["native"],clean_shared))
        for role in clean:
            delta=np.array(latencies(clean[role],clean_shared))-ref
            clean_metrics[role]["paired_extra_latency_p50_ms"]=float(np.median(delta))
            clean_metrics[role]["paired_extra_latency_p95_ms"]=float(np.quantile(delta,.95))
    integrity={c:{a:dict(exit=d["receipt"]["code"],complete_input=d["complete_input"],
                        strictly_increasing=d["receipt"]["public_increasing"],
                        private_leaks=d["receipt"]["private_leaked"],
                        unbound_public=len(d["unbound"]),health=d["health"])
                      for a,d in fleet.items()} for c,fleet in all_arms.items()}
    gains=[e["arms"]["v0"]["combined"]["rmse_m"]-e["arms"]["v2"]["combined"]["rmse_m"]
           if all(e["arms"][r]["combined"]["rmse_m"] is not None for r in ("v0","v2")) else None
           for e in events]
    gates=dict(both_primary_improve=all(x is not None and x>0 for x in gains[:2]),
               v2_cycle_complete_without_resets=all(e["arms"]["v2"]["rearmed"] and
                e["arms"]["v2"]["actual_resets"]==0 for e in events) and
                integrity["fault"]["v2"]["exit"]==0 and integrity["fault"]["v2"]["complete_input"],
               v2_no_extra_missing=all(e["arms"]["v2"]["missed"]<=e["arms"]["v0"]["missed"] for e in events),
               narrow_combined_no_worse=(gains[2] is not None and gains[2]>=0),
               clean_no_new_errors=clean_metrics["v2"]["exit"]==0 and clean_metrics["v2"]["alarms"]==0 and
                   clean_metrics["v2"]["isolates"]==0 and clean_metrics["v2"]["input_complete"] and
                   clean_metrics["v2"]["missing"]<=clean_metrics["native"]["missing"])
    output=dict(sequence="rtp_03",planned_scans=len(baseline_keys),prism_common_scans=len(refs),
                events=events,clean=clean_metrics,integrity=integrity,primary_combined_gains_m=gains,
                continuous_gate=gates,continuous_go=all(gates.values()))
    with (ROOT/"EVENTS.csv").open("w",newline="") as stream:
        writer=csv.writer(stream)
        writer.writerow(("event","kind","arm","decision","rearmed","actual_resets","public_slots","total_slots",
                         "max_no_public_s","return_after_end_s","reentry_displacement_error_m",
                         "fault_rmse_m","post_3s_rmse_m","combined_rmse_m","combined_common_frames"))
        writer.writerows(csv_rows)
    (ROOT/"RESULTS.json").write_text(json.dumps(output,indent=2,allow_nan=False)+"\n")
    print(json.dumps(dict(gates=gates,clean=clean_metrics),indent=2))


if __name__=="__main__":
    main()
