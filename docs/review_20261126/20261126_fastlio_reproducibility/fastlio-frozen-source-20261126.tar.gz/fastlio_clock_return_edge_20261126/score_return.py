"""Compare the frozen prior results with exact-trace return-edge regressions."""
import json
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parent
MATRIX = ROOT.parent/"fastlio_full_cycle_matrix_20261126"
RTP = ROOT.parent/"fastlio_rtp03_v2_acceptance_20261126"
sys.path.insert(0,str(MATRIX))
from score_matrix import base, event_lifecycle, event_actions, gt_for, same_stamps


def main():
    fixtures = base.read(ROOT/"FIXTURES.json")
    check_prefix = base.check_prefix

    def check(rows, reference):
        check_prefix([{key: row[key] for key in reference[0]} for row in rows],reference)

    base.check_prefix = check
    old_roots = dict(eee_clock=(MATRIX,"sync_plugin"),sbs_clock_narrow=(MATRIX,"sync_narrow_plugin"),
                     rtp03_noisy=(ROOT.parent/"fastlio_rtp03_clock_retiming_20261126","noisy_retimed"),
                     rtp03_clean_challenge=(ROOT.parent/"fastlio_rtp03_clock_retiming_20261126","challenge_retimed"))
    result = dict(cases={})
    for case,fixture in fixtures.items():
        spec = fixture["input"]
        population = spec["inputs"]
        windows = spec["windows"]
        origin = spec["origin_ns"]
        archived_root, archived_name = old_roots[case]
        base.ROOT = archived_root
        old = base.load_arm(archived_name,population)
        base.ROOT = ROOT
        new = base.load_arm(case,population)
        actual_trace = [r[:3] for r in new["telemetry"]["receiver_trace"]]
        row = dict(
            exit=new["receipt"]["code"], full_input=new["complete_input"],
            exact_trace=actual_trace==fixture["receiver"],
            input_count=len(new["relay"]), native_markers=new["health"],
            strictly_increasing=new["receipt"]["public_increasing"], private_leaked=new["receipt"]["private_leaked"],
            old_public=len(old["public"]), public=len(new["public"]),
            outside_triggered=[], events=[])
        result["cases"][case] = row
        triggers = event_actions(new,"triggered")
        physical = {r["fed_ns"]:r["stamp_ns"] for r in population}
        event_by_stamp = {r["fed_ns"]:r["event"] for r in population}
        row["outside_triggered"] = [r["alarm_scan_ns"] for r in triggers
                                    if event_by_stamp.get(r["alarm_scan_ns"]) is None]
        if not windows:
            row["clean_pass"] = not triggers and set(new["public"])==set(old["public"])
            continue
        if spec["site"]=="rtp_03":
            base.ROOT = RTP
            expected = base.read(RTP/"independent"/"expected_inputs.json")["fault"]
            native = base.load_arm("native_fault",expected)
            truth = base.read_gt(ROOT/"independent"/"rtp_03_gt.csv")
        else:
            base.ROOT = MATRIX
            native = base.load_arm(f"{fixture['case']}_native",population)
            truth = gt_for(spec["site"])
        arms = dict(native=native,previous=old,patched=new)
        common = sorted(set.intersection(*(set(arm["poses"]) for arm in arms.values())))
        ref = {t:v for t in common if (v:=base.interp(*truth,native["poses"][t][1])) is not None}
        prior_rearm_ns = None
        for j,w in enumerate(windows):
            lo,hi = w["onset_ns"],w["end_ns"]
            tail = min(hi+3*base.NS,windows[j+1]["onset_ns"]) if j+1<len(windows) else hi+3*base.NS
            injected = [r for r in population if r["event"]==w["id"]]
            physical_keys = [r["stamp_ns"] for r in injected]
            fed_keys = [r["fed_ns"] for r in injected]
            associated = [r for r in triggers if r["alarm_scan_ns"] in fed_keys]
            trigger = associated[0] if len(associated)==1 else None
            life = event_lifecycle(new,trigger,physical,physical_keys,fed_keys)
            episode = life.get("episode")
            rows = event_actions(new,"sensor_clock_frame",episode) if episode else []
            old_retimed = [x for x in old["receipt"]["refusal_receipts"] if x.get("retimed")
                           and any(abs(x["scan_ns"]-t)<=1024 for t in fed_keys)]
            fixed_rows = [x for x in new["receipt"]["refusal_receipts"] if x.get("retimed")
                          and any(abs(x["scan_ns"]-t)<=1024 for t in fed_keys)]
            reordered = same_stamps([r["scan_ns"] for r in fixed_rows],fed_keys)
            healthy = [r for r in rows if r["state"]=="returned"]
            early_healthy = [physical[r["scan_ns"]] for r in healthy if physical[r["scan_ns"]]<hi]
            rearm = [key for key,out in new["public"].items() if out["stamp_ns"]==life.get("rearm_pose_ns")]
            rearm_key = min(rearm) if rearm else None
            anchor = max((t for t in ref if t<lo and all(t in a["public"] for a in arms.values())),default=None)
            chosen = [t for t in ref if lo<=t<tail]
            prior_public = max((t for t in new["public"] if t<lo),default=None)
            next_public = min((t for t in new["public"] if lo<=t<tail),default=None)
            metrics = dict(
                kind=w["kind"], actual_injected=len(injected), lifecycle=life,
                old_retimed=len(old_retimed), exact_retimed_identities=reordered,
                old_fault_public=sum(t in old["public"] for t in physical_keys),
                fault_public=sum(t in new["public"] for t in physical_keys),
                patched_public_slots=sum(lo<=t<tail for t in new["public"]),
                first_public_gap_s=(next_public-prior_public)/base.NS if prior_public and next_public else None,
                first_return_s=(physical[healthy[0]["scan_ns"]]-origin)/base.NS if healthy else None,
                early_healthy=len(early_healthy), rearmed_at_s=(rearm_key-origin)/base.NS if rearm_key else None,
                rearmed_before_this=prior_rearm_ns<lo if prior_rearm_ns is not None else None,
                receiver_sign_flips=sum(r["measured_receiver_phase_ns"]<0 for r in rows if r["scan_ns"] in fed_keys),
                rms={arm:base.displacement_error(data,chosen,anchor,ref) for arm,data in arms.items()})
            if fixed_rows and reordered:
                metrics["max_corrected_scan_error_ms"] = max(
                    abs(a["corrected_scan_ns"]-b)/1e6 for a,b in zip(fixed_rows,physical_keys))
            metrics["check"] = (
                life["full_closure"] and metrics["fault_public"]==0 and not early_healthy
                and rearm_key is not None and rearm_key>=hi
                and (w["kind"]!="sync" or reordered)
                and (j==0 or metrics["rearmed_before_this"]))
            if rearm_key:
                prior_rearm_ns = rearm_key
            row["events"].append(metrics)
    result["passed"] = all(
        r["exit"]==0 and r["full_input"] and r["exact_trace"] and not r["private_leaked"]
        and r["strictly_increasing"] and not r["outside_triggered"]
        and (all(e["check"] for e in r["events"]) if r["events"] else r["clean_pass"])
        for r in result["cases"].values())
    (ROOT/"RESULTS.json").write_text(json.dumps(result,indent=2,allow_nan=False)+"\n")
    print(json.dumps(result,indent=2,allow_nan=False))


if __name__=="__main__":
    main()
