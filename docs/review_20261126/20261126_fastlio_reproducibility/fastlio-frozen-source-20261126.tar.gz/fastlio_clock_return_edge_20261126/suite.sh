#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "$0")"
root=$(dirname "$PWD")
version="$root/fastlio_stability_20261126/v2"
matrix="$root/fastlio_full_cycle_matrix_20261126"
population="$root/fastlio_rtp03_v2_acceptance_20261126"
sha256sum -c --quiet EXPERIMENT.sha256
(cd "$version" && sha256sum -c --quiet FREEZE.sha256 && sha256sum -c --quiet HOST_SHA256)
if [[ "$1" == local ]]; then
    (cd "$matrix" && sha256sum -c --quiet REVIEW_EVIDENCE.sha256 && sha256sum -c --quiet SOURCES.sha256)
    PYTHONPATH="$root/fastlio_rtp03_clock_retiming_20261126:$root/fastlio_rtp03_clock_confirmation_20261126" \
        PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 test_clock_return.py > LOOP_TESTS.txt 2>&1
    profiles=(eee_clock sbs_clock_narrow)
elif [[ "$1" == rtp ]]; then
    bash offline.sh prepare.py
    sha256sum -c --quiet "$population/LOCKED_POPULATION.sha256"
    unlink independent/rtp_03.zip
    profiles=(rtp03_noisy rtp03_clean_challenge)
else
    exit 2
fi
for profile in "${profiles[@]}"; do
    rc=0
    bash run_case.sh "$profile" "$profile" || rc=$?
    printf '%s %s\n' "$profile" "$rc" >> STATUS.txt
    if [[ -d "$profile" && -s "$profile/finished_at.txt" ]]; then
        if [[ ! -s "$profile/exit.txt" ]]; then printf '%s\n' "$rc" > "$profile/exit.txt"; fi
        bash offline.sh compact.py "$profile"
    fi
done
if [[ "$1" == rtp ]]; then
    unlink independent/study.bag
    printf '%s\n' 'Cleaned RTP03 archive, extracted raw and shared crop after verification. Removed per-run transient logs and privately exported maps.' > CLEANUP.txt
fi
(cd "$version" && sha256sum -c --quiet FREEZE.sha256 && sha256sum -c --quiet HOST_SHA256)
