"""Extract the frozen Nanyang Auditorium evaluation window from the verified original archive."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

import numpy as np
import rosbag

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "independent"
NS = 10**9
TOPICS = {"/os1_cloud_node1/points":"/velodyne_points", "/imu/imu":"/imu_raw"}


def digest(path):
    sha = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 << 20), b""):
            sha.update(block)
    return sha.hexdigest()


def main():
    protocol = json.loads((ROOT/"protocol.json").read_text())["independent"]
    archive, gt = DATA/"rtp_03.zip", DATA/"rtp_03_gt.csv"
    expected = {name: sha for sha,name in (v.split() for v in (DATA/"download.sha256").read_text().splitlines())}
    assert all(digest(p)==expected[p.name] for p in (archive,gt))
    raw = DATA/"raw.bag.tmp"
    crop = DATA/"study.bag"
    wrapped = DATA/"nested.zip.tmp"
    layers = []
    try:
        with zipfile.ZipFile(archive) as outer:
            member, = [i for i in outer.infolist() if not i.is_dir() and
                       Path(i.filename).suffix in (".bag",".zip")]
            layers.append(member.filename)
            if Path(member.filename).suffix==".zip":
                assert member.file_size < 5_000_000_000
                with outer.open(member) as source, wrapped.open("xb") as sink:
                    shutil.copyfileobj(source,sink,4<<20)
        with zipfile.ZipFile(wrapped if wrapped.exists() else archive) as z:
            recording, = [i for i in z.infolist() if i.filename.endswith(".bag")]
            if wrapped.exists():
                layers.append(recording.filename)
            assert recording.file_size == 13_950_899_164
            with z.open(recording) as source, raw.open("xb") as sink:
                shutil.copyfileobj(source,sink,4<<20)
    finally:
        if wrapped.exists():
            wrapped.unlink()
    count = Counter()
    stamps = {topic:[] for topic in TOPICS}
    bag_sha = digest(raw)
    try:
        with rosbag.Bag(str(raw)) as bag, rosbag.Bag(str(crop),"w",compression="lz4") as selection:
            meta = bag.get_type_and_topic_info()[1]
            assert meta["/os1_cloud_node1/points"].msg_type=="sensor_msgs/PointCloud2"
            assert meta["/imu/imu"].msg_type=="sensor_msgs/Imu"
            origin = min(next(bag.read_messages(topics=[t])).message.header.stamp.to_nsec() for t in TOPICS)
            lo,hi = protocol["read_window_s"]
            fields = None
            for topic,msg,stamp in bag.read_messages(topics=list(TOPICS)):
                if stamp.to_nsec() > origin+(hi+3)*NS:
                    break
                n = msg.header.stamp.to_nsec()
                if not origin+lo*NS <= n < origin+hi*NS:
                    continue
                assert not stamps[topic] or n > stamps[topic][-1]
                stamps[topic].append(n)
                if topic=="/os1_cloud_node1/points" and fields is None:
                    fields = {f.name:f.datatype for f in msg.fields}
                    assert fields["ring"] in (2,4) and fields["t"] == 6
                selection.write(TOPICS[topic],msg,msg.header.stamp)
                count[topic] += 1
        assert count["/os1_cloud_node1/points"] > 350 and count["/imu/imu"] > 7000
        with rosbag.Bag(str(crop)) as check:
            for source,target in TOPICS.items():
                assert [stamp.to_nsec() for _,m,stamp in check.read_messages(topics=[target])
                        if m.header.stamp==stamp] == stamps[source]
        windows=[]
        for i,(a,b) in enumerate(protocol["windows_s_since_first_input"],1):
            onset,end = origin+a*NS,origin+b*NS
            scans = sum(onset <= t < end for t in stamps["/os1_cloud_node1/points"])
            assert scans >= 50
            windows.append(dict(id=i,onset_ns=onset,end_ns=end,frames=scans,inject_z_m=0.5))
        desc = dict(sequence="rtp_03", archive=expected[archive.name], zip_members=layers,
                    original_bag_sha256=bag_sha, original_bag_bytes=recording.file_size,
                    study_bag_sha256=digest(crop), study_bag_bytes=crop.stat().st_size,
                    ground_truth_sha256=expected[gt.name], start_ns=origin,
                    input_window_s=[lo,hi],counts=count,point_fields=fields,
                    median_hz={t:float(NS/np.median(np.diff(s))) for t,s in stamps.items()},
                    bag_envelope="Normalized to unmodified header stamp, same as SBS, for controlled replay")
        (DATA/"population.json").write_text(json.dumps(desc,indent=2)+"\n")
        (DATA/"events.json").write_text(json.dumps(windows,indent=2)+"\n")
        print(json.dumps(desc,indent=2))
    finally:
        raw.unlink()


if __name__=="__main__":
    main()
