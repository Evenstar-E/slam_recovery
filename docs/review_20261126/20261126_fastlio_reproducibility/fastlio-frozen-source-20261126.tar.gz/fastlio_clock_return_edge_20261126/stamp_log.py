"""Timestamp the native tracking messages used for acceptance."""
import json
import sys
import time

MARKERS=("Degeneracy has happened","Degeneracy during external hold","Over-degeneracy has happened",
         "Over-degeneracy has disappear","reset when rosbag","process has died","started with pid")

for line in sys.stdin:
    if any(marker in line for marker in MARKERS):
        print(json.dumps({"wall_ns":time.monotonic_ns(),"message":line.rstrip()}),flush=True)
