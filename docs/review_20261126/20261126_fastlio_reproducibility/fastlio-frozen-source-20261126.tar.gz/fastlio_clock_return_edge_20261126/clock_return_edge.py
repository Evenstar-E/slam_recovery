"""Validate the end of one confirmed clock step using local intervals."""
from dataclasses import dataclass
import json

from clock_confirmation import CHANNEL, LIMIT_NS
from sensor_clock_retiming import RetimeConfirmedStep


@dataclass
class ClockReturn:
    previous_ns: int
    offset_ns: int
    low_ns: int
    high_ns: int
    initial: bool = True
    saw_reverse_edge: bool = False

    def distance(self, interval_ns):
        return max(self.low_ns-interval_ns, interval_ns-self.high_ns, 0)

    def observe(self, stamp_ns, phase_ns):
        interval = stamp_ns-self.previous_ns
        self.previous_ns = stamp_ns
        ordinary = self.distance(interval)
        reverse = self.distance(interval+self.offset_ns)
        phase_is_clean = abs(phase_ns)<=LIMIT_NS and abs(phase_ns)<abs(phase_ns-self.offset_ns)
        if self.initial:
            # The previous stage has already confirmed the onset on two scans.
            self.initial = False
            state = "shifted"
        elif not self.saw_reverse_edge and reverse < ordinary and reverse <= LIMIT_NS:
            self.saw_reverse_edge = phase_is_clean
            state = "returned" if phase_is_clean else "unverified_return"
        elif self.saw_reverse_edge:
            state = "returned" if ordinary <= LIMIT_NS and phase_is_clean else "unverified_return"
        else:
            state = "shifted" if ordinary <= LIMIT_NS else "unverified_header"
        return state, interval, ordinary, reverse


class ReturnEdgeRetime(RetimeConfirmedStep):
    def _record_clock(self, action, sample, **fields):
        super()._record_clock(action, sample, **fields)
        if action == "clock_confirmed":
            self.sensor_step = ClockReturn(
                self.last_forwarded_input_ns, self.sensor_step.offset_ns,
                min(self.calibration_intervals_ns), max(self.calibration_intervals_ns))

    def _header_diagnosis(self, stamp_ns, diagnosis):
        reasons, measured_phase, coverage = diagnosis
        clock = self.sensor_step
        state, interval, ordinary, reverse = clock.observe(stamp_ns, measured_phase)
        self.event_file.write(json.dumps(dict(
            action="sensor_clock_frame", episode=len(self.closed)+1, scan_ns=stamp_ns, state=state,
            measured_receiver_phase_ns=measured_phase, header_offset_ns=clock.offset_ns,
            interval_ns=interval, ordinary_distance_ns=ordinary, reverse_distance_ns=reverse,
            healthy_interval_bounds_ns=[clock.low_ns,clock.high_ns]))+"\n")
        other = [reason for reason in reasons if reason != CHANNEL]
        if state == "shifted":
            return other+[CHANNEL], clock.offset_ns, coverage
        if state == "returned":
            return other, 0, coverage
        # Keep this scan private, and make the captured set ineligible for the
        # frozen pure-clock correction. Other recovery gates remain in force.
        return other+["clock_header_unverified"], measured_phase, coverage
