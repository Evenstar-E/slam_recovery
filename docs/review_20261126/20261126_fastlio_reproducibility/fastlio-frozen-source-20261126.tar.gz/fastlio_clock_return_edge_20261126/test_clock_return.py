import unittest

from clock_return_edge import ClockReturn


MS = 1_000_000


class ReturnTest(unittest.TestCase):
    def test_variable_intervals_do_not_accumulate_into_a_return(self):
        tracker = ClockReturn(0,50*MS,69*MS,105*MS)
        stamp = 153*MS
        self.assertEqual(tracker.observe(stamp,50*MS)[0],"shifted")
        for delta in [70,103,103,103,103]*12:
            stamp += delta*MS
            self.assertEqual(tracker.observe(stamp,50*MS)[0],"shifted")
        self.assertEqual(tracker.observe(stamp+53*MS,-1*MS)[0],"returned")
        self.assertEqual(tracker.observe(stamp+123*MS,-2*MS)[0],"returned")

    def test_receive_jitter_alone_does_not_end_the_step(self):
        tracker = ClockReturn(0,50*MS,99*MS,101*MS)
        states = [tracker.observe(time*MS,phase*MS)[0]
                  for time,phase in [(150,50),(250,-149),(350,-65),(450,0),(550,0),(600,0),(700,0)]]
        self.assertEqual(states,["shifted"]*5+["returned"]*2)

    def test_possible_edge_with_shifted_receiver_stays_unverified(self):
        tracker = ClockReturn(0,50*MS,69*MS,105*MS)
        self.assertEqual(tracker.observe(153*MS,50*MS)[0],"shifted")
        self.assertEqual(tracker.observe(206*MS,50*MS)[0],"unverified_return")
        self.assertEqual(tracker.observe(309*MS,0)[0],"shifted")
        self.assertEqual(tracker.observe(362*MS,0)[0],"returned")

    def test_unexpected_large_interval_stays_private(self):
        tracker = ClockReturn(0,50*MS,69*MS,105*MS)
        tracker.observe(153*MS,50*MS)
        self.assertEqual(tracker.observe(360*MS,0)[0],"unverified_header")
        self.assertFalse(tracker.saw_reverse_edge)

    def test_negative_clock_step_requires_reverse_edge(self):
        tracker = ClockReturn(0,-50*MS,69*MS,105*MS)
        self.assertEqual(tracker.observe(53*MS,-50*MS)[0],"shifted")
        self.assertEqual(tracker.observe(156*MS,-50*MS)[0],"shifted")
        self.assertEqual(tracker.observe(309*MS,0)[0],"returned")
        self.assertEqual(tracker.observe(410*MS,0)[0],"returned")


if __name__=="__main__":
    unittest.main(verbosity=2)
