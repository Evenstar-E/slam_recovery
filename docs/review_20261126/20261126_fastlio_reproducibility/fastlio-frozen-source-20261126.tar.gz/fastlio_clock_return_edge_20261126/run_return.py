"""Exercise the two known early releases and the preserved RTP03 traces."""
import json
import os
from pathlib import Path
import sys
import time

import cv2
import rosbag
import rospy

from run_matrix import inputs, SOURCE, frozen
from run_confirmation import ConfirmedController
from clock_return_edge import ReturnEdgeRetime


ROOT = Path(__file__).resolve().parent
NS = frozen.NS


class ReturnController(ReturnEdgeRetime, ConfirmedController):
    pass


def main(out, profile):
    cfg = json.loads((ROOT/"FIXTURES.json").read_text())[profile]
    case = cfg["case"]
    spec = cfg["input"]
    site, origin, windows = spec["site"], spec["origin_ns"], spec["windows"]
    scan_list = spec["inputs"]
    bag_path = ROOT/"independent"/"study.bag" if site == "rtp_03" else SOURCE/site/"study.bag"
    assert Path(frozen.__file__).resolve() == Path(os.environ["FROZEN_VERSION_DIR"])/"mixed_controller.py"
    trace = {raw:(fed,recv) for raw,fed,recv in cfg["receiver"]}
    assert len(trace) == len(scan_list)
    config = {"read_s":[26,65],"feed_s":[27,64]}
    lo, hi = [frozen.time_to_ros(origin+t*NS) for t in config["read_s"]]
    speed = 1.65
    with rosbag.Bag(str(bag_path)) as bag:
        imu = [msg for _,msg,_ in bag.read_messages(topics=["/imu_raw"],start_time=lo,end_time=hi)]
        rospy.init_node("clock_return_replay",disable_signals=True)
        ctl = ReturnController(out,imu)
        ctl.arm = "sparse_localization"
        ctl.wait(lambda:ctl.native_pub.get_num_connections()>0
                 and ctl.imu_pub.get_num_connections()>0,12,"missing native subscribers")
        wall = None
        count = 0
        for msg, recorded, identity in inputs(bag,config,origin,windows):
            assert identity == scan_list[count]
            count += 1
            key = identity["stamp_ns"]
            fed, receive = trace[key]
            assert fed == identity["fed_ns"]
            position = (recorded-origin)/NS
            if wall is None:
                wall = time.monotonic()-position/speed
            remaining = wall+position/speed-time.monotonic()
            if remaining>0:
                time.sleep(remaining)
            now = time.monotonic()
            if key<origin+31*NS:
                ctl.diagnose(msg,origin,receive)
            row = dict(identity,receiver_ns=receive,received_wall_ns=round(now*NS),
                       wall_feed_ns=time.monotonic_ns())
            ctl.input_file.write(json.dumps(row)+"\n")
            ctl.receive(msg,origin,receive,row["received_wall_ns"])
            if ctl.mode in ("AWAIT_LIVE","REENTRY"):
                wall += max(0.,time.monotonic()-now)
        assert count == len(scan_list)
        ctl.flush_clock(origin)
        if ctl.mode=="ARMED":
            ctl.wait_pose(ctl.latest_scan,10)
        tail = ctl.send("status")
        (out/"completion.json").write_text(json.dumps(dict(site=site,scenario=case,arm="return_edge",
            events=ctl.closed,mode=ctl.mode,tail=tail,groups=count,speed=speed),indent=2)+"\n")


if __name__=="__main__":
    cv2.setNumThreads(1)
    main(Path(sys.argv[1]),sys.argv[2])
