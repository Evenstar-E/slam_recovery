#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
base=$(dirname "$PWD")
prior="$base/fastlio_rtp03_v2_acceptance_20261126"
version="$base/fastlio_stability_20261126/v2"
sha256sum -c --quiet EXPERIMENT.sha256
(cd "$version" && sha256sum -c --quiet FREEZE.sha256 && sha256sum -c --quiet HOST_SHA256)
(
    cd independent
    sha256sum -c --quiet download.sha256
)
bash offline.sh prepare.py
sha256sum -c --quiet "$prior/LOCKED_POPULATION.sha256"
unlink independent/rtp_03.zip
printf '%s\n' 'Source ZIP and extracted raw removed after verification. The verified crop is shared by all cases.' > CLEANUP.txt
while read -r name condition strategy; do
    rc=0
    bash run_case.sh "$name" "$condition" "$strategy" || rc=$?
    printf '%s %s\n' "$name" "$rc" >> STATUS.txt
    if [[ -d "$name" && -s "$name/finished_at.txt" ]]; then
        if [[ ! -s "$name/exit.txt" ]]; then printf '%s\n' "$rc" > "$name/exit.txt"; fi
        bash offline.sh compact.py "$name"
    fi
done <<'TABLE'
v2_challenge challenge frozen
confirmed_challenge challenge confirmed
confirmed_clean clean confirmed
v2_clock fault frozen
confirmed_clock fault confirmed
TABLE
(cd "$version" && sha256sum -c --quiet FREEZE.sha256 && sha256sum -c --quiet HOST_SHA256)
bash offline.sh evaluate_clock.py
unlink independent/study.bag
printf '%s\n' 'Removed the shared crop after scoring and per-run logs/maps after sealing telemetry. No per-run bag.' >> CLEANUP.txt
