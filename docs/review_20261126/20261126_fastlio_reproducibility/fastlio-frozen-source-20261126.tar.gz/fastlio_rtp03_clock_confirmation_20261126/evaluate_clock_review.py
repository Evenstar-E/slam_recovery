"""Bind scan identities, checkpoint, and public poses on RTP03."""
from pathlib import Path
import json
import re
import sys

import numpy as np


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "independent"
PRIOR = ROOT.parent / "fastlio_rtp03_v2_acceptance_20261126"
sys.path.insert(0, str(PRIOR))
import evaluate as frozen


def actions(arm, name):
    return [row for row in arm["receipt"]["events"] if row["action"] == name]


def only(items):
    item, = items
    return item


def ns_field(record, name):
    return int(re.search(rf"\b{name}=([0-9]+)", record).group(1))


def main():
    expected = frozen.read(DATA / "expected_inputs.json")
    old = frozen.load_arm("native_clean", expected["clean"])
    frozen.ROOT = ROOT
    original_check = frozen.check_prefix

    def check_input_prefix(actual, reference):
        # Receiver and wall time are telemetry, separate from the original
        # payload/stamp/event identity used to verify the input population.
        identity = tuple(reference[0])
        original_check([{field: row[field] for field in identity} for row in actual], reference)

    frozen.check_prefix = check_input_prefix
    clock_only = [fault if fault["event"] == 1 else clean
                  for fault, clean in zip(expected["fault"], expected["clean"])]
    input_of = {name: clock_only if name.endswith("_clock") else expected["clean"] for name in (
        "v2_challenge", "confirmed_challenge", "confirmed_clean", "v2_clock", "confirmed_clock",
        "matched_clock")}
    arms = {name: frozen.load_arm(name, rows) for name, rows in input_of.items()}
    fixture = frozen.read(ROOT / "CHALLENGE.json")
    windows = frozen.read(DATA / "events.json")
    start = min(old["public"])
    slots = [x["stamp_ns"] for x in expected["clean"] if x["stamp_ns"] >= start]
    result = dict(arms={}, positive={})
    for name, arm in arms.items():
        receipt = arm["receipt"]
        public = arm["public"]
        suspects = actions(arm, "clock_suspect")
        row = dict(exit=receipt["code"], inputs=len(arm["relay"]),
                   input_complete=arm["complete_input"], public=sum(t in public for t in slots),
                   slots=len(slots), alarms=actions(arm, "triggered"),
                   isolated=len(actions(arm, "triggered")), suspects=len(suspects),
                   buffered=sum(s["buffered"] for s in suspects),
                   confirmation_count=len(actions(arm, "clock_confirmed")),
                   dismissals=actions(arm, "clock_dismissed"),
                   resets=arm["health"], private_leaked=receipt["private_leaked"],
                   public_increasing=receipt["public_increasing"],
                   unbound_public=len(arm["unbound"]))
        if not name.endswith("_clock"):
            row["max_public_gap_s"] = frozen.maximum_gap(sorted(public), slots[0], slots[-1])
        result["arms"][name] = row
    for name in ("v2_challenge", "confirmed_challenge"):
        result["arms"][name]["archived_intervals"] = [
            dict(first_scan_ns=episode["scan_keys_ns"][0],
                 present=sum(key in arms[name]["public"] for key in episode["scan_keys_ns"]),
                 total=len(episode["scan_keys_ns"]),
                 suspects=sum(s["scan_ns"] in episode["scan_keys_ns"]
                              for s in actions(arms[name], "clock_suspect")))
            for episode in fixture["episodes"]]

    true_keys = [r["stamp_ns"] for r in clock_only if r["event"] == 1]
    true_fed = [r["fed_ns"] for r in clock_only if r["event"] == 1]
    physical = {row["fed_ns"]: row["stamp_ns"] for row in clock_only}
    previous = clock_only[clock_only.index(next(r for r in clock_only if r["event"] == 1))-1]["stamp_ns"]
    for name in ("v2_clock", "confirmed_clock", "matched_clock"):
        arm = arms[name]
        lifecycle = frozen.frozen_lifecycle(arm, 1, windows[0], clock_only)
        metrics = dict(lifecycle)
        result["positive"][name] = metrics
        triggers = [t for t in actions(arm, "triggered") if t["alarm_scan_ns"] in true_fed]
        if not triggers:
            continue
        event = only(triggers)
        cp = ns_field(event["checkpoint"], "stamp_ns")
        cp_frame = ns_field(event["checkpoint"], "frame")
        native_checkpoint_scan = only(row for row in arm["telemetry"]["fates"]
                                      if row["fate"] == "ingested" and row["stamp_ns"] == cp
                                      and row["frame"] == cp_frame)
        metrics.update(checkpoint_ns=cp, checkpoint_frame=cp_frame,
                       checkpoint_map_points=ns_field(event["checkpoint"], "map_points"),
                       first_fault_physical_ns=true_keys[0],
                       previous_clean_scan_ns=previous,
                       checkpoint_binds_previous_clean=previous in arm["public"] and
                           abs(round(native_checkpoint_scan["beg_s"]*1e9)-previous) <= 2500,
                       checkpoint_minus_previous_ros_pose_ns=cp-arm["public"][previous]["stamp_ns"],
                       checkpoint_precedes_first_fault_start=cp < true_keys[0],
                       hold_uses_checkpoint=ns_field(event["hold"], "stamp_ns") == cp
                           and "map_writes=held" in event["hold"],
                       event_private_leaks=sum(key in arm["public"] for key in true_keys))
        before = max(key for key in arm["public"] if key < true_keys[0])
        after = min(key for key in arm["public"] if key >= windows[0]["end_ns"])
        metrics.update(public_gap_ms=(after-before)/1e6,
                       first_public_after_fault_end_ms=(after-windows[0]["end_ns"])/1e6)
        decisions = [r for r in actions(arm, "sparse_localization") if r["episode"] == event["episode"]]
        metrics["corrected_clock_offset_ms"] = only(decisions)["clock_phase_ns"] / 1e6 if (
            decisions and only(decisions)["clock_phase_ns"] is not None) else None
        observed = {row["stamp_ns"]: row for row in arm["telemetry"]["detector"]}
        metrics["opposite_sign_phase_ms"] = [observed[stamp]["clock_error_ns"]/1e6 for stamp in true_fed
                                              if observed[stamp]["clock_error_ns"] < 0]
        confirms = [r for r in actions(arm, "clock_confirmed") if r["scan_ns"] in true_fed]
        if confirms:
            confirm = only(confirms)
            hold = only(row for row in arm["telemetry"]["commands"] if row.get("command") == "hold"
                        and ns_field(row["ack"], "stamp_ns") == cp)
            hold_ns = round(hold["monotonic_s"] * 1e9)
            metrics.update(confirmation_scan_ns=physical[confirm["confirmation_scan_ns"]],
                           last_forwarded_scan_ns=confirm["last_forwarded_scan_ns"],
                           confirmation_data_ms=(physical[confirm["confirmation_scan_ns"]] - true_keys[0])/1e6,
                           confirmation_wall_ms=(confirm["confirmation_wall_ns"] - confirm["arrived_wall_ns"])/1e6,
                           onset_to_hold_ack_wall_ms=(hold_ns - confirm["arrived_wall_ns"])/1e6,
                           no_fault_forwarded_during_confirmation=confirm["last_forwarded_scan_ns"] == previous)

    peers = arms["confirmed_clean"]["public"]
    keys = sorted(set(old["public"]) & set(peers))
    extras = np.array(frozen.latencies(arms["confirmed_clean"], keys)) - np.array(frozen.latencies(old, keys))
    result["ordinary_clean_historical_native_latency"] = dict(
        paired=len(keys), extra_p50_ms=float(np.median(extras)), extra_p95_ms=float(np.quantile(extras, .95)))
    history = frozen.read(PRIOR/"v2_clean"/"receipt.json")
    scan_keys = [item["stamp_ns"] for item in expected["clean"]]
    origin = frozen.read(DATA/"population.json")["start_ns"]
    nominal = int(np.median([b-a for a,b in zip(scan_keys, scan_keys[1:]) if b < origin+31*frozen.NS]))
    result["historical_alarm_header_steps_ns"] = {
        str(row["alarm_scan_ns"]): row["alarm_scan_ns"]-scan_keys[scan_keys.index(row["alarm_scan_ns"])-1]-nominal
        for row in history["events"] if row["action"] == "triggered"}
    new = result["positive"]["confirmed_clock"]
    rows = result["arms"]
    result["checks"] = dict(
        all_runs_completed=all(r["exit"] == 0 and r["input_complete"] for r in rows.values()),
        no_private_pose_leaks=all(not r["private_leaked"] and r["public_increasing"] for r in rows.values()),
        old_gate_reproduces_both_counterexamples=[a["alarm_scan_ns"] for a in rows["v2_challenge"]["alarms"]]
            == [m["scan_keys_ns"][0] for m in fixture["episodes"]],
        no_isolation_and_full_output=all(rows[name]["isolated"] == 0
            and rows[name]["slots"] == rows[name]["public"] for name in ("confirmed_challenge", "confirmed_clean")),
        confirms_true_fault_at_second_scan=new.get("confirmation_scan_ns") == true_keys[1],
        protects_original_checkpoint=new.get("no_fault_forwarded_during_confirmation", False)
            and new["checkpoint_binds_previous_clean"] and new["checkpoint_precedes_first_fault_start"]
            and new["hold_uses_checkpoint"] and new["event_private_leaks"] == 0,
        paced_full_native_clock_recovery=new.get("retimed") == len(true_keys) and new["fault_identities_exact"]
            and new["healthy_updates"] == 2 and new["rearmed"] and rows["confirmed_clock"]["isolated"] == 1)
    match = result["positive"]["matched_clock"]
    result["checks"].update(
        receiver_trace_matches_exactly=[row[:3] for row in arms["matched_clock"]["telemetry"]["receiver_trace"]]
            == [row[:3] for row in arms["v2_clock"]["telemetry"]["receiver_trace"]],
        matched_full_native_clock_recovery=match.get("retimed") == len(true_keys)
            and match["fault_identities_exact"] and match["healthy_updates"] == 2 and match["rearmed"]
            and rows["matched_clock"]["isolated"] == 1
            and match["corrected_clock_offset_ms"] == result["positive"]["v2_clock"]["corrected_clock_offset_ms"],
        same_checkpoint_as_v2=all(metrics.get(field) == result["positive"]["v2_clock"].get(field)
            for metrics in (new,match) for field in ("checkpoint_ns","checkpoint_frame","checkpoint_map_points")))
    (ROOT / "RESULTS.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(dict(checks=result["checks"], positive=result["positive"],
                          counts={name: (r["isolated"], r["public"]) for name, r in rows.items()}), indent=2))


if __name__ == "__main__":
    main()
