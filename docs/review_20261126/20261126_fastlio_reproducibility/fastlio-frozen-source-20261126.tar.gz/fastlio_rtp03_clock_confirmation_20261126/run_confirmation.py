"""Compare clock confirmation on frozen RTP03 data and the original host."""
import hashlib
import json
import os
from pathlib import Path
import sys
import time

import cv2
import rosbag
import rospy
from std_msgs.msg import Bool

import mixed_controller as frozen
from clock_confirmation import ConfirmClock

ROOT=Path(__file__).resolve().parent
DATA=ROOT/"independent"


class ObservedController(frozen.AutoZ):
    """Observe ROS odometry arrivals and host health signals."""
    def __init__(self,out,imu):
        self.wall_odom=(out/"wall_odom.jsonl").open("x",buffering=1)
        self.signal_log=(out/"host_signals.jsonl").open("x",buffering=1)
        super().__init__(out,imu)
        self.subscribers=[rospy.Subscriber(topic,Bool,self.host_signal,
                           callback_args=topic,queue_size=50)
                          for topic in ("/Issleeping","/Isbuilding")]

    def pose(self,msg):
        self.wall_odom.write(json.dumps(dict(stamp_ns=msg.header.stamp.to_nsec(),
                                            wall_ns=time.monotonic_ns()))+"\n")
        super().pose(msg)

    def host_signal(self,msg,topic):
        self.signal_log.write(json.dumps(dict(topic=topic,value=msg.data,
                                             wall_ns=time.monotonic_ns()))+"\n")


class ConfirmedController(ConfirmClock, ObservedController):
    def beam_alarm(self, msg):
        return max(abs(frozen.estimate(msg, self.model)[0]),
                   frozen.odd_error(msg, self.model)) > self.limit


def main(out, condition, strategy):
    version=Path(os.environ["FROZEN_VERSION_DIR"])
    assert Path(frozen.__file__).resolve()==version/"mixed_controller.py"
    protocol=json.loads((ROOT/"protocol.json").read_text())["independent"]
    origin=json.loads((DATA/"population.json").read_text())["start_ns"]
    windows=json.loads((DATA/"events.json").read_text())
    kinds=("sync",) if condition=="fault" else ()
    challenge = {}
    if condition == "challenge":
        fixture = json.loads((ROOT/"CHALLENGE.json").read_text())
        challenge = {stamp: fixture["receiver_delay_ns"] for row in fixture["episodes"]
                     for stamp in row["scan_keys_ns"]}
    counts=[0]*len(windows)
    lo,hi=protocol["read_window_s"]
    begin,end=protocol["feed_window_s"]
    lo=frozen.time_to_ros(origin+lo*frozen.NS)
    hi=frozen.time_to_ros(origin+hi*frozen.NS)
    speed=1.65
    with rosbag.Bag(str(DATA/"study.bag")) as bag:
        imu=[m for _,m,_ in bag.read_messages(topics=["/imu_raw"],start_time=lo,end_time=hi)]
        rospy.init_node("frozen_acceptance",disable_signals=True)
        controller=(ConfirmedController if strategy == "confirmed" else ObservedController)(out,imu)
        controller.arm="sparse_localization"
        controller.wait(lambda:controller.native_pub.get_num_connections()>0 and
                        controller.imu_pub.get_num_connections()>0,12,"missing native inputs")
        wall=None
        for _,msg,recorded in bag.read_messages(topics=["/velodyne_points"],start_time=lo,end_time=hi):
            stamp=msg.header.stamp.to_nsec()
            if not origin+begin*frozen.NS<=stamp<origin+end*frozen.NS:
                continue
            position=(recorded.to_nsec()-origin)/frozen.NS
            if wall is None:
                wall=time.monotonic()-position/speed
            after=wall+position/speed-time.monotonic()
            if after>0:
                time.sleep(after)
            now=time.monotonic()
            recv_ns=origin+round((now-wall)*speed*frozen.NS)
            if condition == "challenge":
                # Controlled phase replay. Preserve original cloud and IMU timestamps.
                recv_ns = recorded.to_nsec() + challenge.get(stamp, 0)
            if stamp<origin+31*frozen.NS:
                controller.diagnose(msg,origin,recv_ns)
            event=next((i for i,win in enumerate(windows[:len(kinds)])
                        if win["onset_ns"]<=stamp<win["end_ns"]),None)
            if event is not None:
                counts[event]+=1
                msg=frozen.mutate(msg,kinds[event],windows[event],counts[event])
            row=dict(stamp_ns=stamp,fed_ns=msg.header.stamp.to_nsec(),event=event+1 if event is not None else None,
                     sha256=hashlib.sha256(msg.data).hexdigest(),wall_feed_ns=time.monotonic_ns(),
                     receiver_ns=recv_ns,received_wall_ns=round(now*frozen.NS))
            controller.input_file.write(json.dumps(row)+"\n")
            if strategy=="confirmed":
                controller.receive(msg,origin,recv_ns,row["received_wall_ns"])
            else:
                controller.handle(msg,origin,recv_ns)
            if controller.mode in ("AWAIT_LIVE","REENTRY"):
                wall+=max(0.,time.monotonic()-now)
        if strategy=="confirmed":
            controller.flush_clock(origin)
        if controller.mode=="ARMED":
            controller.wait_pose(controller.latest_scan,10)
        tail=controller.send("status")
        (out/"completion.json").write_text(json.dumps(dict(site="rtp_03",scenario=condition,arm=strategy,
                                                       events=controller.closed,mode=controller.mode,
                                                       tail=tail,injected=counts,speed=speed),indent=2)+"\n")


if __name__=="__main__":
    cv2.setNumThreads(1)
    main(Path(sys.argv[1]),sys.argv[2],sys.argv[3])
