"""Check the one-frame confirmation buffer at its host interface."""
from io import StringIO
import json
from types import SimpleNamespace
import unittest

from clock_confirmation import CHANNEL, ConfirmClock


PERIOD = 100_000_000
STEP = 50_000_000
FIRST = 34_000_000_000


class Host:
    def __init__(self):
        self.mode = "ARMED"
        self.sent_imu = 4
        self.closed = []
        self.event_file = StringIO()
        self.calls = []

    def diagnose(self, msg, origin, receiver_ns):
        return msg.reasons, msg.phase, 36

    def beam_alarm(self, msg):
        return msg.beam

    def handle(self, msg, origin, receiver_ns):
        reasons, _, _ = self.diagnose(msg, origin, receiver_ns)
        self.calls.append((msg.header.stamp.to_nsec(), reasons))
        self.sent_imu += 1


class Subject(ConfirmClock, Host):
    def __init__(self):
        super().__init__()
        self.nominal_interval_ns = PERIOD
        self.previous_input_ns = FIRST - PERIOD
        self.last_forwarded_input_ns = self.previous_input_ns

    def scan(self, stamp, phase, beam=False):
        reasons = [CHANNEL] if abs(phase) >= STEP else []
        message = SimpleNamespace(header=SimpleNamespace(stamp=SimpleNamespace(to_nsec=lambda: stamp)),
                                  reasons=reasons, phase=phase, beam=beam)
        self.receive(message, 0, stamp - phase, 2 * stamp)


class ConfirmationTest(unittest.TestCase):
    def test_scheduling_delay_never_gates_clean_headers(self):
        host = Subject()
        for i in range(3):
            host.scan(FIRST + PERIOD * i, -STEP)
        self.assertEqual(host.calls, [(FIRST + PERIOD * i, []) for i in range(3)])

    def test_same_sign_step_gates_from_first_frame(self):
        host = Subject()
        host.scan(FIRST + STEP, STEP)
        self.assertEqual(host.calls, [])
        self.assertEqual(host.sent_imu, 4)
        host.scan(FIRST + PERIOD + STEP, STEP)
        self.assertEqual(host.calls, [(FIRST + STEP, [CHANNEL]), (FIRST + PERIOD + STEP, [CHANNEL])])
        event = json.loads(host.event_file.getvalue().splitlines()[-1])
        self.assertEqual(event["last_forwarded_scan_ns"], FIRST - PERIOD)
        self.assertEqual(event["imu_sent_before_confirmation"], 4)

    def test_unconfirmed_scan_released_in_order(self):
        host = Subject()
        host.scan(FIRST + STEP, STEP)
        host.scan(FIRST + PERIOD, 0)
        self.assertEqual(host.calls, [(FIRST + STEP, []), (FIRST + PERIOD, [])])

    def test_combined_beam_alarm_still_reaches_host(self):
        host = Subject()
        host.scan(FIRST + STEP, STEP, beam=True)
        self.assertEqual(host.calls, [(FIRST + STEP, [CHANNEL])])
        self.assertIsNone(host.pending_clock)

    def test_end_of_input_releases_single_candidate(self):
        host = Subject()
        host.scan(FIRST + STEP, STEP)
        host.flush_clock(0)
        self.assertEqual(host.calls, [(FIRST + STEP, [])])


if __name__ == "__main__":
    unittest.main(verbosity=2)
