"""Confirm an isolated lidar timestamp step before changing the native host."""
from dataclasses import dataclass
import json
from statistics import median


CHANNEL = "transport_clock"
LIMIT_NS = 27_000_000  # Frozen V2 phase tolerance.


@dataclass
class TimingSample:
    stamp_ns: int
    receiver_ns: int
    phase_ns: int
    reasons: list
    coverage: int
    arrived_wall_ns: int
    message: object

    def without_clock_alarm(self):
        return [reason for reason in self.reasons if reason != CHANNEL]


def header_step_agrees(step_ns, phase_ns):
    return (abs(step_ns) > LIMIT_NS and step_ns * phase_ns > 0
            and abs(step_ns - phase_ns) <= LIMIT_NS)


def stable_clock_pair(first, second):
    if second.reasons != [CHANNEL]:
        return False
    phases = (first.phase_ns, second.phase_ns)
    center = int(median(phases))
    return all(phase * center > 0 and abs(phase - center) <= LIMIT_NS for phase in phases)


class ConfirmClock:
    """Hold one not-yet-forwarded scan, only for a corroborated clock candidate."""
    def __init__(self, *args):
        super().__init__(*args)
        self.pending_clock = None
        self.previous_input_ns = None
        self.calibration_intervals_ns = []
        self.nominal_interval_ns = None
        self.precomputed_diagnosis = None
        self.last_forwarded_input_ns = None

    def diagnose(self, msg, origin, receiver_ns):
        if self.precomputed_diagnosis is not None:
            return self.precomputed_diagnosis
        return super().diagnose(msg, origin, receiver_ns)

    def _forward(self, msg, origin, receiver_ns, diagnosis=None):
        self.precomputed_diagnosis = diagnosis
        try:
            super().handle(msg, origin, receiver_ns)
        finally:
            self.precomputed_diagnosis = None
        self.last_forwarded_input_ns = msg.header.stamp.to_nsec()

    def _forward_sample(self, sample, origin, confirmed):
        reasons = sample.reasons if confirmed else sample.without_clock_alarm()
        self._forward(sample.message, origin, sample.receiver_ns,
                      (reasons, sample.phase_ns, sample.coverage))

    def _record_clock(self, action, sample, **fields):
        self.event_file.write(json.dumps(dict(
            action=action, episode=len(self.closed) + 1,
            scan_ns=sample.stamp_ns, phase_ns=sample.phase_ns,
            arrived_wall_ns=sample.arrived_wall_ns, **fields)) + "\n")

    def receive(self, msg, origin, receiver_ns, arrived_wall_ns):
        stamp = msg.header.stamp.to_nsec()
        interval = None if self.previous_input_ns is None else stamp - self.previous_input_ns
        self.previous_input_ns = stamp
        if stamp < origin + 31_000_000_000:
            if interval is not None:
                self.calibration_intervals_ns.append(interval)
            return self._forward(msg, origin, receiver_ns)
        if self.nominal_interval_ns is None:
            self.nominal_interval_ns = int(median(self.calibration_intervals_ns))
        if self.mode == "CALIBRATING":
            self.freeze_calibration()
        if self.mode in ("HELD", "AWAIT_LIVE"):
            return self._forward(msg, origin, receiver_ns)

        reasons, phase, coverage = super().diagnose(msg, origin, receiver_ns)
        # Keep the frozen beam decision authoritative for both simultaneous and
        # independent geometry alarms. Its dedicated calibration is ready at 31 s.
        geometry_alarm = reasons == [CHANNEL] and self.beam_alarm(msg)
        sample = TimingSample(stamp, receiver_ns, phase, reasons, coverage, arrived_wall_ns, msg)
        if self.pending_clock is not None:
            pending = self.pending_clock
            self.pending_clock = None
            if not geometry_alarm and stable_clock_pair(pending, sample):
                self._record_clock("clock_confirmed", pending, confirmation_scan_ns=stamp,
                                   confirmation_phase_ns=phase, confirmation_wall_ns=arrived_wall_ns,
                                   last_forwarded_scan_ns=self.last_forwarded_input_ns,
                                   imu_sent_before_confirmation=self.sent_imu)
                self._forward_sample(pending, origin, confirmed=True)
                return self._forward_sample(sample, origin, confirmed=True)
            self._record_clock("clock_dismissed", pending, next_scan_ns=stamp,
                               reason="next_scan_did_not_confirm")
            self._forward_sample(pending, origin, confirmed=False)

        if reasons == [CHANNEL] and not geometry_alarm:
            step_ns = interval - self.nominal_interval_ns
            can_confirm = header_step_agrees(step_ns, phase)
            self._record_clock("clock_suspect", sample, startup_interval_ns=self.nominal_interval_ns,
                               header_step_ns=step_ns, buffered=can_confirm)
            if can_confirm:
                self.pending_clock = sample
                return
            return self._forward_sample(sample, origin, confirmed=False)
        return self._forward_sample(sample, origin, confirmed=True)

    def flush_clock(self, origin):
        if self.pending_clock is not None:
            pending = self.pending_clock
            self.pending_clock = None
            self._record_clock("clock_dismissed", pending, reason="end_of_input")
            self._forward_sample(pending, origin, confirmed=False)
