"""Development bridge using scan-to-scan translation and short-window inertial motion."""
from dataclasses import dataclass

import cv2
import numpy as np

from slam_recovery.repair.pose_reregistration import (
    MIN_CORRESPONDENCES,
    MOTION_PRIOR_BASE_M,
    STEP_DAMPING,
    estimate_normals,
)

AXIS_Z = np.array([0.,0.,1.])
# The fixed HOST variant uses the same successive distance gates as the existing coarse-to-fine fit.
GATES = ((1.20,4),(.60,4),(.50,5),(.25,5))


class Neighbors:
    def __init__(self, points):
        self.points = np.ascontiguousarray(points, dtype=np.float32)
        self.index = cv2.flann_Index(self.points, dict(algorithm=1, trees=4))

    def query(self, queries, k=1):
        return self.index.knnSearch(np.ascontiguousarray(queries,dtype=np.float32),
                                    k,params=dict(checks=64))


@dataclass
class Fit:
    pose_translation: np.ndarray
    supported: int
    total: int
    holdout_rms: float
    min_eigenvalue: float
    available: bool


def measure_translation(previous, current, rotation, prior):
    """Fit a translation in the frame of the previous original scan."""
    index=Neighbors(previous)
    normals,valid=estimate_normals(previous,grid=index)
    q=(current@rotation.T)
    probe=q[::5]
    train=q[np.arange(len(q))%5!=0][::2]
    t=np.array(prior,copy=True)
    rank=0
    for gate,n_iter in GATES:
        for _ in range(n_iter):
            x=train+t
            idx,d=index.query(x)
            idx,d=idx[:,0],d[:,0]
            take=(d<=gate*gate)&valid[idx]
            if take.sum()<MIN_CORRESPONDENCES: break
            n=normals[idx[take]]
            error=np.einsum('ij,ij->i',n,x[take]-previous[idx[take]])
            dx,_,rank,_=np.linalg.lstsq(n,-error,rcond=None)
            t+=STEP_DAMPING*dx
            if np.linalg.norm(dx)<1e-6: break
    x=probe+t
    idx,d=index.query(x)
    idx,d=idx[:,0],d[:,0]
    keep=(d<=1.0)&valid[idx]
    strength=normals[idx[keep]]
    rv=np.einsum('ij,ij->i',strength,x[keep]-previous[idx[keep]])
    lam=float(np.linalg.eigvalsh(strength.T@strength/max(len(strength),1))[0])
    return Fit(t,int(keep.sum()),len(probe),
               float(np.sqrt(np.mean(rv*rv))) if len(rv) else float('nan'),
               lam,rank==3 and len(rv)>=MIN_CORRESPONDENCES and len(rv)>=.60*len(probe))


def translation_and_step(measured, physical_prior, delta_rotation, previous_bias):
    """Remove the observed bias difference from the relative scan displacement.

    The common per-scan bias contributes b_prev*z - R*b_next*z in the previous frame.
    """
    axis_current = delta_rotation @ AXIS_Z
    expected = physical_prior + previous_bias * (AXIS_Z - axis_current)
    discrepancy = measured-expected
    axial = float(discrepancy@axis_current)
    lateral = float(np.linalg.norm(discrepancy-axial*axis_current))
    step = abs(axial) >= MOTION_PRIOR_BASE_M and abs(axial)>lateral
    bias = previous_bias - axial if step else previous_bias
    physical = measured - previous_bias*AXIS_Z + bias*axis_current
    return physical,bias,step,axial,lateral


def trajectory(scans, rotations, lidar_arms, stamps, accel_world, initial_pose, initial_velocity, extrinsic_t):
    """Build physically paired scan edges. Injection times and reference trajectories are absent."""
    cv2.setNumThreads(1)
    cv2.setRNGSeed(31)
    result={}
    for arm,biases in lidar_arms.items():
        # Bias application happens on the raw XYZ coordinates before the measured deskew.
        clouds=[nominal + axis*b for (nominal,axis),b in zip(scans,biases)]
        r=rotations
        mode_by_name={name:dict(position=initial_pose.copy(),velocity=initial_velocity.copy(),
                                rows=[],bias=0.) for name in ('imu_only','lidar_imu','step_aware')}
        prev=clouds[0]
        for i,(cloud,t) in enumerate(zip(clouds,stamps)):
            if not i:
                for state in mode_by_name.values():
                    state['rows'].append(dict(stamp_ns=int(t),lidar_position=initial_pose.tolist()))
                continue
            dt=(t-stamps[i-1])*1e-9
            Rprev=r[i-1]
            Rpair=Rprev.T@r[i]
            a=(accel_world[i]+accel_world[i-1])*.5
            lever=(r[i]-Rprev)@extrinsic_t
            geometric_fit = None
            for mode, state in mode_by_name.items():
                d=state['velocity']*dt+.5*a*dt*dt
                prior=Rprev.T@(d+lever)
                state['velocity']+=a*dt
                used_fit=False
                fit=None
                step=False
                axial=None
                if mode != 'imu_only':
                    b=state['bias']
                    if mode == 'lidar_imu':
                        geometric_fit=measure_translation(prev,cloud,Rpair,prior)
                    fit=geometric_fit
                    if fit.available:
                        if mode=='step_aware':
                            motion,b,step,axial,_=translation_and_step(fit.pose_translation,prior,Rpair,b)
                            state['bias']=b
                        else:
                            motion=fit.pose_translation
                        d_obs=Rprev@motion-lever
                        # LiDAR observes displacement while the IMU contributes acceleration over
                        # the short interval. Preserve an explicit prior-only fallback on gaps.
                        state['velocity']=.8*state['velocity']+.2*(d_obs/dt+.5*a*dt)
                        d=d_obs
                        used_fit=True
                state['position']+=d+lever
                state['rows'].append(dict(
                    stamp_ns=int(t),lidar_position=state['position'].tolist(),used_lidar=used_fit,
                    prior_translation_m=prior.tolist(),estimated_bias_m=float(state['bias']),
                    step=step,axial_innovation_m=axial,
                    holdout_supported=None if fit is None else fit.supported,
                    holdout_total=None if fit is None else fit.total,
                    holdout_rmse_m=None if fit is None or not np.isfinite(fit.holdout_rms) else fit.holdout_rms,
                    translation_geometry_min_eig=None if fit is None else fit.min_eigenvalue,
                ))
            prev=cloud
        result[arm]={name:s['rows'] for name,s in mode_by_name.items()}
    return result
