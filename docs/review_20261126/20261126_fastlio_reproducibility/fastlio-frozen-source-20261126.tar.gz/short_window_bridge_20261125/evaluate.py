"""Evaluate paired short-window chains without feeding reference positions into the estimator."""
from collections import Counter
import json
from pathlib import Path
import sys

import numpy as np

root=Path(__file__).resolve().parent
reference_root=root.parent/"ntuviral_fastlio_step5_20261125"
sys.path.insert(0,str(reference_root))
from ground_truth_eval import PRISM_IN_BODY, fit, interp, read_gt

state=json.loads((root/(sys.argv[1] if len(sys.argv)>1 else "TRAJECTORIES.json")).read_text())
ti=np.array(state["scan_starts"],dtype=np.int64)
tf=np.array(state["scan_ends"],dtype=np.int64)
origin=state["origin"]
evt=[r for r in json.loads((reference_root/"eee_03"/"events.json").read_text()) if r["inject_z_m"]]
prism_lever=PRISM_IN_BODY - np.array(state['extrinsic_t'])
lever=np.einsum('nij,j->ni',np.array(state['rotations']),prism_lever)
pins,records=read_gt(reference_root/"incoming"/"eee_03_gt.csv")
gt=np.array([g if (g:=interp(pins,records,int(t))) is not None else [np.nan]*3 for t in tf])
valid=np.isfinite(gt).all(axis=1)
assert valid[0]
gt_disp=gt-gt[0]
pops={"event1": (ti>=evt[0]['onset_ns'])&(ti<evt[0]['end_ns']),
      "between": (ti>=evt[0]['end_ns'])&(ti<evt[1]['onset_ns']),
      "event2": (ti>=evt[1]['onset_ns'])&(ti<evt[1]['end_ns']),
      "tail":ti>=evt[1]['end_ns']}
def stats(x):
    x=np.asarray(x)
    return dict(n=len(x),rmse=float(np.sqrt(np.mean(x*x))),median=float(np.median(x)),
                p95=float(np.quantile(x,.95)),maximum=float(np.max(x))) if len(x) else dict(n=0)


def poses(rows):
    return np.array([r["lidar_position"] for r in rows])+lever


basis=poses(state["outcomes"]["clean"]["lidar_imu"])
used=valid&(ti>=evt[0]["onset_ns"])&(ti<evt[1]["onset_ns"])
alignment, fit_receipt=fit(basis[used],gt[used])
end_idx=int(np.flatnonzero(valid)[-1])
doc={
    "anchor_ns":int(tf[0]), "end_ns":int(tf[end_idx]),
    "time_scope_s":((np.array([ti[0],ti[-1]])-origin)*1e-9).tolist(),
    "scan_count":len(ti), "matched_prism":int(valid.sum()),
    "independent_prism_endpoint_displacement_m":float(np.linalg.norm(gt_disp[end_idx])),
    "secondary_common_alignment_from_clean_control":fit_receipt,
    "imu_samples_read":state["imu_count"], "compute_wall_s":state["durations_s"],
    "arms":{},
}
for arm,modes in state["outcomes"].items():
    doc["arms"][arm]={}
    for mode,rows in modes.items():
        est=poses(rows)
        d=est-est[0]
        one_sec=[]
        for i,t in enumerate(tf):
            if not valid[i]: continue
            j=int(np.searchsorted(tf,t+1_000_000_000))
            if 0<j<len(tf) and abs(tf[j-1]-t-1_000_000_000)<abs(tf[j]-t-1_000_000_000):
                j-=1
            if j<len(tf) and abs(tf[j]-t-1_000_000_000)<=50_000_000 and valid[j]:
                one_sec.append(abs(np.linalg.norm(est[j]-est[i])-np.linalg.norm(gt[j]-gt[i])))
        fix=None if alignment is None else est@alignment[0].T+alignment[1]
        j1=int(np.flatnonzero(pops['between'])[0])
        j2=int(np.flatnonzero(pops['tail'])[0]) if np.any(pops['tail']) else None
        panel={
            "lidar_edges":sum(r.get("used_lidar",False) for r in rows),
            "total_edges":len(rows)-1,
            "injected_scans":state["injected_scan_counts"][arm],
            "independent_1s_displacement_length_error_m":stats(one_sec),
            "endpoint_displacement_m":float(np.linalg.norm(d[end_idx])),
            "abs_error_in_endpoint_displacement_m":float(abs(np.linalg.norm(d[end_idx])-np.linalg.norm(gt_disp[end_idx]))),
            "prism_error_common_secondary_alignment_m":stats(np.linalg.norm(fix[valid]-gt[valid],axis=1))
                 if fix is not None else None,
            "edges":{},
            "proposed_changes":[dict(at_s=(int(ti[i])-origin)*1e-9,bias_m=r["estimated_bias_m"],
                                     innovation_m=r["axial_innovation_m"])
                                for i,r in enumerate(rows) if r.get("step",False)],
            "displacement_at_recoveries": {
                "first_elapsed_s":(int(ti[j1])-origin)*1e-9,
                "first_estimated_m":float(np.linalg.norm(d[j1])),
                "first_independent_m":float(np.linalg.norm(gt_disp[j1])) if valid[j1] else None,
                "second_elapsed_s":(int(ti[j2])-origin)*1e-9 if j2 is not None else None,
                "second_estimated_m":float(np.linalg.norm(d[j2])) if j2 is not None else None,
                "second_independent_m":float(np.linalg.norm(gt_disp[j2])) if j2 is not None and valid[j2] else None,
            },
        }
        for k,mask in pops.items():
            ii=np.flatnonzero(mask)
            geometry=[rows[i]['translation_geometry_min_eig'] for i in ii if rows[i]['translation_geometry_min_eig'] is not None]
            panel["edges"][k] = {
                "total":len(ii),"lidar":sum(rows[i]['used_lidar'] for i in ii),
                "min_geom_eigen_median":float(np.median(geometry)) if geometry else None,
            }
        doc["arms"][arm][mode]=panel
print(json.dumps(doc,indent=2,allow_nan=False))
