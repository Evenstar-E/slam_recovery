"""Read the fixed original NTU bag, construct matched arms, and run the estimator."""
import json
from pathlib import Path
import time

import cv2
import numpy as np
import rosbag
import yaml

from bridge_shared import trajectory

ROOT=Path(__file__).resolve().parent
INPUT=ROOT.parent/"ntuviral_fastlio_step5_20261125"/"eee_03"
PAST=ROOT.parent/"native_imu_recovery_20261125"/"eee_imu_dual"/"detection.jsonl"
GYRO_AXES=("x","y","z")
NS=1_000_000_000


def message_xyz(vector):
    return [getattr(vector,key) for key in GYRO_AXES]


def scalp(msg):
    fields={f.name:(f.offset,f.datatype) for f in msg.fields}
    values=[]
    for key,dtype,kind in (('x','<f4',7),('y','<f4',7),('z','<f4',7),('t','<u4',6),('range','<u4',6)):
        offset,typ=fields[key]
        assert typ==kind
        values.append(np.ndarray((msg.height,msg.width),dtype=dtype,buffer=msg.data,offset=offset,
                                 strides=(msg.row_step,msg.point_step)).ravel())
    xyz=np.stack(values[:3],axis=-1).astype(np.float64)
    keep=np.flatnonzero(np.isfinite(xyz).all(axis=1)&(values[4]>4000))
    assert len(keep)>=100
    end_offset=int(values[3][keep].max())
    assert 0<end_offset<150_000_000
    ids=keep[np.linspace(0,len(keep)-1,min(len(keep),6000),dtype=np.int64)]
    return xyz[ids], values[3][ids].astype(np.int64), end_offset


def interp_matrix(targets, times, rotations):
    hi=np.searchsorted(times,targets,side='right')
    assert np.min(hi)>0 and np.max(hi)<len(times)
    lo=hi-1
    u=(targets-times[lo])/(times[hi]-times[lo])
    return rotations[lo]+u[...,None,None]*(rotations[hi]-rotations[lo])


def main():
    origin=int(json.loads((INPUT/"population.json").read_text())["start_ns"])
    config=yaml.safe_load((ROOT/"ntulab.yaml").read_text())
    extr_R=np.asarray(config["mapping"]["extrinsic_R"],dtype=float).reshape(3,3)
    extr_t=np.asarray(config["mapping"]["extrinsic_T"],dtype=float)
    assert np.allclose(extr_R,np.eye(3))
    past=list(map(json.loads,PAST.open()))
    scans=[]; gyro=[]; accel=[]; imu_time=[]
    with rosbag.Bag(str(INPUT/"study.bag")) as bag:
        for topic,msg,_ in bag.read_messages(topics=['/velodyne_points','/imu_raw']):
            at=msg.header.stamp.to_nsec()
            if at<origin+28*NS: continue
            if at>origin+45*NS: break
            if topic=="/imu_raw":
                imu_time.append(at)
                gyro.append(message_xyz(msg.angular_velocity))
                accel.append(message_xyz(msg.linear_acceleration))
            elif origin+31*NS<=at<origin+44*NS:
                points,times,end_offset=scalp(msg)
                scans.append((at,at+end_offset,points,at+times))
    t=np.asarray(imu_time,dtype=np.int64)
    g=np.array(gyro); a=np.array(accel)
    starts=np.array([r[0] for r in scans],dtype=np.int64)
    ends=np.array([r[1] for r in scans],dtype=np.int64)
    assert np.all(np.diff(t)>0) and np.all(np.diff(ends)>0)
    old={r['scan_stamp_ns']:r for r in past}
    assert int(starts[0]) in old
    anchor=np.array(old[int(starts[0])]["T_wb"],dtype=float).reshape(4,4)
    prefix=[r for r in past if starts[0]-500_000_000<=r['scan_stamp_ns']<=starts[0]]
    x=np.array([np.array(r['T_wb']).reshape(4,4)[:3,3] for r in prefix])
    tp=(np.array([r['scan_stamp_ns'] for r in prefix],dtype=np.int64)-starts[0])*1e-9
    design=np.column_stack((np.ones(len(tp)),tp))
    v0=np.linalg.lstsq(design,x,rcond=None)[0][1]
    quiet=(t>=origin+29*NS)&(t<origin+31*NS)
    assert quiet.sum()>100
    g-=g[quiet].mean(axis=0)
    relative=[np.eye(3)]
    for i,dt in enumerate(np.diff(t)*1e-9):
        delta=cv2.Rodrigues(.5*(g[i]+g[i+1])*dt)[0]
        relative.append(relative[-1]@delta)
    relative=np.asarray(relative)
    anchor_interpolated=interp_matrix(np.array([ends[0]]),t,relative)[0]
    u,_,vt=np.linalg.svd(anchor_interpolated)
    world_from_rel=anchor[:3,:3]@(u@vt).T
    orientations=world_from_rel@relative
    interpolated=interp_matrix(ends,t,orientations)
    u,_,vt=np.linalg.svd(interpolated)
    rotations=u@vt
    world_acc=np.einsum("nij,nj->ni",orientations,a)
    world_acc-=world_acc[quiet].mean(axis=0)
    step_acc=np.stack([np.interp((ends-t[0])*1e-9,(t-t[0])*1e-9,world_acc[:,i])
                       for i in range(3)],axis=-1)
    clouds=[]
    for i,(_,end,points,pointtime) in enumerate(scans):
        ori=interp_matrix(pointtime,t,orientations)
        nominal=np.einsum("nij,nj->ni",ori,points)@rotations[i]
        offset_axis=ori[:,:,2]@rotations[i]
        clouds.append((nominal,offset_axis))
    events=[e for e in json.loads((INPUT/"events.json").read_text()) if e['inject_z_m']]
    branches={"clean":np.zeros(len(scans))}
    revert=np.zeros(len(scans))
    for e in events:
        revert[(starts>=e["onset_ns"])&(starts<e["end_ns"])]=e["inject_z_m"]
    branches["reverted_two_events"]=revert
    branches["sustained_event1"]=np.where(starts>=events[0]["onset_ns"],events[0]["inject_z_m"],0.)
    started=time.monotonic()
    outcomes=trajectory(clouds,rotations,branches,ends,step_acc,anchor[:3,3],v0,extr_t)
    out=dict(origin=origin,scan_starts=starts.tolist(),scan_ends=ends.tolist(),
             rotations=rotations.tolist(),extrinsic_t=extr_t.tolist(),
             imu_count=len(t),quiet_imu_count=int(quiet.sum()),velocity_at_start=v0.tolist(),
             durations_s=round(time.monotonic()-started,3),
             original_arrays_sha_role="study bag and old pre-fault fused anchor only",
             injected_scan_counts={k:int(np.count_nonzero(v)) for k,v in branches.items()},
             outcomes=outcomes)
    (ROOT/"TRAJECTORIES_EVENT1.json").write_text(json.dumps(out,indent=2,allow_nan=False)+"\n")


if __name__=="__main__":
    main()
