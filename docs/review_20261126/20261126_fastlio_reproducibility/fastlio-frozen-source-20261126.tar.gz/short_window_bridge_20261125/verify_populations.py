import json
from pathlib import Path
import numpy as np

r=json.loads(Path('TRAJECTORIES_EVENT1.json').read_text())
rows=r['outcomes']
assert rows['clean']['imu_only']==rows['reverted_two_events']['imu_only']==rows['sustained_event1']['imu_only']
assert all([int(x['stamp_ns']) for x in arm]==r['scan_ends'] for a in rows.values() for arm in a.values())
split=1609060374758287417
mask=np.array(r['scan_starts'])<split
match={}
for label in ('lidar_imu','step_aware'):
    a,b=(np.array([val['lidar_position'] for val in rows[key][label]])
         for key in ('reverted_two_events','sustained_event1'))
    match[label]=float(np.max(np.linalg.norm(a[mask]-b[mask],axis=1)))
print(json.dumps({"common_imu_chain_exact":True,"common_scan_populations_exact":True,
                  "pre_split_pose_max_delta_m":match},indent=2))
