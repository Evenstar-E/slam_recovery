from pathlib import Path
source = Path("../campus12_tail_ab_20261124/run_arm.sh").read_text()
source = source.replace('RC=""; LAUNCH=""; PLAY=""; NODE=""; RELAY=""',
                        'RC=""; LAUNCH=""; PLAY=""; NODE=""; RELAY=""; REC=""; PROBE=""')
source = source.replace('cleanup(){', 'cleanup(){ [ -n "$PROBE" ] && kill -TERM "$PROBE" 2>/dev/null;')
anchor = '# shellcheck disable=SC2086'
before = '''"$PY" -u "$PROBE_SCRIPT" "$OUT" "$REPAIR_BAG" > "$OUT/probe.log" 2>&1 & PROBE=$!
for _ in $(seq 1 20); do
  rosnode list 2>/dev/null | grep -q '^/candidate_native_probe$' && break
  sleep 0.5
done
rosnode list | grep -q '^/candidate_native_probe$' || { echo "BLOCKED: native probe registration failed" > "$OUT/result.txt"; exit 4; }
'''
assert source.count(anchor) == 1
source = source.replace(anchor, before+anchor)
source = source.replace('rosbag info "$OUT/frontend.bag"', '''if kill -0 "$PROBE" 2>/dev/null; then kill -TERM "$PROBE" 2>/dev/null; fi
wait "$PROBE"
probe_exit=$?
printf '%s\\n' "$probe_exit" > "$OUT/probe_exit.txt"
rosbag info "$OUT/frontend.bag"''')
source = source.replace('exit "$play_exit"', 'if [ "$play_exit" -ne 0 ]; then exit "$play_exit"; fi\nexit "$probe_exit"')
Path("run_probe.sh").write_text(source)
