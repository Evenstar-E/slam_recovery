from pathlib import Path
import os

root = Path("/home/tong/src/slam_recovery/FAST-LIO/src")
imu_path = root / "IMU_Processing.hpp"
cpp_path = root / "laserMapping.cpp"
imu, cpp = imu_path.read_text(), cpp_path.read_text()


def replace(text, old, new):
    if text.count(old) != 1:
        raise ValueError(f"expected one source anchor: {old[:90]}")
    return text.replace(old, new)


# These are the mutable propagation and initialization fields, excluding the log stream and
# derived per-scan work vectors, which are rebuilt in UndistortPcl.
imu = replace(imu, '  ofstream fout_imu;', '''  struct RecoveryState
  {
    sensor_msgs::ImuConstPtr last_imu;
    V3D cov_acc, cov_gyr, mean_acc, mean_gyr, angvel_last, acc_last;
    Eigen::Matrix<double, 12, 12> process_noise;
    double first_lidar_time, start_time, last_lidar_end_time;
    int init_iter_num;
    bool first_frame, need_init, dynamic_init;
  };
  RecoveryState recovery_state() const
  {
    return {last_imu_, cov_acc, cov_gyr, mean_acc, mean_gyr, angvel_last, acc_s_last,
            Q, first_lidar_time, start_timestamp_, last_lidar_end_time_, init_iter_num,
            b_first_frame_, imu_need_init_, imu_init_dynamic};
  }
  void restore_recovery_state(const RecoveryState& state)
  {
    last_imu_ = state.last_imu;
    cov_acc = state.cov_acc;
    cov_gyr = state.cov_gyr;
    mean_acc = state.mean_acc;
    mean_gyr = state.mean_gyr;
    angvel_last = state.angvel_last;
    acc_s_last = state.acc_last;
    Q = state.process_noise;
    first_lidar_time = state.first_lidar_time;
    start_timestamp_ = state.start_time;
    last_lidar_end_time_ = state.last_lidar_end_time;
    init_iter_num = state.init_iter_num;
    b_first_frame_ = state.first_frame;
    imu_need_init_ = state.need_init;
    imu_init_dynamic = state.dynamic_init;
    IMUpose.clear();
  }
  ofstream fout_imu;''')
imu = replace(imu, '  double last_lidar_end_time_;', '  double last_lidar_end_time_ = 0.0;')
imu = replace(imu, '  double first_lidar_time; \n', '  double first_lidar_time = 0.0;\n')
cpp = replace(cpp, 'struct NrCheckpoint\n{', '''BoxPointType LocalMap_Points;
bool Localmap_Initialized = false;

struct NrCheckpoint
{''')
cpp = replace(cpp, 'BoxPointType LocalMap_Points;      \nbool Localmap_Initialized = false;\n', '')
cpp = replace(cpp, '    double last_imu_time = -1.0;      // IMU cursor at snapshot (p_imu internals are NOT in the cp)\n    double last_lidar_time = -1.0;', '''    ImuProcess::RecoveryState imu;
    BoxPointType local_map;
    bool local_map_initialized = false;
    double first_lidar_stamp = 0.0;
    int queue_index = 0;
    esekfom::esekf<state_ikfom, 12, input_ikfom> queue[kfQueLength], degradation_pre;
    int degradation_count = 0, degradation_history = 0;
    bool dynamic_imu = false, is_publish = false, pub_sleep = false, pub_build = false;''')
cpp = replace(cpp, '    bool replayed = false;\n};', '    bool repaired = false;\n};')
cpp = replace(cpp, 'static std::deque<NrGroup> g_nr_groups;', 'static std::deque<NrGroup> g_nr_replay_groups;\nstatic std::deque<NrGroup> g_nr_groups;')
cpp = replace(cpp, '''static std::map<long long, bool> g_nr_replay_marks;    // group end ns -> pushed by reprocess
static std::map<long long, bool> g_nr_repaired_marks;  // group end ns -> carried a repaired cloud''', '''static int g_nr_degradation_count = 0, g_nr_degradation_history = 0;
static bool g_nr_dynamic_imu = false, g_nr_is_publish = false;
static int g_nr_repaired_map_updates = 0;
static std::ofstream g_nr_updates;''')
# Publish flags live below the native interface in this translation unit.
import re
flags = [re.search(r"(?m)^bool " + name + r" *=[^;\n]+;", cpp) for name in ('hasPubsleep','hasPubbuild')]
assert all(flags), 'host publish flags not found'
for flag in flags:
    cpp = re.sub(r'(?m)^' + re.escape(flag.group(0)), '', cpp, count=1)
cpp = replace(cpp, 'static bool g_nr_dynamic_imu = false, g_nr_is_publish = false;', 'static bool g_nr_dynamic_imu = false, g_nr_is_publish = false;\n' + '\n'.join(flag.group(0) for flag in flags))
cpp = replace(cpp, '''    // Called after a group is taken from the buffers; decides this group's identity (replayed or
    // live, carried a repaired cloud or not) from the marks written when the replay was queued.
    std::lock_guard<std::mutex> lk(g_nr_mtx);
    const long long key = (long long)std::llround(lidar_end_time * 1e9);
    g_nr_cur_is_replay = g_nr_replay_marks.erase(key) > 0;
    g_nr_cur_repaired = g_nr_repaired_marks.erase(key) > 0;''', '''    if (g_nr_cur_is_replay || !g_nr_cp.valid) return;
    std::lock_guard<std::mutex> lk(g_nr_mtx);''')
a = cpp.index('    // Rewind the input cursors too:')
b = cpp.index('    g_nr_lidar_end = g_nr_cp.stamp;', a)
cpp = cpp[:a] + '''    p_imu->restore_recovery_state(g_nr_cp.imu);
    LocalMap_Points = g_nr_cp.local_map;
    Localmap_Initialized = g_nr_cp.local_map_initialized;
    first_lidar_time = g_nr_cp.first_lidar_stamp;
    kfindex = g_nr_cp.queue_index;
    for (int i = 0; i < kfQueLength; ++i) kfqueue[i] = g_nr_cp.queue[i];
    Degradationpre_point = g_nr_cp.degradation_pre;
    g_nr_degradation_count = g_nr_cp.degradation_count;
    g_nr_degradation_history = g_nr_cp.degradation_history;
    g_nr_dynamic_imu = g_nr_cp.dynamic_imu;
    g_nr_is_publish = g_nr_cp.is_publish;
    hasPubsleep = g_nr_cp.pub_sleep;
    hasPubbuild = g_nr_cp.pub_build;
''' + cpp[b:]
cpp = replace(cpp, '''            g_nr_cp.last_imu_time = last_timestamp_imu;
            g_nr_cp.last_lidar_time = last_timestamp_lidar;''', '''            g_nr_cp.imu = p_imu->recovery_state();
            g_nr_cp.local_map = LocalMap_Points;
            g_nr_cp.local_map_initialized = Localmap_Initialized;
            g_nr_cp.first_lidar_stamp = first_lidar_time;
            g_nr_cp.queue_index = kfindex;
            for (int i = 0; i < kfQueLength; ++i) g_nr_cp.queue[i] = kfqueue[i];
            g_nr_cp.degradation_pre = Degradationpre_point;
            g_nr_cp.degradation_count = g_nr_degradation_count;
            g_nr_cp.degradation_history = g_nr_degradation_history;
            g_nr_cp.dynamic_imu = g_nr_dynamic_imu;
            g_nr_cp.is_publish = g_nr_is_publish;
            g_nr_cp.pub_sleep = hasPubsleep;
            g_nr_cp.pub_build = hasPubbuild;''')
cpp = replace(cpp, '''              << " last_repaired_update_ns=" << g_nr_last_repaired_update_ns''', '''              << " last_repaired_update_ns=" << g_nr_last_repaired_update_ns
              << " repaired_map_updates=" << g_nr_repaired_map_updates
              << " replay_remaining=" << g_nr_replay_remaining
              << " map_points=" << ikdtree.validnum()''')
a = cpp.index('            // Re-feed the consumed groups in order;')
b = cpp.index('            g_nr_replay.store(true);', a)
cpp = cpp[:a] + '''            for (const auto& captured : g_nr_groups)
            {
                NrGroup group = captured;
                PointCloudXYZI::Ptr rep;
                if (nr_take_repair(group.beg, group.end, rep))
                {
                    group.lidar = rep;
                    group.repaired = true;
                    ++g_nr_repaired_fed;
                }
                const long long stamp = (long long)std::llround(group.end * 1e9);
                if (end_ns > 0 && stamp > end_ns) ++g_nr_suffix; else ++g_nr_within;
                g_nr_replay_groups.push_back(std::move(group));
            }
''' + cpp[b:]
cpp = replace(cpp, '            s << "OK reprocess replay_suffix=" << g_nr_suffix', '''            s << "OK reprocess valid=1 checkpoint_stamp_ns="
              << (long long)std::llround(g_nr_cp.stamp * 1e9)
              << " checkpoint_frame=" << g_nr_cp.frame
              << " replay_suffix=" << g_nr_suffix''')
cpp = replace(cpp, '    pcl::fromROSMsg(*msg, *cloud);', '''    // The measurement topic carries raw Velodyne fields, including per-return time.
    p_pre->process(msg, cloud);
    if (cloud->size() <= 1) return;''')
cpp = replace(cpp, '''    int degradation_count = 0;
    int getDegradationpre_point = 0;
    bool isIMU_init_dynamic = false;
    bool isPublish = false;''', '''    auto& degradation_count = g_nr_degradation_count;
    auto& getDegradationpre_point = g_nr_degradation_history;
    auto& isIMU_init_dynamic = g_nr_dynamic_imu;
    auto& isPublish = g_nr_is_publish;''')
cpp = replace(cpp, '''        if (sync_packages(Measures))
        {
            // Armed commands run here, before this group is captured or estimated: the snapshot
            // then describes the previous completed frame and never lands after its boundary.
            nr_apply_deferred(lidar_end_time);''', '''        g_nr_cur_is_replay = !g_nr_replay_groups.empty();
        g_nr_cur_repaired = false;
        if (g_nr_cur_is_replay || sync_packages(Measures))
        {
            if (g_nr_cur_is_replay)
            {
                NrGroup group = std::move(g_nr_replay_groups.front());
                g_nr_replay_groups.pop_front();
                Measures.lidar = group.lidar;
                Measures.imu = std::move(group.imu);
                Measures.lidar_beg_time = group.beg;
                lidar_end_time = group.end;
                g_nr_cur_repaired = group.repaired;
                g_nr_replay_remaining = (int)g_nr_replay_groups.size();
                g_nr_replay.store(g_nr_replay_remaining > 0);
            }
            else
                nr_apply_deferred(lidar_end_time);''')
cpp = replace(cpp, '                map_incremental();', '''                map_incremental();
                if (g_nr_cur_repaired) ++g_nr_repaired_map_updates;''')
cpp = replace(cpp, '        g_nr_fates.open(g_nr_dir + "/input_fates.jsonl", std::ios::out);', '''        g_nr_fates.open(g_nr_dir + "/input_fates.jsonl", std::ios::out);
        g_nr_updates.open(g_nr_dir + "/repair_updates.jsonl", std::ios::out);''')
cpp = replace(cpp, '''                g_nr_last_repaired_update_ns = (long long)std::llround(lidar_end_time * 1e9);''', '''                g_nr_last_repaired_update_ns = (long long)std::llround(lidar_end_time * 1e9);
                g_nr_updates << "{\\\\\\"scan_stamp_ns\\\\\\":"
                    << (long long)std::llround(Measures.lidar_beg_time * 1e9)
                    << ",\\\\\\"end_stamp_ns\\\\\\":" << g_nr_last_repaired_update_ns
                    << ",\\\\\\"map_update_count\\\\\\":" << g_nr_repaired_map_updates
                    << ",\\\\\\"map_points\\\\\\":" << ikdtree.validnum() << "}" << std::endl;'''.replace('\\\\\\"','\\"'))
cpp = replace(cpp, '''            if (g_nr_cur_is_replay && g_nr_replay_remaining > 0)
            {
                if (--g_nr_replay_remaining == 0) g_nr_replay.store(false);
            }''','')
# Use an honest capability scope. Solving this normal path does not qualify unknown vendor configs.
cpp = cpp.replace('only x/P', 'x/P').replace('x+P+map_pts+time_cursors', 'x+P+map_pts+IMU_and_local_map_context')
for path, data in ((imu_path,imu),(cpp_path,cpp)):
    tmp = path.with_suffix(path.suffix+'.step3.tmp')
    tmp.write_text(data)
    os.chmod(tmp,path.stat().st_mode)
    tmp.replace(path)
