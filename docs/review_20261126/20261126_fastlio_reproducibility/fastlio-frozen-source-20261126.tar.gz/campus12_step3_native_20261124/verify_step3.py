"""Assemble independently read native, gate, and second-event evidence."""
from collections import Counter
import json
from pathlib import Path
import re

import rosbag


ROOT = Path(__file__).resolve().parent


def jsonl(path):
    return [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []


def verify_probe(name, expected):
    root = ROOT / name
    rows = jsonl(root / "ctl/repair_updates.jsonl")
    fates = jsonl(root / "ctl/input_fates.jsonl")
    observed = [row["scan_stamp_ns"] for row in rows]
    action = jsonl(root / "native_probe_actions.jsonl")
    relayed = jsonl(root / "relay_frames.jsonl")
    proof = {
        "scope": "isolated native experiment, no acceptance",
        "actual_native_repaired_updates": len(rows),
        "same_candidate_stamps": len(observed) == len(expected)
        and all(abs(a-b) <= 1024 for a,b in zip(observed, expected)),
        "map_update_actions": rows[-1]["map_update_count"] if rows else 0,
        "map_points_first_and_last_repaired": (rows[0]["map_points"], rows[-1]["map_points"]) if rows else None,
        "input_fates": dict(Counter(row["fate"] for row in fates)),
        "tail_relay_receipt": relayed[-1] if relayed else None,
        "commands": action,
    }
    if (root / "native_probe_result.json").exists():
        result = json.loads((root / "native_probe_result.json").read_text())
        proof["result"] = result
        resumes = [a for a in action if a.get("command") == "resume"]
        restore = [a for a in action if a.get("command") == "restore"]
        assert len(resumes) == 2 and len(restore) == 1
        e1_release = int(re.search(r"stamp_ns=(\d+)",resumes[0]["ack"]).group(1))
        e2_checkpoint = result["second_checkpoint_ns"]
        proof["new_ingested_groups_between_release_and_second_checkpoint"] = sum(
            row["fate"] == "ingested" and e1_release < row["stamp_ns"] <= e2_checkpoint
            for row in fates
        )
    bag_path = root / "frontend.bag"
    if bag_path.exists():
        with rosbag.Bag(str(bag_path)) as bag:
            stamps = [msg.header.stamp.to_nsec() for _,msg,_ in bag.read_messages(topics=["/Odometry"])]
        proof["odom_count"] = len(stamps)
        proof["last_odom_stamp_ns"] = stamps[-1] if stamps else None
    for name in ("runner_exit","probe_exit","play_exit"):
        f = root / (name+".txt")
        proof[name] = int(f.read_text()) if f.is_file() else None
    return proof


def main_evidence():
    root = ROOT / "main"
    summary = root / "run_summary.json"
    if not summary.exists():
        return None
    j = json.loads(summary.read_text())
    rows = jsonl(root/"candidates.jsonl")
    infos = jsonl(root/"icp_detail.jsonl")
    actions = j.get("native_checkpoint_actions")
    repairs = jsonl(root/"ctl/repair_updates.jsonl")
    details = j["quarantine"].get("episode_detail", [])
    evidence = {
        "scope":"frozen gate on fresh controlled primary run",
        "gate":j["gate"],
        "decisions":rows,
        "candidate_formation":infos,
        "scripted_triggers":j["scripted_triggers"],
        "native_actions":actions,
        "actual_native_repaired_updates":len(repairs),
        "lifecycle":j.get("lifecycle"),
        "terminal_reason":j.get("terminal_reason"),
        "input_health":j.get("input_health"),
        "frames":j.get("frames"),
        "episode_details":details,
        "errors":j.get("decision_errors"),
    }
    for name in ("runner_exit","driver_exit","play_exit"):
        f = root / (name+".txt")
        evidence[name] = int(f.read_text()) if f.exists() else None
    return evidence


def main():
    stage = ROOT/"../campus12_e1_ray_candidate_20261124/stage_receipt.json"
    expected = json.loads(stage.read_text())["e1_stamps_ns"]
    result = {
        "candidate_source":str(stage.parent/"repair_candidate.bag"),
        "expected_frames":len(expected),
        "probe_before_wire_fix":verify_probe("native_probe",expected),
        "probe_after_wire_fix":verify_probe("native_probe_wire_fixed",expected),
        "main":main_evidence(),
    }
    with (ROOT/"step3_verification.json").open("x") as f:
        json.dump(result,f,indent=2)
        f.write("\n")
    for k,v in result.items():
        if isinstance(v,dict):
            print(k,{a:v[a] for a in ("actual_native_repaired_updates","map_update_actions","same_candidate_stamps","gate","terminal_reason","runner_exit") if a in v})


if __name__ == "__main__":
    main()
