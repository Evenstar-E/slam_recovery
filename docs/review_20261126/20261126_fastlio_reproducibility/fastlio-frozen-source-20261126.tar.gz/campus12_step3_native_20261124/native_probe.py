"""Exercise the native replay in a disposable host, without an admission/commit claim."""
import argparse
import json
import os
from pathlib import Path
import re
import threading
import time

import rosbag
import rospy
from nav_msgs.msg import Odometry
from sensor_msgs.msg import PointCloud2


E1_BOUNDARY = 1711548075873248339
E2_BOUNDARY = 1711548094873076439
E2_DECISION = 1711548102974123478
ROS_STAMP_TOLERANCE_NS = 1024


def integer(receipt, field):
    match = re.search(r"\b" + field + r"=(-?\d+)", receipt)
    if not match:
        raise RuntimeError(f"no {field} in {receipt}")
    return int(match.group(1))


class Probe:
    def __init__(self, root):
        self.ctl = root / "ctl"
        self.root = root
        self.condition = threading.Condition()
        self.poses = []
        self.pub = rospy.Publisher("/native_recovery/repaired_scan", PointCloud2, queue_size=12)
        self.sub = rospy.Subscriber("/Odometry", Odometry, self.pose, queue_size=300)
        self.receipts = (root / "native_probe_actions.jsonl").open("x", buffering=1)

    def pose(self, msg):
        p, q = msg.pose.pose.position, msg.pose.pose.orientation
        with self.condition:
            self.poses.append((msg.header.stamp.to_nsec(),
                               [p.x, p.y, p.z, q.x, q.y, q.z, q.w]))
            self.condition.notify_all()

    def wait(self, fn, seconds, description):
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline and not rospy.is_shutdown():
            found = fn()
            if found:
                return found
            time.sleep(0.02)
        raise TimeoutError(description)

    def wait_pose(self, stamp, seconds):
        return self.wait(lambda: self.poses and self.poses[-1][0] >= stamp,
                         seconds, f"no odometry through {stamp}")

    def log(self, row):
        row["wall_time"] = time.time()
        self.receipts.write(json.dumps(row) + "\n")

    def fresh_ack(self, previous, predicate):
        path = self.ctl / "ack"
        if not path.is_file() or path.stat().st_mtime_ns <= previous:
            return None
        ack = path.read_text().strip()
        return ack if predicate(ack) else None

    def send(self, cmd, payload="", predicate=None):
        ack = self.ctl / "ack"
        previous = ack.stat().st_mtime_ns if ack.exists() else 0
        tmp = self.ctl / "cmd.probe.tmp"
        tmp.write_text(f"{cmd}\n{payload}\n")
        os.replace(tmp, self.ctl / "cmd")
        self.log({"sent":cmd, "payload":payload})
        result = self.wait(lambda: self.fresh_ack(previous, predicate or (
            lambda row: row.startswith(f"OK {cmd} "))), 8, f"no ack for {cmd}")
        self.log({"command":cmd, "payload":payload, "ack":result})
        return result

    def arm(self, boundary):
        self.wait_pose(boundary - 3 * 10**9, 460)
        for cmd in ("hold", "snapshot"):
            ack = self.send(cmd, str(boundary))
            if "deferred" not in ack.lower():
                raise RuntimeError(f"{cmd} did not arm before the boundary: {ack}")
        return boundary

    def snapshot_applied(self, boundary):
        ack = self.wait(lambda: self.fresh_ack(
            0, lambda row: row.startswith("OK snapshot applied valid=1 ")), 20,
            "scheduled checkpoint did not apply")
        stamp = integer(ack, "stamp_ns")
        if not boundary - 300_000_000 <= stamp <= boundary:
            raise RuntimeError(f"checkpoint is not from this boundary: {ack}")
        self.log({"command":"snapshot_applied", "boundary_ns":boundary, "ack":ack})
        return stamp

    def publish_candidate(self, clouds):
        self.wait(lambda: self.pub.get_num_connections() >= 1, 5, "no native repair subscriber")
        base = integer(self.send("status"), "repair_received")
        for i in range(0, len(clouds), 10):
            batch = clouds[i:i+10]
            for msg in batch:
                self.pub.publish(msg)
            target = base + i + len(batch)
            self.wait(lambda: integer(self.send("status"), "repair_received") >= target,
                      8, "host did not receive a complete repair batch")
        got = integer(self.send("status"), "repair_received")
        if got != base + len(clouds):
            raise RuntimeError(f"incorrect cumulative repair count: {got}")
        return got - base

    def run(self, candidate_path):
        with rosbag.Bag(candidate_path) as bag:
            clouds = [msg for _, msg, _ in bag.read_messages(topics=["/velodyne_points"])]
        stamps = [m.header.stamp.to_nsec() for m in clouds]
        if len(stamps) != 40 or stamps != sorted(set(stamps)):
            raise ValueError("invalid candidate population")
        self.arm(E1_BOUNDARY)
        cp1 = self.snapshot_applied(E1_BOUNDARY)
        self.wait_pose(stamps[-1] + 200_000_000, 35)
        received = self.publish_candidate(clouds)
        with self.condition:
            start = len(self.poses)
        ack = self.send("reprocess", str(stamps[-1]))
        if integer(ack, "valid") != 1 or integer(ack, "checkpoint_stamp_ns") != cp1:
            raise RuntimeError(f"wrong checkpoint: {ack}")
        fed = integer(ack, "repaired_fed")
        if fed != len(stamps):
            raise RuntimeError(f"wrong repaired population: {fed}/{len(stamps)}")

        def replay_complete():
            status = self.send("status")
            return status if integer(status, "replay_remaining") == 0 else None

        status = self.wait(replay_complete, 20, "native replay did not finish")
        consumed = integer(status, "repaired_in_update")
        mapped = integer(status, "repaired_map_updates")
        if consumed != fed or mapped != fed:
            raise RuntimeError(f"native steps missing: fed={fed} updated={consumed} mapped={mapped}")
        readback = [json.loads(line) for line in
                    (self.ctl / "repair_updates.jsonl").read_text().splitlines()]
        begun = [row["scan_stamp_ns"] for row in readback]
        if len(begun) != len(stamps) or any(abs(a-b)>ROS_STAMP_TOLERANCE_NS for a,b in zip(begun, stamps)):
            raise RuntimeError("native update identities differ from candidate timestamps")
        with self.condition:
            poses_before = list(self.poses[:start])
            poses_after = list(self.poses[start:])
        data = {"stamps_ns": stamps, "replay_updates":readback, "before":poses_before[-250:],
                "after":poses_after, "checkpoint_stamp_ns":cp1, "reprocess_ack":ack}
        (self.root / "native_candidate_poses.json").write_text(json.dumps(data, indent=2)+"\n")
        resume = self.send("resume")
        if "map_writes=released" not in resume:
            raise RuntimeError("E1 release missing")
        del clouds
        self.arm(E2_BOUNDARY)
        cp2 = self.snapshot_applied(E2_BOUNDARY)
        self.wait_pose(E2_DECISION, 35)
        restore = self.send("restore")
        if integer(restore, "valid") != 1 or integer(restore, "stamp_ns") != cp2:
            raise RuntimeError("E2 restore did not use its own checkpoint")
        release = self.send("resume")
        if "map_writes=released" not in release:
            raise RuntimeError("E2 release missing")
        self.wait_pose(1711548105373903360, 15)
        terminal = {"mode":"ISOLATED_PRE_ADMISSION_NATIVE_REPLAY",
                    "received":received, "fed":fed, "updated":consumed, "mapped":mapped,
                    "e1_release":resume, "e2_restore":restore, "e2_release":release,
                    "first_checkpoint_ns":cp1, "second_checkpoint_ns":cp2,
                    "last_odom_stamp_ns":self.poses[-1][0]}
        (self.root / "native_probe_result.json").write_text(json.dumps(terminal, indent=2)+"\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("run_root", type=Path)
    parser.add_argument("candidate_bag")
    args = parser.parse_args()
    rospy.init_node("candidate_native_probe")
    Probe(args.run_root).run(args.candidate_bag)


if __name__ == "__main__":
    main()
