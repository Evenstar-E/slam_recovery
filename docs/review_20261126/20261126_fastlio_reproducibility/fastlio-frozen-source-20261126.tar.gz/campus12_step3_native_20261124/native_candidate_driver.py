"""Integration-only adapter: the project gate judges out-of-process native replay poses."""
import bisect
import json
import os
from pathlib import Path
import re
import sys
import time

import numpy as np
import rosbag
import rospy

from slam_recovery.ros import recovery_node as recovery


STAMP_TOLERANCE_NS = 1024
FIRST_TRIGGER_NS = 1711548079776363519
BASE = recovery.NativeClosedLoop
RESULT = Path(os.environ["NATIVE_CANDIDATE_PROBE"])
CANDIDATE = Path(os.environ["REPAIR_BAG"])


def near(stamps, stamp):
    index = bisect.bisect_left(stamps, stamp)
    window = stamps[max(0, index-1):index+1]
    if not window:
        return None
    best = min(window, key=lambda key: abs(key-stamp))
    return best if abs(best-stamp) <= STAMP_TOLERANCE_NS else None


def int_field(ack, key):
    match = re.search(r"\b" + key + r"=(\d+)", ack or "")
    return int(match.group(1)) if match else None


class NativeCandidateLoop(BASE):
    def __init__(self, node, *args, **kwargs):
        super().__init__(node,*args,**kwargs)
        probe = json.loads(RESULT.read_text())
        summary = json.loads(RESULT.with_name("native_probe_result.json").read_text())
        if summary["mode"] != "ISOLATED_PRE_ADMISSION_NATIVE_REPLAY":
            raise ValueError("unexpected candidate provenance")
        self.replay_cp = probe["checkpoint_stamp_ns"]
        self.native_pose_data = {key: data for key,data in probe["after"]}
        self.pose_stamps = sorted(self.native_pose_data)
        self.before = {key: data for key,data in probe["before"]}
        self.before_stamps = sorted(self.before)
        self.replay_stamps = {a["scan_stamp_ns"]: a["end_stamp_ns"] for a in probe["replay_updates"]}
        self.scan_stamps = sorted(self.replay_stamps)
        with rosbag.Bag(str(CANDIDATE)) as bag:
            self.fixed_clouds = {msg.header.stamp.to_nsec(): msg for _,msg,_ in bag.read_messages()}
        if sorted(self.fixed_clouds) != probe["stamps_ns"] or len(self.fixed_clouds) != len(self.replay_stamps):
            raise ValueError("candidate does not cover the native update population")
        self.staged = {}
        self.native_evidence = []
        self.original_scans = {}
        old_eval = node.evaluate_and_commit_candidate

        def evaluate(candidate_id, repaired_poses, **kwargs):
            if not self.staged:
                return old_eval(candidate_id,repaired_poses,**kwargs)
            self.original_scans = {k:node.scan_buffer_body[k] for k in self.staged}
            try:
                for k, cloud in self.staged.items():
                    node.scan_buffer_body[k] = recovery.subsample(recovery.cloud_to_xyz(cloud),self.scan_cap)
                verdict = old_eval(candidate_id,repaired_poses,**kwargs)
            except BaseException:
                node.scan_buffer_body.update(self.original_scans)
                raise
            if not verdict.accepted:
                node.scan_buffer_body.update(self.original_scans)
            return verdict

        node.evaluate_and_commit_candidate = evaluate

    def _icp_candidate(self, ep, incumbent_poses=None):
        self.staged = {}
        if ep.candidate_id != "cand_0000":
            return super()._icp_candidate(ep, incumbent_poses)
        frames = []
        for k, t, _ in ep.frames:
            rec = self._scan_index.get(k)
            s = None if rec is None else near(self.scan_stamps,rec[0])
            if s is None:
                continue
            actual = near(self.pose_stamps,self.replay_stamps[s])
            raw = near(sorted(self.fixed_clouds),s)
            if actual is not None and raw is not None:
                frames.append((k,t,actual,raw))
        # Align only by the common pre-event checkpoint pose, independent of the repaired data.
        shadow_anchor_stamp = near(self.before_stamps,self.replay_cp)
        trusted_key = next((k for k,t in self.node._kf_timestamps.items()
                            if k in self.node.tx_mgr.trusted_poses
                            and abs(t-self.replay_cp) <= STAMP_TOLERANCE_NS), None)
        if shadow_anchor_stamp is None or trusted_key is None or len(frames) != len(self.fixed_clouds):
            return {}, {"mode":"native_replayed_measurements","candidate_suppressed":True,
                        "reason":"full stamped population or trusted alignment anchor missing",
                        "matching_frames":len(frames), "expected_frames":len(self.fixed_clouds),
                        "shadow_anchor":shadow_anchor_stamp, "current_anchor":trusted_key}
        q = self.before[shadow_anchor_stamp]
        alignment = self.node.tx_mgr.trusted_poses[trusted_key] @ np.linalg.inv(recovery.pose_to_matrix(q[:3],q[3:]))
        poses = {}
        for k,_t,actual,raw in frames:
            self.staged[k] = self.fixed_clouds[raw]
            q = self.native_pose_data[actual]
            poses[k] = alignment @ recovery.pose_to_matrix(q[:3],q[3:])
        return poses, {"mode":"native_replayed_measurements","frames_candidate":len(poses),
                       "checkpoint_stamp_ns":self.replay_cp,
                       "anchor_transform":alignment.tolist(),
                       "holdout_measurement_view":"same corrected returns for both pose alternatives"}

    def _repair_gate(self, ep, accepted):
        # The experiment only supplied E1 replacement measurements. E2 can use the normal
        # pose/host gate, with no synthetic measurement correction.
        if ep.candidate_id != "cand_0000":
            return True, None
        if not accepted:
            return True, None
        committed = set(self.records[-1]["committed_pose_keys"])
        if committed != set(self.staged):
            self._operational_error(ep, "POLICY_ACCEPTED_SUBSET_NOT_FULL_MEASUREMENT_POPULATION")
            return False, None
        baseline = self.cp.read_repair_received(timeout_s=2)
        if baseline is None:
            self._operational_error(ep,"REPAIR_RECEIPT_BASELINE_MISSING")
            return False, None
        messages = sorted(self.staged.values(), key=lambda m: m.header.stamp.to_nsec())
        sent = []
        for i in range(0,len(messages),10):
            for msg in messages[i:i+10]:
                self.publish_repair(msg)
                sent.append(msg.header.stamp.to_nsec())
            if not self.cp.wait_for_repair_count(baseline+len(sent),timeout_s=5):
                self._operational_error(ep,"REPAIR_BATCH_NOT_RECEIVED")
                return False,None
        return True, {"published":len(sent),"synced":True,"frames":sent,
                      "source":"fixed_verified_Campus12_E1_measurements"}

    def _operational_error(self, ep, reason):
        self.native_evidence.append({"candidate_id":ep.candidate_id,"failure":reason})
        # Fail the engineering run if a logical decision cannot be executed accurately.
        rospy.signal_shutdown(reason)

    def _read_update_receipt(self, ep, ack_text):
        fed = int_field(ack_text,"repaired_fed")
        cp_stamp = int_field(ack_text,"checkpoint_stamp_ns")
        if ep.candidate_id == "cand_0000" and (fed != len(self.fixed_clouds) or cp_stamp != self.replay_cp):
            self._operational_error(ep,"NATIVE_REPLAY_CHECKPOINT_OR_POPULATION_MISMATCH")
            raise RuntimeError("native replay was not correctly sourced")
        until = time.monotonic()+20
        while time.monotonic()<until:
            event = self.cp._send("status")
            deadline = time.monotonic()+2
            while not event.get("ack") and time.monotonic()<deadline:
                self.cp.poll()
                time.sleep(0.02)
            ack = event.get("ack")
            remaining = int_field(ack,"replay_remaining")
            if remaining == 0:
                consumed = int_field(ack,"repaired_in_update")
                mapped = int_field(ack,"repaired_map_updates")
                evidence = {"candidate_id":ep.candidate_id,"command_ack":ack_text,"completion_ack":ack}
                self.native_evidence.append(evidence)
                if ep.candidate_id == "cand_0000" and (consumed != fed or mapped != fed):
                    self._operational_error(ep,"NATIVE_UPDATE_OR_MAP_COUNT_MISMATCH")
                    raise RuntimeError("incomplete actual repaired updates")
                return consumed
            time.sleep(0.06)
        self._operational_error(ep,"NATIVE_REPLAY_COMPLETION_TIMEOUT")
        raise TimeoutError("native replay didn't drain")

    def decide(self, now_ts_ns, basis):
        out = super().decide(now_ts_ns,basis)
        if out and out["candidate_id"] == "cand_0000":
            out["candidate_source"] = "native_replayed_measurements"
            self.fixed_clouds.clear()
            self.staged.clear()
            self.original_scans.clear()
        if self.native_evidence:
            root = Path(os.environ["NATIVE_MAIN_RUN_ROOT"])
            (root/"native_engineering_actions.json").write_text(json.dumps(self.native_evidence,indent=2)+"\n")
        return out


if __name__ == "__main__":
    recovery.NativeClosedLoop = NativeCandidateLoop
    sys.exit(recovery.main())
