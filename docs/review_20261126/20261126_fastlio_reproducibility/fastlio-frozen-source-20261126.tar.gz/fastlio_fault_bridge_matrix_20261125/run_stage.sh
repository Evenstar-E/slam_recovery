#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "$0")"
stage="$1"
kinds=(z_shift rigid_ramp occlusion attenuation narrow_fov sync)
if [ "$stage" = single ]; then
  for i in $(seq 1 30); do test -f clean/finished_at.txt && break; sleep 2; done
  test "$(cat clean/replay_exit.txt)" = 0
  test -f clean/finished_at.txt
  duration=45
else
  test "$stage" = dual
  test -s SINGLE_COMPLETE.json
  duration=64
fi
for kind in "${kinds[@]}"; do
  faults=("$kind")
  if [ "$stage" = dual ]; then faults+=("$kind"); fi
  if bash run_case.sh "${stage}_$kind" "$duration" "${faults[@]}"; then code=0; else code=$?; fi
  printf '%s %s %s\n' "$stage" "$kind" "$code" | tee -a "${stage}_statuses.txt"
done
