"""Publish the historical fault profiles and capture exactly the stream offered to FAST-LIO."""
import argparse
from array import array
import hashlib
import json
from pathlib import Path
import time

import cv2
import numpy as np
import rosbag
import rospy
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu, PointCloud2
from slam_recovery.experiments.injection.injectors import (
    LiDARInjectionParams, inject_lidar_attenuation_and_dropout,
    inject_plastic_bag_near_field_occlusion, inject_timestamp_offset,
)

ROOT = Path(__file__).resolve().parent
INPUT = ROOT.parent / "ntuviral_fastlio_step5_20261125" / "eee_03"
NS = 1_000_000_000
KINDS = ("z_shift", "rigid_ramp", "occlusion", "attenuation", "narrow_fov", "sync")


def time_to_ros(ns):
    return rospy.Time(int(ns//NS), int(ns%NS))


def vector(obj, keys="xyz"):
    return [getattr(obj, k) for k in keys]


def records(msg):
    if msg.is_bigendian:
        raise ValueError("The fixed NTU input is little-endian")
    raw = np.ndarray((msg.height, msg.width, msg.point_step), dtype=np.uint8, buffer=msg.data,
                     strides=(msg.row_step,msg.point_step,1)).reshape((-1,msg.point_step))
    fields = {f.name: f.offset for f in msg.fields}
    layout = np.dtype({"names": ["x","y","z","intensity","t","range"],
                       "formats": ["<f4","<f4","<f4","<f4","<u4","<u4"],
                       "offsets": [fields[k] for k in ("x","y","z","intensity","t","range")],
                       "itemsize": msg.point_step})
    return raw, layout


def as_xyzi(rows):
    return np.column_stack([rows[k] for k in ("x","y","z","intensity")])


def mutate(msg, kind, event, frame_index):
    start = msg.header.stamp.to_nsec()
    if kind == "none":
        return msg
    if kind == "sync":
        ns = inject_timestamp_offset(np.array([start]),50.,event["onset_ns"],event["end_ns"]-1)[0]
        msg.header.stamp = time_to_ros(ns)
        return msg
    raw, layout = records(msg)
    expected = raw.copy()
    rows = expected.view(layout).reshape(-1)
    xyz = as_xyzi(rows)
    finite = np.isfinite(xyz).all(axis=1)
    valid_ids = np.flatnonzero(finite & (rows["range"]>0))
    xyz_valid = xyz[valid_ids]
    seed = 42000+frame_index
    if kind == "z_shift":
        rows["z"][np.isfinite(rows["z"])] += .5
    elif kind == "rigid_ramp":
        onset, end = event["onset_ns"], event["end_ns"]
        u = np.clip((start-onset-2*NS)/(end-onset-2*NS),0.,1.)
        scale = .5*(1.+np.cos(np.pi*u))
        rotation = cv2.Rodrigues(np.deg2rad(20.)*scale*np.array([1.,1.,2.])/np.sqrt(6.))[0]
        with np.errstate(invalid="ignore"):
            changed = xyz[:,:3]@rotation.T + np.array([0.,0.,1.5*scale])
        for axis, k in enumerate("xyz"):
            rows[k] = changed[:,axis]
    elif kind == "narrow_fov":
        azimuth = np.arctan2(rows["y"],rows["x"])
        expected = expected[finite & (azimuth > (-np.pi+2*np.pi*.88))].copy()
    else:
        if kind == "occlusion":
            changed, mask = inject_plastic_bag_near_field_occlusion(
                xyz_valid,.88,4.30,.01,seed)
            out_ids = valid_ids[mask]
            changed = changed[mask]
        elif kind == "attenuation":
            changed, kept = inject_lidar_attenuation_and_dropout(
                xyz_valid,LiDARInjectionParams(.05,.12,.95,seed))
            expected = expected[valid_ids[kept]].copy()
            rows = expected.view(layout).reshape(-1)
            out_ids = np.arange(len(rows))
        else:
            raise ValueError(kind)
        for axis, k in enumerate(("x","y","z","intensity")):
            rows[k][out_ids] = changed[:,axis]
        rows["range"][out_ids] = np.clip(np.rint(np.linalg.norm(changed[:,:3],axis=1)*1000),
                                         0,np.iinfo(np.uint32).max).astype(np.uint32)
    if len(expected) != msg.height*msg.width:
        msg.height, msg.width = 1, len(expected)
        msg.row_step = msg.point_step*msg.width
    elif msg.row_step != msg.point_step*msg.width:
        raise ValueError("Unexpected padding in fixed NTU point cloud")
    msg.data = expected.tobytes()
    return msg


def capture(msg):
    raw, layout = records(msg)
    rows = raw.view(layout).reshape(-1)
    xyz = np.column_stack([rows[k] for k in "xyz"])
    good = np.flatnonzero(np.isfinite(xyz).all(axis=1) & (rows["range"]>4000))
    all_offsets = rows["t"]
    pending = all_offsets[all_offsets<150_000_000]
    end = int(all_offsets[good].max()) if len(good) else (int(pending.max()) if len(pending) else 0)
    assert 0 <= end < 150_000_000
    ix = good[np.linspace(0,len(good)-1,min(len(good),6000),dtype=np.int64)] if len(good) else good
    return xyz[ix], all_offsets[ix].astype(np.int32), end


def main():
    p=argparse.ArgumentParser()
    p.add_argument("out",type=Path)
    p.add_argument("--faults",nargs="*",choices=KINDS,default=[])
    p.add_argument("--duration",type=int,required=True)
    p.add_argument("--speed",type=float,default=1.25)
    a=p.parse_args()
    out=a.out
    pop=json.loads((INPUT/"population.json").read_text())
    origin=int(pop["start_ns"])
    windows=[e for e in json.loads((INPUT/"events.json").read_text()) if e["inject_z_m"]][:len(a.faults)]
    rospy.init_node("fault_matrix_replay",disable_signals=True)
    odom_file=(out/"native_odom.jsonl").open("x",buffering=1)
    pub=rospy.Publisher("/velodyne_points",PointCloud2,queue_size=64,tcp_nodelay=True)
    pub_imu=rospy.Publisher("/imu_raw",Imu,queue_size=1024,tcp_nodelay=True)
    def on_odom(msg):
        pose=msg.pose.pose
        row=dict(stamp=msg.header.stamp.to_nsec(),p=vector(pose.position),q=vector(pose.orientation,"xyzw"))
        odom_file.write(json.dumps(row,allow_nan=True)+"\n")
    sub=rospy.Subscriber("/Odometry",Odometry,on_odom,queue_size=1000,tcp_nodelay=True)
    deadline=time.monotonic()+12
    while pub.get_num_connections()<1 or pub_imu.get_num_connections()<1:
        if time.monotonic()>deadline:
            raise RuntimeError("FAST-LIO publisher connections unavailable")
        time.sleep(.1)
    points, offsets, boundaries, scans, fed, scan_end = [], [], [0], [], [], []
    imu, gyro, accel = [], [], []
    fault_frames=[0]*len(windows)
    start=origin+27*NS
    finish=origin+a.duration*NS
    stamp0=None
    not_before=time.monotonic()
    with rosbag.Bag(str(INPUT/"study.bag")) as bag, (out/"replay_frames.jsonl").open("x",buffering=1) as audit:
        for topic, msg, time_recorded in bag.read_messages(
                topics=["/velodyne_points","/imu_raw"],start_time=time_to_ros(start-NS),end_time=time_to_ros(finish+NS)):
            t=msg.header.stamp.to_nsec()
            if not (start <= t < finish):
                continue
            export_time=time_recorded.to_nsec()
            if stamp0 is None:
                stamp0=export_time
            wait=not_before+(export_time-stamp0)/(a.speed*NS)-time.monotonic()
            if wait>0:
                time.sleep(wait)
            if topic=="/imu_raw":
                pub_imu.publish(msg)
                imu.append(t); gyro.append(vector(msg.angular_velocity)); accel.append(vector(msg.linear_acceleration))
                continue
            original_size=msg.height*msg.width
            before=bytes(msg.data)
            event_index=next((i for i,e in enumerate(windows) if e["onset_ns"]<=t<e["end_ns"]),None)
            kind=a.faults[event_index] if event_index is not None else "none"
            if event_index is not None:
                fault_frames[event_index]+=1
                msg=mutate(msg,kind,windows[event_index],fault_frames[event_index])
            actual=msg.header.stamp.to_nsec()
            pub.publish(msg)
            size=msg.height*msg.width
            if origin+31*NS<=t<finish-NS:
                xyz, toff, end=capture(msg)
                points.append(xyz); offsets.append(toff); boundaries.append(boundaries[-1]+len(xyz))
                scans.append(t); fed.append(actual); scan_end.append(end)
            audit.write(json.dumps(dict(original_ns=t,fed_ns=actual,event=event_index+1 if event_index is not None else None,
                kind=kind,original_points=original_size,points=size,changed_payload=msg.data!=before,
                fed_data_sha256=hashlib.sha256(msg.data).hexdigest()))+"\n")
    time.sleep(2)
    sub.unregister()
    odom_file.close()
    np.savez_compressed(out/"measurements.npz", xyz=np.concatenate(points), offset=np.concatenate(offsets),
        boundaries=boundaries, scans=scans, fed=fed, scan_end=scan_end, imu=imu, gyro=gyro, accel=accel)
    assert fault_frames==[e["frames"] for e in windows],(fault_frames,windows)
    (out/"replayed.json").write_text(json.dumps(dict(origin=origin, fault_frames=fault_frames, faults=a.faults,
        windows=windows, scans=len(scans), imu=len(imu), speed=a.speed, duration=a.duration),indent=2)+"\n")


if __name__=="__main__":
    cv2.setNumThreads(1)
    main()
