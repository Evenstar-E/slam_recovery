"""Measure inherited bridge displacement relative to the common, un-injected reference."""
import json
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent
NS=1_000_000_000
MOMENTS=(("after_E1",40),("before_E2",53),("after_E2",59))


def load_case(case):
    replay=json.loads((case/"replayed.json").read_text())
    with np.load(case/"measurements.npz") as a, np.load(case/"trajectories.npz") as b:
        return int(replay["origin"]),a["scans"].copy(),b["poses"][:,1].copy(),b["physical_ns"].copy()


def main():
    origin,t,p,time=load_case(ROOT/"clean")
    results={}
    for case in sorted(ROOT.glob("dual_*")):
        if not case.is_dir() or not (case/"trajectories.npz").is_file():
            continue
        new_origin,new_t,new_p,new_time=load_case(case)
        assert new_origin==origin and np.array_equal(t,new_t)
        assert np.array_equal(p[t<origin+34*NS],new_p[t<origin+34*NS])
        out={}
        for label,window in MOMENTS:
            i=int(np.searchsorted(t,origin+window*NS))
            if label=="before_E2":
                i-=1
            assert time[i]==new_time[i], (case.name,label)
            error=(new_p[i]-p[i])
            out[label]={"scan_elapsed_s":(int(t[i])-origin)/NS,"position_difference_m":float(np.linalg.norm(error)),
                        "vector_difference_m":error.tolist()}
        results[case.name]=out
    (ROOT/"CARRYOVER.json").write_text(json.dumps(results,indent=2,allow_nan=False)+"\n")
    for case, result in results.items():
        print(case, *(round(result[label]["position_difference_m"],3) for label,_ in MOMENTS))


if __name__=="__main__":
    main()
