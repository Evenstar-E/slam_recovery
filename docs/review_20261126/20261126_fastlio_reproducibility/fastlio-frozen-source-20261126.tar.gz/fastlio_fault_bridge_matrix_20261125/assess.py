"""Compare the host and the previously developed short-window LiDAR–IMU estimate."""
from collections import Counter
import json
from pathlib import Path
import sys
import time

import cv2
import numpy as np
from rigid_bridge import MIN_CORRESPONDENCES, cloud_geometry, fit_edge
from run_bridge_event1 import interp_matrix, PAST, NS
from score import pairs_in, stats, PRISM_IN_BODY, read_gt, REF

ROOT = Path(__file__).resolve().parent


def load_rows(path):
    return list(map(json.loads,path.open()))


def pose_data(data, origin, fed_ends, starts):
    t = data["imu"]
    a = data["accel"]
    g = data["gyro"].copy()
    quiet=(t>=origin+29*NS)&(t<origin+31*NS)
    assert quiet.sum()>100
    past = load_rows(PAST)
    prefix = [r for r in past if starts[0]-500_000_000 <= r["scan_stamp_ns"] <= starts[0]]
    xyz = np.array([np.array(r["T_wb"]).reshape(4,4)[:3,3] for r in prefix])
    times = (np.array([r["scan_stamp_ns"] for r in prefix], dtype=np.int64)-starts[0])*1e-9
    assert prefix[-1]["scan_stamp_ns"]==starts[0]
    v0 = np.linalg.lstsq(np.column_stack((np.ones(len(times)),times)),xyz,rcond=None)[0][1]
    anchor = np.asarray(prefix[-1]["T_wb"]).reshape(4,4)
    g -= g[quiet].mean(axis=0)
    relative = [np.eye(3)]
    for i, dt in enumerate(np.diff(t)*1e-9):
        relative.append(relative[-1] @ cv2.Rodrigues(.5*(g[i]+g[i+1])*dt)[0])
    relative = np.asarray(relative)
    u, _, vt=np.linalg.svd(interp_matrix(np.array([fed_ends[0]]),t,relative)[0])
    orientations=anchor[:3,:3]@(u@vt).T@relative
    u, _, vt=np.linalg.svd(interp_matrix(fed_ends,t,orientations))
    rotations=u@vt
    a_world = np.einsum("nij,nj->ni",orientations,a)
    a_world -= a_world[quiet].mean(axis=0)
    a_scans=np.stack([np.interp((fed_ends-t[0])*1e-9,(t-t[0])*1e-9,a_world[:,i])
                      for i in range(3)],axis=-1)
    clouds=[]
    for i, t0 in enumerate(data["fed"]):
        sl=slice(data["boundaries"][i],data["boundaries"][i+1])
        p=data["xyz"][sl]
        if len(p):
            ori=interp_matrix(t0+data["offset"][sl].astype(np.int64),t,orientations)
            p=np.einsum("nij,nj->ni",ori,p)@rotations[i]
        clouds.append(p)
    return anchor[:3,3],v0,rotations,a_scans,clouds


def chain(clouds, stamps, rot, accel, p0, v0, extr_t):
    p = np.stack((p0,p0))
    v = np.stack((v0,v0))
    pos = [p.copy()]
    support = np.zeros(len(stamps),dtype=bool)
    evidence=[]
    for i in range(1,len(stamps)):
        previous,current=clouds[i-1],clouds[i]
        dt=(stamps[i]-stamps[i-1])*1e-9
        assert dt>0
        cv2.setRNGSeed(31+i)
        a=(accel[i]+accel[i-1])*.5
        d=v*dt+.5*a*dt*dt
        lever=(rot[i]-rot[i-1])@extr_t
        v+=a*dt
        item=dict(n_previous=len(previous),n_current=len(current),available=False)
        if min(len(current),len(previous))>=max(20,MIN_CORRESPONDENCES):
            r_prev=rot[i-1]
            _, fit=fit_edge(previous,current,cloud_geometry(previous),r_prev.T@rot[i],
                            r_prev.T@(d[1]+lever))
            item.update(supported=fit.supported,total=fit.total,available=bool(fit.available),
                        heldout_rms=fit.holdout_rms if np.isfinite(fit.holdout_rms) else None)
            if fit.available:
                d[1]=r_prev@fit.pose_translation-lever
                v[1]=.8*v[1]+.2*(d[1]/dt+.5*a*dt)
                support[i]=True
        p+=d+lever
        pos.append(p.copy())
        evidence.append(item)
    positions=np.asarray(pos)
    return positions+((rot@(PRISM_IN_BODY-extr_t))[:,None,:]),support,evidence


def host_data(out, stems):
    fates=load_rows(out/"ctl"/"input_fates.jsonl")
    replay=load_rows(out/"replay_frames.jsonl")
    ids=np.asarray([r["fed_ns"] for r in replay],dtype=np.int64)
    assert np.all(np.diff(ids)>0)
    raw_odom=load_rows(out/"native_odom.jsonl")
    by_stamp={int(r["stamp"]):r for r in raw_odom}
    odom_stamps=np.array(sorted(by_stamp),dtype=np.int64)
    assert len(odom_stamps)>0
    matched={}
    duplicates=0
    dtype_grouper=Counter()
    for row in fates:
        beg=round(row["beg_s"]*NS)
        i=int(np.searchsorted(ids,beg))
        candidates=[j for j in (i-1,i) if 0<=j<len(ids)]
        i=min(candidates,key=lambda j:abs(int(ids[j])-beg))
        if abs(int(ids[i])-beg)>2500:
            continue
        orig=replay[i]["original_ns"]
        if orig in matched:
            duplicates+=1
        matched[orig]=row
        dtype_grouper[row["fate"]]+=1
    sequence=[]
    for stamp in stems:
        fate=matched.get(int(stamp))
        odom=None
        if fate:
            target=fate["stamp_ns"]
            j=int(np.searchsorted(odom_stamps,target))
            candidates=[k for k in (j-1,j) if 0<=k<len(odom_stamps)]
            ix=min(candidates,key=lambda k:abs(int(odom_stamps[k])-target))
            if abs(int(odom_stamps[ix])-target)<=2500:
                odom=by_stamp[int(odom_stamps[ix])]
        if odom is None or not np.isfinite(odom["p"]).all() or not np.isfinite(odom["q"]).all():
            sequence.append([np.nan]*3)
        else:
            q=np.asarray(odom["q"],dtype=float)
            q/=np.linalg.norm(q)
            xyz,w=q[:3],q[3]
            lever=PRISM_IN_BODY+2*np.cross(xyz,w*PRISM_IN_BODY+np.cross(xyz,PRISM_IN_BODY))
            sequence.append(odom["p"]+lever)
    cases={}
    for k in sorted({x["event"] for x in replay if x["event"] is not None}):
        entries=[x for x in replay if x["event"]==k]
        base={r["original_ns"]:r for r in load_rows(ROOT/"clean"/"replay_frames.jsonl")}
        confirmed=[x for x in entries if x["original_ns"] in matched]
        payload=sum(x["fed_data_sha256"]!=base[x["original_ns"]]["fed_data_sha256"] for x in entries)
        changed=sum(x["fed_ns"]!=x["original_ns"] for x in entries)
        assert payload+changed==len(entries), (k,payload,changed,len(entries))
        cases[str(k)]=dict(published=len(entries),consumed=len(confirmed),
            payload_different=payload, timestamp_different=changed,
            reported_fates=dict(Counter(matched[x["original_ns"]]["fate"] for x in confirmed)),
            min_points=min(x["points"] for x in entries),max_points=max(x["points"] for x in entries))
    clean={r["original_ns"]:r for r in load_rows(ROOT/"clean"/"replay_frames.jsonl")}
    healthy=[x for x in replay if x["event"] is None]
    assert all(x["fed_ns"]==x["original_ns"] and
               x["fed_data_sha256"]==clean[x["original_ns"]]["fed_data_sha256"] for x in healthy)
    return np.asarray(sequence),dict(fates=len(fates),matched=len(matched),duplicates=duplicates,
        unique_odoms=len(by_stamp),odom_duplicates=len(raw_odom)-len(by_stamp),unmatched=len(fates)-sum(dtype_grouper.values()),
        fate_categories=dict(dtype_grouper),healthy_payload_exact=len(healthy),events=cases)


def metrics(physical, poses, support, origin):
    reference_times, coords=read_gt(REF/"incoming"/"eee_03_gt.csv")
    actual=np.asarray([t for t in reference_times if physical[0]<=t<=physical[-1]],dtype=np.int64)
    truth=np.asarray([coords[int(t)] for t in actual])
    hi=np.searchsorted(physical,actual)
    lo=np.where(physical[hi]==actual,hi,hi-1)
    span=physical[hi]-physical[lo]
    f=np.divide(actual-physical[lo],span,out=np.zeros(len(actual)),where=span>0)
    pred=poses[lo]+f[:,None,None]*(poses[hi]-poses[lo])
    native_valid=np.isfinite(pred[:,2]).all(axis=1)
    masks={"whole":np.ones(len(physical),dtype=bool),
           "pre":physical<origin+34*NS,
           "E1":(physical>=origin+34*NS)&(physical<origin+40*NS),
           "between":(physical>=origin+40*NS)&(physical<origin+53*NS),
           "E2":(physical>=origin+53*NS)&(physical<origin+59*NS),
           "tail":physical>=origin+59*NS}
    output={}
    for name, mask in masks.items():
        base=mask[lo]&mask[hi]&(span<=150_000_000)
        pairs=pairs_in(base, np.ones(len(actual),dtype=bool), actual)
        pairs_common=pairs[native_valid[pairs].all(axis=1)]
        row=dict(frames=int(np.count_nonzero(mask)), usable_edges=int(np.count_nonzero(mask&support)),
                 native_pose_frames=int(np.count_nonzero(mask&np.isfinite(poses[:,2]).all(axis=1))),
                 pairs_all=len(pairs),pairs_common=len(pairs_common),matched_rmse_m={},all_pair_bridge_rmse_m={})
        for set_pairs, slot, types in (
            (pairs_common,"matched_rmse_m",("imu_only","lidar_imu","native")),
            (pairs,"all_pair_bridge_rmse_m",("imu_only","lidar_imu"))):
            i,j=set_pairs.T
            for k, typ in enumerate(types):
                e=np.abs(np.linalg.norm(pred[j,k]-pred[i,k],axis=1)-np.linalg.norm(truth[j]-truth[i],axis=1))
                row[slot][typ]=stats(e)
        output[name]=row
    recovery={}
    for k,(on,off) in enumerate(((34,40),(53,59)),1):
        i=int(np.searchsorted(physical,origin+on*NS))-1
        j=int(np.searchsorted(physical,origin+off*NS))
        if i<0 or j>=len(physical):
            continue
        jj=np.searchsorted(actual,physical[[i,j]])
        if np.any(jj>=len(truth)):
            continue
        length=np.linalg.norm(poses[j]-poses[i],axis=1)
        recovery[f"E{k}"]=dict(approximate_prism_m=float(np.linalg.norm(truth[jj[1]]-truth[jj[0]])),
            estimated_m=[float(x) if np.isfinite(x) else None for x in length],
            endpoints_elapsed_s=((physical[[i,j]]-origin)/NS).tolist())
    return output,recovery


def main(out):
    cv2.setNumThreads(1)
    receipt=json.loads((out/"replayed.json").read_text())
    origin=receipt["origin"]
    with np.load(out/"measurements.npz") as npz:
        data={k:npz[k] for k in npz.files}
    starts=data["scans"]
    native,info=host_data(out,starts)
    physical=starts+data["scan_end"]
    ends=data["fed"]+data["scan_end"]
    assert np.all(np.diff(physical)>0) and np.all(np.diff(ends)>0) and np.all(np.diff(data["imu"])>0)
    p0,v0,rot,accel,clouds=pose_data(data,origin,ends,starts)
    start=time.monotonic()
    poses,available,evidence=chain(clouds,ends,rot,accel,p0,v0,np.array([-.05,0.,.055]))
    seconds=time.monotonic()-start
    all_poses=np.concatenate((poses,native[:,None,:]),axis=1)
    phases,recoveries=metrics(physical,all_poses,available,origin)
    with (out/"score.json").open("x") as f:
        json.dump(dict(**receipt,host=info,phases=phases,recoveries=recoveries,
                      estimate_runtime_s=seconds),f,indent=2,allow_nan=False)
        f.write("\n")
    np.savez_compressed(out/"trajectories.npz",physical_ns=physical,fed_ns=ends,poses=all_poses,
                        lidar_available=available)
    with (out/"edge_evidence.json").open("x") as f:
        json.dump(evidence,f,separators=(",",":"),allow_nan=False)
        f.write("\n")


if __name__=="__main__":
    main(Path(sys.argv[1]).resolve())
