"""Select the event population by the original scan identity and publish stage evidence."""
import csv
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from assess import load_rows, stats, pairs_in, read_gt, REF, NS
from ground_truth_eval import interp

ROOT=Path(__file__).resolve().parent
KINDS=("z_shift","rigid_ramp","occlusion","attenuation","narrow_fov","sync")


def score_phase(result, scans, physical, poses, support, lower, upper, gt_t, gt_pos):
    actual=np.asarray([t for t in gt_t if physical[0]<=t<=physical[-1]],dtype=np.int64)
    truth=np.asarray([gt_pos[int(t)] for t in actual])
    hi=np.searchsorted(physical,actual)
    lo=np.where(physical[hi]==actual,hi,hi-1)
    span=physical[hi]-physical[lo]
    f=np.divide(actual-physical[lo],span,out=np.zeros(len(actual)),where=span>0)
    pred=poses[lo]+f[:,None,None]*(poses[hi]-poses[lo])
    native_valid=np.isfinite(pred[:,2]).all(axis=1)
    member=(scans>=lower)&(scans<upper)
    ids=pairs_in(member[lo]&member[hi]&(span<=150_000_000),np.ones(len(actual),dtype=bool),actual)
    common=ids[native_valid[ids].all(axis=1)]
    for k, name in enumerate(("imu_only","lidar_imu","native")):
        i,j=common.T
        err=np.abs(np.linalg.norm(pred[j,k]-pred[i,k],axis=1)-np.linalg.norm(truth[j]-truth[i],axis=1))
        result[name]=stats(err)
    i,j=ids.T
    bridge_error=np.abs(np.linalg.norm(pred[j,:2]-pred[i,:2],axis=2)-np.linalg.norm(truth[j]-truth[i],axis=1)[:,None])
    result.update(eligible_pairs=len(ids), common_pairs=len(common), scans=int(member.sum()),
                  supported=int(np.count_nonzero(member&support)),
                  native_scans=int(np.count_nonzero(member&np.isfinite(poses[:,2]).all(axis=1))),
                  all_pair_bridge_rmse_m=stats(bridge_error[:,1]), all_pair_imu_rmse_m=stats(bridge_error[:,0]))
    before=int(np.searchsorted(scans,lower))-1
    after=int(np.searchsorted(scans,upper))
    if before>=0 and after<len(scans):
        a=interp(gt_t,gt_pos,int(physical[before]))
        b=interp(gt_t,gt_pos,int(physical[after]))
        lengths=np.linalg.norm(poses[after]-poses[before],axis=1)
        result["from_before_to_first_healthy_m"]=dict(
            reference=float(np.linalg.norm(b-a)) if a is not None and b is not None else None,
            imu_only=float(lengths[0]),lidar_imu=float(lengths[1]),
            native=float(lengths[2]) if np.isfinite(lengths[2]) else None)
    return result


def main(stage):
    assert stage in ("single","dual")
    gt_t,gt_pos=read_gt(REF/"incoming"/"eee_03_gt.csv")
    plan=[(k,ROOT/f"{stage}_{k}") for k in KINDS]
    if stage=="single":
        plan.insert(0,("clean",ROOT/"clean"))
    doc={}
    flat=[]
    for name, out in plan:
        assert (out/"finished_at.txt").exists()
        recv=int((out/"replay_exit.txt").read_text())
        eval_code=int((out/"score_exit.txt").read_text())
        d=doc[name]=dict(replay_exit=recv,score_exit=eval_code)
        if recv!=0 or eval_code!=0:
            continue
        source=out/"score.json"
        obj=json.loads(source.read_text())
        d.update(score_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),host=obj["host"],
                 estimate_runtime_s=obj["estimate_runtime_s"])
        d["events"]={}
        with np.load(out/"trajectories.npz") as poses_file:
            trajectory={key:poses_file[key] for key in poses_file.files}
        with np.load(out/"measurements.npz") as scans_file:
            physical_starts=scans_file["scans"].copy()
        for k,(on,off) in enumerate(((34,40),(53,59)),1):
            if k==2 and stage=="single" and name!="clean":
                continue
            record=score_phase({},physical_starts,trajectory["physical_ns"],trajectory["poses"],
                trajectory["lidar_available"],obj["origin"]+on*NS,obj["origin"]+off*NS,gt_t,gt_pos)
            d["events"][str(k)]=record
            injected=d["host"]["events"].get(str(k),{})
            if injected:
                assert record["scans"]==injected["published"]
            flat.append(dict(profile=name,event=k,scans=record["scans"],injected=injected.get("published",0),
                native_consumed=injected.get("consumed",0),bridge_support=record["supported"],
                common_pairs=record["common_pairs"],imu=record["imu_only"].get("rmse"),
                bridge=record["lidar_imu"].get("rmse"),native=record["native"].get("rmse")))
    basename=stage.upper()
    with (ROOT/f"{basename}_COMPLETE.json").open("x") as f:
        json.dump(doc,f,indent=2,allow_nan=False); f.write("\n")
    with (ROOT/f"{basename}_SUMMARY.csv").open("x") as f:
        writer=csv.DictWriter(f,fieldnames=list(flat[0]))
        writer.writeheader()
        writer.writerows(flat)
    for row in flat:
        print(row)


if __name__=="__main__":
    main(sys.argv[1])
