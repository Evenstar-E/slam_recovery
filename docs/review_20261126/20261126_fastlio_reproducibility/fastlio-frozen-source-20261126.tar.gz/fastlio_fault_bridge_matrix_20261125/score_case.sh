#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "$0")"
source /opt/ros/noetic/setup.bash
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
export PYTHONPATH="$PWD/../rigid_ramp_bridge_20261125:$PWD/../short_window_bridge_20261125:/home/tong/src/slam_recovery:$PYTHONPATH"
test "$(cat "$1/replay_exit.txt")" = 0
test -f "$1/finished_at.txt"
timeout --kill-after=5s 220s /usr/bin/python3 -u assess.py "$1"
