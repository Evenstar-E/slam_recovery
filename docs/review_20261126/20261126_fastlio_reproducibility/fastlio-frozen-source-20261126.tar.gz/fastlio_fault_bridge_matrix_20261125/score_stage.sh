#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "$0")"
stage="$1"
jobs=()
run_score() {
  local name="$1" p
  for p in $(seq 1 300); do test -f "$name/finished_at.txt" && break; sleep 1; done
  local code=0
  bash score_case.sh "$name" > "$name/score.log" 2>&1 || code=$?
  echo "$code" > "$name/score_exit.txt"
  printf 'score %s %s\n' "$name" "$code"
}
cases=()
if [ "$stage" = single ]; then cases+=(clean); fi
for kind in z_shift rigid_ramp occlusion attenuation narrow_fov sync; do cases+=("${stage}_$kind"); done
for name in "${cases[@]}"; do
  run_score "$name" & jobs+=($!)
  if [ "${#jobs[@]}" = 2 ]; then
    for pid in "${jobs[@]}"; do wait "$pid"; done
    jobs=()
  fi
done
for pid in "${jobs[@]}"; do wait "$pid"; done
